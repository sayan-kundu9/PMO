package org.teksys.pmo.service;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.multipart.MultipartFile;
import org.teksys.pmo.dao.EmpTimeReportRepository;
import org.teksys.pmo.dao.UploadTimeSheetRepository;
import org.teksys.pmo.model.ImportTimeSheetEntity;

import java.io.FileInputStream;
import java.io.IOException;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
public class UploadTimeSheetServiceTest {

	@Mock
	UploadTimeSheetRepository uploadTimeSheetRepository;
	@Mock
	EmpTimeReportRepository empTimeReportRepository;

	@InjectMocks
	UploadTimeSheetService serviceUnderTest;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void storeFileIfTest() throws IOException {
		when(uploadTimeSheetRepository.save(any(ImportTimeSheetEntity.class))).thenReturn(importTimeSheetEntity());
		ImportTimeSheetEntity expected = serviceUnderTest.storeFile(file());
		assertThat("ashwin", is(expected.getCreatedBy()));
	}

	@Test
	public void storeFileElseTest() throws IOException {
		when(uploadTimeSheetRepository.save(any(ImportTimeSheetEntity.class))).thenReturn(importTimeSheetEntity());
		ImportTimeSheetEntity expected = serviceUnderTest.storeFile(file2());
	}

	@Test
	public void storeFileFalseNameTest() throws IOException {
		when(uploadTimeSheetRepository.save(any(ImportTimeSheetEntity.class))).thenReturn(importTimeSheetEntity());
		ImportTimeSheetEntity expected = serviceUnderTest.storeFile(file3());
	}

	@Test
	public void storeFileFalseEmpIdTest() throws IOException {
		when(uploadTimeSheetRepository.save(any(ImportTimeSheetEntity.class))).thenReturn(importTimeSheetEntity());
		ImportTimeSheetEntity expected = serviceUnderTest.storeFile(file4());
	}

	@Test
	public void storeFileFalseProjectIdTest() throws IOException {
		when(uploadTimeSheetRepository.save(any(ImportTimeSheetEntity.class))).thenReturn(importTimeSheetEntity());
		ImportTimeSheetEntity expected = serviceUnderTest.storeFile(file5());
	}

	public MultipartFile file() throws IOException {

		FileInputStream inputFile = new FileInputStream("src/test/java/resources/timesheetSuccess.xlsx");
		MockMultipartFile file = new MockMultipartFile("file", "timesheet1.xlsx", "multipart/form-data", inputFile);

		return file;
	}

	public MultipartFile file2() throws IOException {

		FileInputStream inputFile = new FileInputStream("src/test/java/resources/timesheetException.xlsx");
		MockMultipartFile file = new MockMultipartFile("file", "timesheet2.xlsx", "multipart/form-data", inputFile);

		return file;
	}

	public MultipartFile file3() throws IOException {

		FileInputStream inputFile = new FileInputStream("src/test/java/resources/timesheetFalseReturnName.xlsx");
		MockMultipartFile file = new MockMultipartFile("file", "timesheetFalseReturnName.xlsx", "multipart/form-data", inputFile);

		return file;
	}
	public MultipartFile file4() throws IOException {

		FileInputStream inputFile = new FileInputStream("src/test/java/resources/timesheetFalseReturnEmpId.xlsx");
		MockMultipartFile file = new MockMultipartFile("file", "timesheetFalseReturnEmpId.xlsx", "multipart/form-data", inputFile);

		return file;
	}
	public MultipartFile file5() throws IOException {

		FileInputStream inputFile = new FileInputStream("src/test/java/resources/timesheetFalseReturnProjectId.xlsx");
		MockMultipartFile file = new MockMultipartFile("file", "timesheetFalseReturnProjectId.xlsx", "multipart/form-data", inputFile);

		return file;
	}

	public ImportTimeSheetEntity importTimeSheetEntity() {
		ImportTimeSheetEntity importTimeSheetEntity = new ImportTimeSheetEntity();
		importTimeSheetEntity.setCreatedBy("ashwin");
		importTimeSheetEntity.setFileName("filename");
		return importTimeSheetEntity;
	}
}
