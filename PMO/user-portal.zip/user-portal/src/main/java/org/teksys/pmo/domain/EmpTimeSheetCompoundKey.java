package org.teksys.pmo.domain;

public class EmpTimeSheetCompoundKey
{
    private String companyEmpId;
    private String companyProjectId;
    private String month;
    private String year;
    private String type;

    public EmpTimeSheetCompoundKey(String type, String companyEmpId, String companyProjectId, String month, String year)
    {
        this.type = type;
        this.companyEmpId = companyEmpId;
        this.companyProjectId = companyProjectId;
        this.month = month;
        this.year = year;
    }

    public EmpTimeSheetCompoundKey() {}

    public void setCompanyEmpId(String companyEmpId)
    {
        this.companyEmpId = companyEmpId;
    }

    public String getCompanyEmpId()
    {
        return this.companyEmpId;
    }

    public void setCompanyProjectId(String companyProjectId)
    {
        this.companyProjectId = companyProjectId;
    }

    public String getCompanyProjectId()
    {
        return this.companyProjectId;
    }

    public void setMonth(String month)
    {
        this.month = month;
    }

    public String getMonth()
    {
        return this.month;
    }

    public void setYear(String year)
    {
        this.year = year;
    }

    public String getYear()
    {
        return this.year;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    public String getType()
    {
        return this.type;
    }
}
