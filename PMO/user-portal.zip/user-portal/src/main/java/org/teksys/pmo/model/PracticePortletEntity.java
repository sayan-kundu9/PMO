package org.teksys.pmo.model;

import javax.persistence.*;
import java.io.Serializable;


@Entity
@Table(name="PracticePortlet")
public class PracticePortletEntity implements Serializable {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    @Column(name="PortletPracticeID")
    private int id;
    @Column(name="PracticeHead")
    private String practiceHead;

    public void setId(int id)
    {
        this.id = id;
    }

    public int getId()
    {
        return this.id;
    }

    public void setPracticeHead(String practiceHead)
    {
        this.practiceHead = practiceHead;
    }

    public String getPracticeHead()
    {
        return this.practiceHead;
    }


}
