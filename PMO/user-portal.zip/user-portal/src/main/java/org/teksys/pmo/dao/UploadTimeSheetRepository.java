package org.teksys.pmo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.teksys.pmo.model.ImportTimeSheetEntity;

public interface UploadTimeSheetRepository extends JpaRepository<ImportTimeSheetEntity, Integer> ,UploadTimeSheetRepositoryCustom{
}
