package org.teksys.pmo.model;
import java.io.Serializable;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="BDM")
public class BDM implements Serializable{

    @Id
    @Column(name="BDMId", nullable=false, unique=true)
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int bdmId;
    @Column(name="Name")
    private String name;
//    @OneToMany(mappedBy="bdm")
//    private Set<ProjectDTO> projects;

    public void setBdmId(int bdmId)
    {
        this.bdmId = bdmId;
    }

    public int getBdmId()
    {
        return this.bdmId;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return this.name;
    }

//    public void setProjects(Set<ProjectDTO> projects)
//    {
//        this.projects = projects;
//    }
//
//    public Set<ProjectDTO> getProjects()
//    {
//        return this.projects;
//    }
}
