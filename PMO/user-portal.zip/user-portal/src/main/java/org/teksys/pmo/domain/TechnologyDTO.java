package org.teksys.pmo.domain;

import java.util.Set;

public class TechnologyDTO {

    private String technologyId;
    private String technologyName;
    private Set<Employee> employees;
    private Set<EmpProjectDTO> empProjects;


    public String getTechnologyId() {
        return technologyId;
    }

    public void setTechnologyId(String technologyId) {
        this.technologyId = technologyId;
    }

    public String getTechnologyName() {
        return technologyName;
    }

    public void setTechnologyName(String technologyName) {
        this.technologyName = technologyName;
    }

    public Set<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(Set<Employee> employees) {
        this.employees = employees;
    }

    public Set<EmpProjectDTO> getEmpProjects() {
        return empProjects;
    }

    public void setEmpProjects(Set<EmpProjectDTO> empProjects) {
        this.empProjects = empProjects;
    }
}
