package org.teksys.pmo.controller;

import java.io.FileNotFoundException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.teksys.pmo.dao.ProjectRepository;
import org.teksys.pmo.domain.BDMDTO;
import org.teksys.pmo.domain.ClientDTO;
import org.teksys.pmo.domain.PracticeDTO;
import org.teksys.pmo.domain.ProjectDTO;
import org.teksys.pmo.domain.RegionDTO;
import org.teksys.pmo.domain.SOWDTO;
import org.teksys.pmo.domain.SOWNameDTO;
import org.teksys.pmo.domain.SolutionExecutiveDTO;
import org.teksys.pmo.model.SOWNames;
import org.teksys.pmo.service.ProjectService;

@RestController
public class ProjectController {
    @Autowired
    private ProjectService projectService;
    @Autowired
    private ProjectRepository projectRepository ;
    // Work around, Kalai will work on it.
   //@CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/findAllProjects")
    public String findAllProjects(Pageable pageable) {
        return projectService.findAllProjects(pageable);
    }
    @GetMapping("/totalProjectsCount")
    public Integer totalProjectsCount() {
        return projectRepository.totalProjectsCount();
    }

//    @GetMapping("/findAllProjectPractices")
//
//    public List<ProjectPracticeMapping> findAllProjectPractices() {
//
//        return projectService.findAllProjectPractices();
//    }

    //@CrossOrigin(origins = "http://localhost:4200")
    @PostMapping(value = "/findProject")
    public List<ProjectDTO> findProjects(@RequestBody ProjectDTO projectDTO) {
        return projectService.findProjects(projectDTO);
    }

    //@CrossOrigin(origins = "http://localhost:4200")
    @PostMapping( "/addProject")
    public void addProject(@RequestBody ProjectDTO projectDTO ) {
        projectService.addProject(projectDTO);
    }

    @PostMapping( "/updateProject")
    public void updateProject(@RequestBody ProjectDTO projectDTO ) { projectService.updateProject(projectDTO); }

    //@CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/findAllClients")
    public List<ClientDTO> findAllClients() {
        return projectService.findAllClients();
    }

    //@CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/findAllRegions")
    public List<RegionDTO> findAllRegions() {
        return projectService.findAllRegions();
    }

    //@CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/findAllBdm")
    public List<BDMDTO> findAllBdm() {
        return projectService.findAllBdm();
    }

    //@CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/findAllSolutionExecutive")
    public List<SolutionExecutiveDTO> findAllSolutionExecutive() {
        return projectService.findAllSolutionExecutive();
    }

    //@CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/findAllPractices")
    public List<PracticeDTO> findAllPractices() {
        return projectService.findAllPractices();
    }

    //add and edit client
    //@CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/addClient")
    public void addClient(@RequestBody ClientDTO clientDTO) {
        projectService.addClient(clientDTO);
    }

    //@CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/editClient/{id}")
    public void editClient(@RequestBody ClientDTO clientDTO, @PathVariable Integer id) {
        projectService.updateClientById(clientDTO, id);
    }

    //@CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/findProjectSows")
    public List<SOWDTO> findProjectSowNames() {
        return projectService.findProjectSows();
    }

    @GetMapping(value = "/findAllProjectSowsList")
    public List<SOWNameDTO> findAllProjectSowsList(){
        return projectService.findAllProjectSowsList();
    }

    @GetMapping("/findProjectSows/{companyProjectId}")
    public List<SOWNameDTO> findSelectedSOWDetails(@PathVariable String companyProjectId) {
        return projectService.findSelectedSOWDetailsById(companyProjectId);
    }

    @PostMapping("/uploadSow/{companyProjectId}")
    public SOWNames uploadSow(@RequestParam("file") MultipartFile file, @PathVariable String companyProjectId) throws FileNotFoundException {
        SOWNames sowNames = projectService.uploadSow(file, companyProjectId);
        return sowNames;
    }

    @GetMapping("/downloadSow/{companyProjectId}")
    public byte[] downloadSow(@PathVariable String companyProjectId) {
        byte[] sowNames = projectService.downloadSow(companyProjectId);
        return  sowNames;
    }

    @PostMapping("/deleteSow/{companyProjectId}")
    public  void deleteSow(@PathVariable String companyProjectId) {
        projectService.deleteSow(companyProjectId);
    }
}
