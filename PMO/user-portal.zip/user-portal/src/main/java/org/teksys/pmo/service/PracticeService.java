package org.teksys.pmo.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.teksys.pmo.dao.ExpensesDao;
import org.teksys.pmo.dao.PracticeDao;
import org.teksys.pmo.domain.ExpensesDTO;
import org.teksys.pmo.domain.PracticeExpenseDTO;
import org.teksys.pmo.model.Expenses;
import org.teksys.pmo.model.PracticeExpense;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

@Service
public class PracticeService {
    private static final Logger logger = Logger.getLogger(PracticeService.class);

    @Autowired
    private PracticeDao practiceDao;

    @Autowired
    private ExpensesDao expensesDao;

    @Autowired
    private ObjectMapper objectMapper;

    public List<ExpensesDTO> findAllExpenses() {
        List<ExpensesDTO> expensesDTOList = new ArrayList<ExpensesDTO>();
        try {
            List<Expenses> expensesList = expensesDao.findAll();
            String expensesListInString = objectMapper.writeValueAsString(expensesList);
            expensesDTOList = objectMapper.readValue(expensesListInString, new TypeReference<List<ExpensesDTO>>() {
            });
        } catch (Exception ex) {
        }
        return expensesDTOList;
    }

    public List<PracticeExpenseDTO> findAllPracticeExpenses() {
        List<PracticeExpenseDTO> practiceExpenseDTOList = new ArrayList<PracticeExpenseDTO>();

        try {
            List<PracticeExpense> practiceExpenseList = practiceDao.findAll();
            String practiceExpenseListInString = objectMapper.writeValueAsString(practiceExpenseList);
            practiceExpenseDTOList = objectMapper.readValue(practiceExpenseListInString, new TypeReference<List<PracticeExpenseDTO>>() {
            });

        } catch (Exception ex) {
        }
        return practiceExpenseDTOList;
    }

    public void savePracticeExpense(PracticeExpenseDTO practiceExpenseDTO) {
        try {
            PracticeExpense practiceExpense = new PracticeExpense();

            practiceExpense.setPracticeId(practiceExpenseDTO.getPracticeId());
            practiceExpense.setExpensesId(practiceExpenseDTO.getExpensesId());
            practiceExpense.setAmount(practiceExpenseDTO.getAmount());
            practiceExpense.setCurrency_name(practiceExpenseDTO.getCurrency_name());
            practiceExpense.setDateOfExpense(practiceExpenseDTO.getDateOfExpense());
            practiceExpense.setExpenses_description(practiceExpenseDTO.getExpenses_description());
            practiceExpense.setPlanned(practiceExpenseDTO.getPlanned());

            practiceDao.save(practiceExpense);

        } catch (Exception e) {
            logger.error("error when try to find employee :"+e);
        }
    }

    public void updatePracticeExpenseById(PracticeExpenseDTO practiceExpenseDTO) {
        try {
            PracticeExpense practiceExpense = practiceDao.findByPracticeExpenseId(practiceExpenseDTO.getPracticeExpenseId());

            practiceExpense.setPracticeId(practiceExpenseDTO.getPracticeId());
            practiceExpense.setExpensesId(practiceExpenseDTO.getExpensesId());
            practiceExpense.setCurrency_name(practiceExpenseDTO.getCurrency_name());
            practiceExpense.setAmount(practiceExpenseDTO.getAmount());
            practiceExpense.setPlanned(practiceExpenseDTO.getPlanned());
            practiceExpense.setExpenses_description(practiceExpenseDTO.getExpenses_description());
            practiceExpense.setDateOfExpense(practiceExpenseDTO.getDateOfExpense());

            practiceDao.save(practiceExpense);
        } catch (Exception ex) {
        }
    }
}
