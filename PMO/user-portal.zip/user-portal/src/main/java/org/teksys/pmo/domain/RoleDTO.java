package org.teksys.pmo.domain;



import java.util.Set;

public class RoleDTO {
    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public Set<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(Set<Employee> employees) {
        this.employees = employees;
    }

    public Set<EmpProjectDTO> getEmpProjects() {
        return empProjects;
    }

    public void setEmpProjects(Set<EmpProjectDTO> empProjects) {
        this.empProjects = empProjects;
    }

    private String roleId;
    private String roleName;
    private Set<Employee> employees;
   // private Set<ProjectRoleBilling> projectRoleBillings;
    private Set<EmpProjectDTO> empProjects;
}
