package org.teksys.pmo.domain;

public class BDMDTO {
    private int bdmId;
    private String name;

    public int getBdmId() {
        return bdmId;
    }

    public void setBdmId(int bdmId) {
        this.bdmId = bdmId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
