package org.teksys.pmo.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.teksys.pmo.dao.PracticeManagementRepository;
import org.teksys.pmo.domain.PracticeManagementDTO;
import org.teksys.pmo.model.PracticeManagementEntity;
import java.util.ArrayList;
import java.util.List;

@Service
public class PracticeManagementService {
    @Autowired
    private PracticeManagementRepository practiceManagementRepository;
    @Autowired
    ObjectMapper objectMapper;

    public void saveProjectContent(PracticeManagementDTO practiceManagementDTO) {
        try {
            PracticeManagementEntity practiceManagementEntity=null;

            practiceManagementEntity = new PracticeManagementEntity();
            practiceManagementEntity.setId(practiceManagementDTO.getId());
            practiceManagementEntity.setPortletPracticeID(practiceManagementDTO.getPortletPracticeID());
            practiceManagementEntity.setPracticeContent(practiceManagementDTO.getPracticeContent());
            practiceManagementEntity.setCreatedBy(practiceManagementDTO.getCreatedBy());
            practiceManagementEntity.setCreatedDate(practiceManagementDTO.getCreatedDate());
            practiceManagementEntity.setModifiedBy(practiceManagementDTO.getModifiedBy());
            practiceManagementEntity.setActiveStr(practiceManagementDTO.getActiveStr());
            practiceManagementEntity.setDeletedStr(practiceManagementDTO.getDeletedStr());
            practiceManagementEntity.setCreatedDt(practiceManagementDTO.getCreatedDt());
            practiceManagementEntity.setActive(practiceManagementDTO.getActive());
            practiceManagementRepository.save(practiceManagementEntity);
        } catch  (Exception ex){ }
    }

    public List<PracticeManagementDTO> findAllProjectInfo() {
        List<PracticeManagementDTO> practiceManagementDTOS = new ArrayList<PracticeManagementDTO>();
        try {
            List<PracticeManagementEntity> practiceManagementEntities = practiceManagementRepository.findAllThoseNotDeleted();
            String employeeListInString =  objectMapper.writeValueAsString(practiceManagementEntities);
            practiceManagementDTOS =  objectMapper.readValue(employeeListInString, new TypeReference<List<PracticeManagementDTO>>(){});

        } catch (Exception ex) {

        }
        return practiceManagementDTOS;
    }
    public void updateById(PracticeManagementDTO practiceManagementDTO) {
        PracticeManagementEntity practiceManagementEntity =null;

        practiceManagementEntity=practiceManagementRepository.findById(practiceManagementDTO.getId());
        practiceManagementEntity.setPracticeContent(practiceManagementDTO.getPracticeContent());
        practiceManagementEntity.setDeleted(practiceManagementDTO.isDeleted());
        practiceManagementEntity.setActive(practiceManagementDTO.getActive());
        practiceManagementEntity.setModifiedDate(practiceManagementDTO.getModifiedDate());
        practiceManagementRepository.save(practiceManagementEntity);

    }
    public boolean isPracticeExist(PracticeManagementDTO practiceManagementDTO) {
        PracticeManagementEntity practiceManagementEntity =
                practiceManagementRepository.findById(practiceManagementDTO.getId());
        if(practiceManagementEntity != null){
           return false;
        }
        return true;
    }
}
