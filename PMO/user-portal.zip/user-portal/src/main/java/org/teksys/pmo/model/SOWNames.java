package org.teksys.pmo.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity(name = "ProjectSOW")
@Table(name = "ProjectSOW")
public class SOWNames implements Serializable {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ProjectSOWID")
    private String projectSowId;

    @Column(name="CompanyProjectID", nullable=false, unique=true)
    private String companyProjectId;
    @Column(name = "SOWName")
    private String sowName;

    @Column(name = "ContentType")
    private String contentType;

    @Column(name = "ProjectName")
    private String projectName;

    @Column(name = "SOWContent")
    private byte[] sowContent;

    public byte[] getSowContent() {
        return sowContent;
    }

    public void setSowContent(byte[] sowContent) {
        this.sowContent = sowContent;
    }

    public String getProjectSowId() {
        return projectSowId;
    }

    public void setProjectSowId(String projectSowId) {
        this.projectSowId = projectSowId;
    }

    public String getCompanyProjectId() {
        return companyProjectId;
    }

    public void setCompanyProjectId(String companyProjectId) {
        this.companyProjectId = companyProjectId;
    }

    public String getSowName() {
        return sowName;
    }

    public void setSowName(String sowName) {
        this.sowName = sowName;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }
}
