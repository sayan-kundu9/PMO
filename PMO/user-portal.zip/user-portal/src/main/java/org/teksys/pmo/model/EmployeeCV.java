package org.teksys.pmo.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(
        name = "EmployeeCV"
)
public class EmployeeCV implements Serializable{
    @Id
    @Column(
            name = "EmpCVID",
            nullable = false,
            unique = true
    )
    @GeneratedValue(
            strategy = GenerationType.AUTO
    )
    private int cvId;
    @Column(
            name = "EmpCompanyID"
    )
    private String empCompanyId;
    @Column(
            name = "CVName"
    )
    private String cvName;
    @Column(
            name = "Type"
    )
    private String type;
    @Column(
            name = "CVContent"
    )
    @Lob
    private byte[] cvContent;
    @ManyToOne
    @JoinColumn(
            name = "EmpCompanyID",
            insertable = false,
            updatable = false
    )
    private EmployeeEntity employee;

    public EmployeeCV() {
    }

    public void setCvId(int cvId) {
        this.cvId = cvId;
    }

    public int getCvId() {
        return this.cvId;
    }

    public void setEmpCompanyId(String empCompanyId) {
        this.empCompanyId = empCompanyId;
    }

    public String getEmpCompanyId() {
        return this.empCompanyId;
    }

    public void setCvName(String cvName) {
        this.cvName = cvName;
    }

    public String getCvName() {
        return this.cvName;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return this.type;
    }

    public void setCvContent(byte[] cvContent) {
        this.cvContent = cvContent;
    }

    public byte[] getCvContent() {
        return this.cvContent;
    }

    public void setEmployee(EmployeeEntity employee) {
        this.employee = employee;
    }

    public EmployeeEntity getEmployee() {
        return this.employee;
    }

}
