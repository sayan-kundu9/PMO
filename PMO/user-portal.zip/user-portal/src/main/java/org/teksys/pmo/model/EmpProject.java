package org.teksys.pmo.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


@Entity
@Table(
        name = "EmployeeProjectDetails"
)
public class EmpProject implements Serializable {

    @Id
    @Column(
            name = "EmployeeProjectID",
            nullable = false,
            unique = true
    )
    @GeneratedValue(
            strategy = GenerationType.AUTO
    )
    private int empProjectId;

    @ManyToOne
    @JoinColumn(
            name = "CompanyProjectID",
            insertable = false,
            updatable = false
    )
    private Project project;
    @ManyToOne
    @JoinColumn(
            name = "RoleID",
            insertable = false,
            updatable = false
    )
    private Role role;
    @ManyToOne
    @JoinColumn(
            name = "EmpCompanyID",
            insertable = false,
            updatable = false
    )
    private EmployeeEntity employee;
    @ManyToOne
    @JoinColumn(
            name = "TechnologyID",
            insertable = false,
            updatable = false
    )
    private Technology technology;
    @Column(
            name = "EmpCompanyID"
    )
    private String empProjectEmpId;


    @Column(
            name = "CompanyProjectID"
    )
    private String empProjectProjectId;
    @Column(
            name = "RoleID"
    )
    private String empProjectProjectRole;
    @Column(
            name = "ProjectStartDate"
    )
    private Date empProjectStartDate;
    @Column(
            name = "ProjectEndDate"
    )
    private Date empProjectEndDate;
    @Column(
            name = "TechnologyID"
    )
    private String empProjectTechnologyId;
    @Column(
            name = "Billable"
    )
    private String billable;
    @Column(
            name = "Revenue"
    )
    private String revenue;
    @Transient
    private String projectName;
    @Transient
    private String empName;
    @Transient
    private String empProjectStDate;
    @Transient
    private String empProjectEnDate;

    public EmpProject() {
    }

    public void setEmpProjectId(int empProjectId) {
        this.empProjectId = empProjectId;
    }

    public int getEmpProjectId() {
        return this.empProjectId;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public Project getProject() {
        return this.project;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Role getRole() {
        return this.role;
    }

    public void setEmployee(EmployeeEntity employee) {
        this.employee = employee;
    }

    public EmployeeEntity getEmployee() {
        return this.employee;
    }


   public void setTechnology(Technology technology) {
        this.technology = technology;
    }

    public Technology getTechnology() {
        return this.technology;
    }


    public void setEmpProjectEmpId(String empProjectEmpId) {
        this.empProjectEmpId = empProjectEmpId;
    }

    public String getEmpProjectEmpId() {
        return this.empProjectEmpId;
    }

    public void setEmpProjectProjectId(String empProjectProjectId) {
        this.empProjectProjectId = empProjectProjectId;
    }

    public String getEmpProjectProjectId() {
        return this.empProjectProjectId;
    }

    public void setEmpProjectProjectRole(String empProjectProjectRole) {
        this.empProjectProjectRole = empProjectProjectRole;
    }

    public String getEmpProjectProjectRole() {
        return this.empProjectProjectRole;
    }

    public void setEmpProjectStartDate(Date empProjectStartDate) {
        this.empProjectStartDate = empProjectStartDate;
    }

    public Date getEmpProjectStartDate() {
        return this.empProjectStartDate;
    }

    public void setEmpProjectEndDate(Date empProjectEndDate) {
        this.empProjectEndDate = empProjectEndDate;
    }

    public Date getEmpProjectEndDate() {
        return this.empProjectEndDate;
    }

    public void setEmpProjectTechnologyId(String empProjectTechnologyId) {
        this.empProjectTechnologyId = empProjectTechnologyId;
    }

    public String getEmpProjectTechnologyId() {
        return this.empProjectTechnologyId;
    }

    public void setBillable(String billable) {
        this.billable = billable;
    }

    public String getBillable() {
        return this.billable;
    }

    public void setRevenue(String revenue) {
        this.revenue = revenue;
    }

    public String getRevenue() {
        return this.revenue;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectName() {
        return this.projectName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpName() {
        return this.empName;
    }

    public void setEmpProjectStDate(String empProjectStDate) {
        this.empProjectStDate = empProjectStDate;
    }

    public String getEmpProjectStDate() {
        return this.empProjectStDate;
    }

    public void setEmpProjectEnDate(String empProjectEnDate) {
        this.empProjectEnDate = empProjectEnDate;
    }

    public String getEmpProjectEnDate() {
        return this.empProjectEnDate;
    }


}
