package org.teksys.pmo.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.teksys.pmo.dao.BdmDao;
import org.teksys.pmo.dao.ClientRepository;
import org.teksys.pmo.dao.ClientRepositoryCustom;
import org.teksys.pmo.dao.PracticeDao;
import org.teksys.pmo.dao.PracticesDao;
import org.teksys.pmo.dao.ProjectDetailsSOWDao;
import org.teksys.pmo.dao.ProjectPracticeMappingEntityRepository;
import org.teksys.pmo.dao.ProjectRepository;
import org.teksys.pmo.dao.ProjectRepositoryCustom;
import org.teksys.pmo.dao.ProjectSOWDao;
import org.teksys.pmo.dao.RegionDao;
import org.teksys.pmo.dao.SolutionExecutiveDao;
import org.teksys.pmo.dao.DaoImpl.ProjectRepositoryImpl;
import org.teksys.pmo.domain.BDMDTO;
import org.teksys.pmo.domain.ClientDTO;
import org.teksys.pmo.domain.PracticeDTO;
import org.teksys.pmo.domain.ProjectDTO;
import org.teksys.pmo.domain.ProjectPracticeMapping;
import org.teksys.pmo.domain.RegionDTO;
import org.teksys.pmo.domain.SOWDTO;
import org.teksys.pmo.domain.SOWNameDTO;
import org.teksys.pmo.domain.SolutionExecutiveDTO;
import org.teksys.pmo.exception.FileStorageException;
import org.teksys.pmo.model.BDM;
import org.teksys.pmo.model.Client;
import org.teksys.pmo.model.Practice;
import org.teksys.pmo.model.Project;
import org.teksys.pmo.model.ProjectPracticeMappingEntity;
import org.teksys.pmo.model.ProjectSOW;
import org.teksys.pmo.model.Region;
import org.teksys.pmo.model.SOWNames;
import org.teksys.pmo.model.SolutionExecutive;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ProjectService {
	@Autowired
	private ProjectRepository projectRepository;

	@Autowired
	private ProjectPracticeMappingEntityRepository projectPracticeMappingEntityRepository;

	@Autowired
	private ClientRepository clientDao;

	@Autowired
	private ClientRepositoryCustom clientDaoCustom;

	@Autowired
	private RegionDao regionDao;

	@Autowired
	private BdmDao bdmDao;

	@Autowired
	private SolutionExecutiveDao solutionExecutiveDao;

	@Autowired
	private PracticeDao practiceDao;

	@Autowired
	private PracticesDao practicesDao;

	@Autowired
	private ProjectSOWDao projectSOWDao;

	@Autowired
	private ProjectDetailsSOWDao projectDetailsSOWDao;

	@Autowired
	private ProjectRepositoryImpl projectRepositoryImpl;

	@Autowired
	private ProjectRepositoryCustom projectRepositoryCustom;

	@Autowired
	ObjectMapper objectMapper;

//    public List<ProjectDTO> findAllProjects(Pageable pageable) {
	public String findAllProjects(Pageable pageable) {
		List<ProjectDTO> projects = new ArrayList<ProjectDTO>();
		String projectListInString = null;
		try {
			// List<Project> projectList = projectDao.findAllProjects();
			if (pageable.getPageSize() == 0) {

			}
			Page<Project> projectList = projectRepository.findAll(pageable);
			long totalPage = projectList.getTotalElements();
			projectListInString = objectMapper.writeValueAsString(projectList);

			projects = objectMapper.readValue(projectListInString, new TypeReference<List<ProjectDTO>>() {
			});
		} catch (Exception ex) {
			ex.printStackTrace();
		}
//        return projects;
		return projectListInString;
	}

	public List<ProjectDTO> findProjects(ProjectDTO projectDTO) {
		List<ProjectDTO> projects = new ArrayList<ProjectDTO>();
		try {
			List<Project> projectList = projectRepositoryCustom.findProjects(projectDTO);
			String projectListInString = objectMapper.writeValueAsString(projectList);
			projects = objectMapper.readValue(projectListInString, new TypeReference<List<ProjectDTO>>() {
			});
		} catch (Exception ex) {

		}
		return projects;
	}

	public void addProject(ProjectDTO projectDTO) {
		try {
			Project projectEntity = new Project();
			// String[] practices = projectDTO.getProjectPracticeMappingSet().;
			Set<ProjectPracticeMapping> practices = new HashSet<>();
			practices = projectDTO.getProjectPracticeMappings();

			Set<ProjectPracticeMappingEntity> projectPracticeMappingEntities = new HashSet<>();
			for (ProjectPracticeMapping practice : practices) {
				ProjectPracticeMappingEntity projectPracticeMappingEntity = new ProjectPracticeMappingEntity();
				projectPracticeMappingEntity.setCompanyProjectId(projectDTO.getCompanyProjectId());
				projectPracticeMappingEntity.setPracticeId(practice.getPracticeId());
				projectPracticeMappingEntities.add(projectPracticeMappingEntity);
			}

			projectEntity.setCompanyProjectId(projectDTO.getCompanyProjectId());
			projectEntity.setProjectId(projectDTO.getProjectId());
			projectEntity.setProjectName(projectDTO.getProjectName());
			projectEntity.setClientId(projectDTO.getClientId());
			projectEntity.setRegionName(projectDTO.getRegionName());
			projectEntity.setSeName(projectDTO.getSeName());
			projectEntity.setBdmName(projectDTO.getBdmName());
			projectEntity.setStartDate(projectDTO.getStartDate());
			projectEntity.setEndDate(projectDTO.getEndDate());
			projectEntity.setProjectAnalyst(projectDTO.getProjectAnalyst());
			projectEntity.setEmail(projectDTO.getEmail());
			projectEntity.setContact(projectDTO.getContact());
			projectEntity.setType(projectDTO.getType());
			projectEntity.setProjectPracticeMappings(projectPracticeMappingEntities);

			// projectEntity.setProjectPracticeMappings(projectDTO.getProjectPracticeMappings());
			projectRepository.save(projectEntity);
		} catch (Exception ex) {
		}
	}

	public void updateProject(ProjectDTO projectDTO) {
		try {
			Project project = projectRepository.findByCompanyProjectId(projectDTO.getCompanyProjectId());
			Integer i = projectPracticeMappingEntityRepository.isExist(project.getCompanyProjectId());
			String s = project.getCompanyProjectId();
			if (i > 0) {
				projectPracticeMappingEntityRepository.removeByCompanyProjectId(s);
			}

			Set<ProjectPracticeMapping> practices = new HashSet<>();
			practices = projectDTO.getProjectPracticeMappings();

			Set<ProjectPracticeMappingEntity> projectPracticeMappingEntities = new HashSet<>();

			for (ProjectPracticeMapping practice : practices) {
				ProjectPracticeMappingEntity projectPracticeMappingEntity = new ProjectPracticeMappingEntity();
				projectPracticeMappingEntity.setProjectPracticeID(practice.getProjectPracticeID());
				projectPracticeMappingEntity.setCompanyProjectId(projectDTO.getCompanyProjectId());
				projectPracticeMappingEntity.setPracticeId(practice.getPracticeId());
				projectPracticeMappingEntities.add(projectPracticeMappingEntity);
			}

			// project.setCompanyProjectId(projectDTO.getCompanyProjectId());
			project.setProjectId(projectDTO.getProjectId());
			project.setProjectName(projectDTO.getProjectName());
			project.setClientId(projectDTO.getClientId());
			project.setRegionName(projectDTO.getRegionName());
			project.setSeName(projectDTO.getSeName());
			project.setBdmName(projectDTO.getBdmName());
			project.setStartDate(projectDTO.getStartDate());
			project.setEndDate(projectDTO.getEndDate());
			project.setProjectAnalyst(projectDTO.getProjectAnalyst());
			project.setEmail(projectDTO.getEmail());
			project.setContact(projectDTO.getContact());
			project.setType(projectDTO.getType());
			project.setProjectPracticeMappings(projectPracticeMappingEntities);

			projectRepository.save(project);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<ClientDTO> findAllClients() {
		List<ClientDTO> clientDTOList = new ArrayList<ClientDTO>();

		try {
			List<Client> clientList = clientDao.findAll();
			String clientListInString = objectMapper.writeValueAsString(clientList);
			clientDTOList = objectMapper.readValue(clientListInString, new TypeReference<List<ClientDTO>>() {
			});

		} catch (Exception ex) {
		}
		return clientDTOList;
	}

	public List<RegionDTO> findAllRegions() {
		List<RegionDTO> regionDTOList = new ArrayList<RegionDTO>();

		try {
			List<Region> regionList = regionDao.findAll();
			String regionListInString = objectMapper.writeValueAsString(regionList);
			regionDTOList = objectMapper.readValue(regionListInString, new TypeReference<List<RegionDTO>>() {
			});

		} catch (Exception ex) {
		}
		return regionDTOList;
	}

	public List<BDMDTO> findAllBdm() {
		List<BDMDTO> bdmdtoList = new ArrayList<BDMDTO>();

		try {
			List<BDM> bdmList = bdmDao.findAll();
			String bdmListInString = objectMapper.writeValueAsString(bdmList);
			bdmdtoList = objectMapper.readValue(bdmListInString, new TypeReference<List<BDMDTO>>() {
			});

		} catch (Exception ex) {
		}
		return bdmdtoList;
	}

	public List<SolutionExecutiveDTO> findAllSolutionExecutive() {
		List<SolutionExecutiveDTO> solutionExecutiveDTOList = new ArrayList<SolutionExecutiveDTO>();

		try {
			List<SolutionExecutive> solutionExecutiveList = solutionExecutiveDao.findAll();
			String seListInString = objectMapper.writeValueAsString(solutionExecutiveList);
			solutionExecutiveDTOList = objectMapper.readValue(seListInString,
					new TypeReference<List<SolutionExecutiveDTO>>() {
					});

		} catch (Exception ex) {
		}
		return solutionExecutiveDTOList;
	}

	public List<PracticeDTO> findAllPractices() {
		List<PracticeDTO> practiceDTOList = new ArrayList<PracticeDTO>();

		try {
			List<Practice> practiceList = practicesDao.findAll();
			String practiceListInString = objectMapper.writeValueAsString(practiceList);
			practiceDTOList = objectMapper.readValue(practiceListInString, new TypeReference<List<PracticeDTO>>() {
			});

		} catch (Exception ex) {
		}
		return practiceDTOList;
	}

	// addClient
	public void addClient(ClientDTO clientDTO) {
		try {
			Client client1 = new Client();
			client1.setId(clientDTO.getId());
			client1.setClientName(clientDTO.getClientName());
			clientDao.save(client1);
		} catch (Exception ex) {
		}
	}

	public void updateClientById(ClientDTO clientDTO, Integer id) {
		try {
			Client clent = clientDao.findById(id);
			clent.setClientName(clientDTO.getClientName());
			clientDao.save(clent);
		} catch (Exception ex) {
		}
	}

	public List<SOWDTO> findProjectSows() {
		List<SOWDTO> sowDTOList = new ArrayList<SOWDTO>();

		try {
			List<ProjectSOW> sowList = projectSOWDao.getAllProjectName();
			String sowListInString = objectMapper.writeValueAsString(sowList);
			sowDTOList = objectMapper.readValue(sowListInString, new TypeReference<List<SOWDTO>>() {
			});
		} catch (Exception ex) {
			System.out.println("Exception " + ex);
		}
		return sowDTOList;
	}

	public List<SOWNameDTO> findAllProjectSowsList() {
		List<SOWNameDTO> sowNamesList = new ArrayList<>();
		try {
			List<SOWNames> sowNames = projectDetailsSOWDao.findAll();
			String sowNamesResult = objectMapper.writeValueAsString(sowNames);
			sowNamesList = objectMapper.readValue(sowNamesResult, new TypeReference<List<SOWNameDTO>>() {
			});

		} catch (Exception ex) {
			System.out.println("Exception " + ex);
		}
		return sowNamesList;
	}

	public List<SOWNameDTO> findSelectedSOWDetailsById(String id) {
		List<SOWNameDTO> sowNamesList = new ArrayList<>();
		try {
			List<SOWNames> sowNames = projectDetailsSOWDao.getAllSowNamesById(id);
			String sowNamesResult = objectMapper.writeValueAsString(sowNames);
			sowNamesList = objectMapper.readValue(sowNamesResult, new TypeReference<List<SOWNameDTO>>() {
			});

		} catch (Exception ex) {
			System.out.println("Exception " + ex);
		}
		return sowNamesList;
	}

	public SOWNames uploadSow(MultipartFile file, String companyProjectId) throws FileNotFoundException {
		String fileName = org.springframework.util.StringUtils.cleanPath(file.getOriginalFilename());
		try {
			System.out.println(file.getContentType());
			if (file.getContentType() == "application/msword") {
				File word = new File(String.valueOf(file));
				byte[] b = new byte[(int) word.length()];
				FileInputStream fileInputStream = new FileInputStream(word);
				fileInputStream.read(b);
				for (int i = 0; i < b.length; i++) {
					System.out.print((char) b[i]);
				}
			} else {
				SOWNames sowNames = new SOWNames();
				sowNames.setCompanyProjectId(companyProjectId);
				sowNames.setSowName(fileName);
				sowNames.setSowContent(file.getBytes());
				sowNames.setContentType(file.getContentType());
				return projectDetailsSOWDao.save(sowNames);
			}
		} catch (Exception ex) {
			throw new FileStorageException("Could not store file " + fileName + ". Please try again!", ex);
		}
		return null;
	}

	public byte[] downloadSow(String companyProjectId) {
		return projectDetailsSOWDao.findSowByProjectId(companyProjectId);
	}

	public void deleteSow(String companyProjectId) {
		projectDetailsSOWDao.deleteSow(companyProjectId);
	}
}