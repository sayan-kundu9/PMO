package org.teksys.pmo.dao;

public interface UploadImportEmployeeRepositoryCustom {
}
