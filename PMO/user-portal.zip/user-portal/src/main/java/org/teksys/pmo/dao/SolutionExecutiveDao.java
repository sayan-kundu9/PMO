package org.teksys.pmo.dao;

import org.springframework.data.repository.CrudRepository;
import org.teksys.pmo.model.SolutionExecutive;

import java.util.List;

public interface SolutionExecutiveDao extends CrudRepository<SolutionExecutive, Integer> {
    @Override
    List<SolutionExecutive> findAll();
}
