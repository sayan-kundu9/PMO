package org.teksys.encryption.converters;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import org.teksys.utils.TGSRSAUtil;

@Converter
public class StringRSAConverter implements AttributeConverter<String, String> {

	@Override
	public String convertToDatabaseColumn(String attribute) {
		String result = null;
		try {
			System.out.println(TGSRSAUtil.class.hashCode());
			result = Base64.getEncoder().encodeToString(TGSRSAUtil.encrypt(attribute));
		} catch (InvalidKeyException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException
				| NoSuchAlgorithmException | InvalidKeySpecException | IOException e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public String convertToEntityAttribute(String dbData) {
		String result = null;
		try {
			result = TGSRSAUtil.decrypt(dbData);
		} catch (InvalidKeyException | NoSuchPaddingException | NoSuchAlgorithmException | BadPaddingException
				| IllegalBlockSizeException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}

}
