package org.teksys.pmo.domain;

import org.teksys.pmo.model.ProjectPracticeMappingEntity;

import java.util.Date;
import java.util.List;
import java.util.Set;


//Clients, region, bdm, solutionExecutive, are changed as of now

public class ProjectDTO {
    private String companyProjectId;

    private String projectId;
    //    private ClientDTO client;
    // private String client;
    //private RegionDTO region;
    // private String region;

    private BDMDTO bdm;

    public BDMDTO getBdm() {
        return bdm;
    }

    public void setBdm(BDMDTO bdm) {
        this.bdm = bdm;
    }

    // private String bdm;
    private SolutionExecutiveDTO solutionExecutive;
    //private String solutionExecutive;
    // private Set<ProjectRoleBilling> projectRoleBillings;

    //private Set<EmpProject> empProjects;

    //private Set<ProjectBidDetails> projectBidDetailses;

    private Set<ProjectPracticeMapping> projectPracticeMappingSet;
    private Set<ProjectPracticeMapping> projectPracticeMappings;
    //    private Set<ProjectSow> projectSowSet;
    private String projectName;
    private Date startDate;
    private Date endDate;
    private String clientName;

    private String clientId;
    private Integer regionName;
    private Integer bdmName;
    private Integer seName;
    private String createdBy;
    private Date dateCreated;
    private String modifiedBy;
    private Date dateModified;
    private char type;
    private String projectAnalyst;
    private String email;
    private String contact;
    private ClientDTO client;
    private RegionDTO region;
    //    private String stDate;
//    private String enDate;
    private String[] practices;
//    private String hideProjectPaymentMode;


    public Set<ProjectPracticeMapping> getProjectPracticeMappingSet() {
        return projectPracticeMappingSet;
    }

    public void setProjectPracticeMappingSet(Set<ProjectPracticeMapping> projectPracticeMappingSet) {
        this.projectPracticeMappingSet = projectPracticeMappingSet;
    }

    public String[] getPractices() {
        return practices;
    }

    public void setPractices(String[] practices) {
        this.practices = practices;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public Set<ProjectPracticeMapping> getProjectPracticeMappings() {
        return projectPracticeMappings;
    }

    public void setProjectPracticeMappings(Set<ProjectPracticeMapping> projectPracticeMappings) {
        this.projectPracticeMappings = projectPracticeMappings;
    }

    public String getCompanyProjectId() {
        return companyProjectId;
    }

    public void setCompanyProjectId(String companyProjectId) {
        this.companyProjectId = companyProjectId;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }
    public SolutionExecutiveDTO getSolutionExecutive() {
        return solutionExecutive;
    }

    public void setSolutionExecutive(SolutionExecutiveDTO solutionExecutive) {
        this.solutionExecutive = solutionExecutive;
    }
    public ClientDTO getClient() {
        return client;
    }

    public void setClient(ClientDTO client) {
        this.client = client;
    }
    public RegionDTO getRegion() {
        return region;
    }

    public void setRegion(RegionDTO region) {
        this.region = region;
    }
    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public Integer getRegionName() {
        return regionName;
    }

    public void setRegionName(Integer regionName) {
        this.regionName = regionName;
    }

    public Integer getBdmName() {
        return bdmName;
    }

    public void setBdmName(Integer bdmName) {
        this.bdmName = bdmName;
    }

    public Integer getSeName() {
        return seName;
    }

    public void setSeName(Integer seName) {
        this.seName = seName;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Date getDateModified() {
        return dateModified;
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified;
    }

    public char getType() {
        return type;
    }

    public void setType(char type) {
        this.type = type;
    }

    public String getProjectAnalyst() {
        return projectAnalyst;
    }

    public void setProjectAnalyst(String projectAnalyst) {
        this.projectAnalyst = projectAnalyst;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

}

