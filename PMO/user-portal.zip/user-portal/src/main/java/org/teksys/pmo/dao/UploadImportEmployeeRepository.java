package org.teksys.pmo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import org.teksys.pmo.model.EmployeeSalaryPerHour;
import org.teksys.pmo.model.ImportEmployee;

public interface UploadImportEmployeeRepository extends JpaRepository <ImportEmployee,Integer>,UploadImportEmployeeRepositoryCustom{
}
