package org.teksys.pmo.model;


import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@Entity
@Table(
        name = "Technology"
)
public class Technology implements Serializable {

    @Id
    @Column(
            name = "TechnologyID",
            nullable = false,
            unique = true
    )
    private String technologyId;
    @Column(
            name = "TechnologyName"
    )
    private String technologyName;
    /*@OneToMany(
            mappedBy = "technology"
    )
    private Set<EmployeeEntity> employees;*/
    /*@OneToMany(
            mappedBy = "technology"
    )
    private Set<EmpProject> empProjects;*/

    public Technology() {
    }

    public void setTechnologyId(String technologyId) {
        this.technologyId = technologyId;
    }

    public String getTechnologyId() {
        return this.technologyId;
    }

    public void setTechnologyName(String technologyName) {
        this.technologyName = technologyName;
    }

    public String getTechnologyName() {
        return this.technologyName;
    }

    /*public void setEmployees(Set<EmployeeEntity> employees) {
        this.employees = employees;
    }

    public Set<EmployeeEntity> getEmployees() {
        return this.employees;
    }*/

   /* public void setEmpProjects(Set<EmpProject> empProjects) {
        this.empProjects = empProjects;
    }

    public Set<EmpProject> getEmpProjects() {
        return this.empProjects;
    }*/
}
