package org.teksys.pmo.dao;

import org.apache.commons.codec.binary.Hex;
import org.hibernate.type.descriptor.sql.LongVarbinaryTypeDescriptor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import org.teksys.pmo.model.EmployeeCV;

import java.util.List;

public interface EmployeeCvRepo extends JpaRepository<EmployeeCV, Integer> {
    @Query("select empCompanyId,cvName,type from EmployeeCV")
    List<EmployeeCV> findAllEmployeeCv();

    @Query("select empCompanyId,cvName,type from EmployeeCV where empCompanyId=?")
    List<EmployeeCV> findEmployeeCvById(String empCompanyId);

    @Query("select count(empCompanyId) from EmployeeCV where empCompanyId=?")
    Integer empIdExists(String empCompanyId);

    @Transactional
    @Modifying
    @Query("delete from EmployeeCV where empCompanyId=?")
    void deleteEmployeeCv(String empCompanyId);

    @Query("select cvContent from EmployeeCV where empCompanyId=?")
    byte[] findCvByEmpId(String empCompanyId);
}

