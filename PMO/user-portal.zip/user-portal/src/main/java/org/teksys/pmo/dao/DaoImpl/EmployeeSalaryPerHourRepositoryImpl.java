package org.teksys.pmo.dao.DaoImpl;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.teksys.pmo.dao.EmployeeSalaryPerHourRepositoryCustom;
import org.teksys.pmo.domain.EmployeeSalaryPerHourDTO;
import org.teksys.pmo.model.EmployeeSalaryPerHour;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

//@Repository
public class EmployeeSalaryPerHourRepositoryImpl implements EmployeeSalaryPerHourRepositoryCustom {


    @Autowired
    EntityManager entityManager;


   public List<EmployeeSalaryPerHour> historyOfDL(EmployeeSalaryPerHourDTO employeeSalaryPerHourDTO) throws IOException{

       CriteriaBuilder cb = entityManager.getCriteriaBuilder();
       CriteriaQuery<EmployeeSalaryPerHour> cq = cb.createQuery(EmployeeSalaryPerHour.class);
       Root<EmployeeSalaryPerHour> empDL = cq.from(EmployeeSalaryPerHour.class);
       List<Predicate> predicates = new ArrayList<Predicate>();

       if(StringUtils.isNotBlank(employeeSalaryPerHourDTO.getCompanyEmpId()))
           predicates.add(cb.like(empDL.get("companyEmpId"),employeeSalaryPerHourDTO.getCompanyEmpId()));
       cq.select(empDL);
       cq.where(predicates.toArray(new Predicate[predicates.size()]));
       TypedQuery<EmployeeSalaryPerHour> q = entityManager.createQuery(cq);
       List<EmployeeSalaryPerHour> resultList = q.getResultList();
       return resultList;
    }

    @Override
    public List<EmployeeSalaryPerHour> employeeDL(EmployeeSalaryPerHourDTO employeeSalaryPerHourDTO) {

       List<EmployeeSalaryPerHour> employeeDL = new ArrayList<EmployeeSalaryPerHour>();

        StringBuffer s = new StringBuffer();
        s.append("SELECT * FROM EmployeeDLView WHERE EmpCompanyID=?1");

        Query query = entityManager.createNativeQuery(s.toString(), EmployeeSalaryPerHour.class);
        query.setParameter(1 , employeeSalaryPerHourDTO.getCompanyEmpId());

        employeeDL = query.getResultList();
        return employeeDL;

    }
}
