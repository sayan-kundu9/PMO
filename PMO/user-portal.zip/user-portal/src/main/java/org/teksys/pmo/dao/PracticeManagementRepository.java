package org.teksys.pmo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.teksys.pmo.model.PracticeManagementEntity;

import java.util.List;

public interface PracticeManagementRepository extends JpaRepository<PracticeManagementEntity,Integer>,PracticeManagementRepositoryCustom{

    @Override
    PracticeManagementEntity findOne(Integer integer);

    PracticeManagementEntity findById(Integer integer);

    @Query( "select l from PracticeManagementEntity l where deleted = 0" )
    List<PracticeManagementEntity> findAllThoseNotDeleted();

}
