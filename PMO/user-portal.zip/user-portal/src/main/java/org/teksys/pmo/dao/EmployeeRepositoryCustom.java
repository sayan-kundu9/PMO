package org.teksys.pmo.dao;

import org.teksys.pmo.domain.EmpProjectDTO;
import org.teksys.pmo.domain.Employee;
import org.teksys.pmo.domain.EmployeeAllDetails;
import org.teksys.pmo.model.EmpProject;
import org.teksys.pmo.model.EmployeeEntity;
import java.io.IOException;
import java.util.List;

public interface EmployeeRepositoryCustom {
    List<Employee> searchEmployee(String location);
    List<EmployeeEntity> findEmployees(Employee employee) throws IOException;
    List<EmployeeEntity> findEmployeesWithSpecificData(Employee employee) throws IOException;
    List<Employee> findEmployeeByAll(Employee employee) throws IOException;
    List<EmployeeAllDetails> getAllEmployees();
}
