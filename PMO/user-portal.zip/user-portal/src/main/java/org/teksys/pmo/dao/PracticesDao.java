package org.teksys.pmo.dao;

import org.springframework.data.repository.CrudRepository;
import org.teksys.pmo.model.Practice;

import java.util.List;
import java.util.Optional;

public interface PracticesDao extends CrudRepository<Practice, Integer> {
    @Override
    List<Practice> findAll();
    Optional<Practice> findByPracticeName(String practiceName);
}

