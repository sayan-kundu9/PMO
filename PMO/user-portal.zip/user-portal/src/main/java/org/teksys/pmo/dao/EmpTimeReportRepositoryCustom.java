package org.teksys.pmo.dao;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.teksys.pmo.domain.EmpTimeReport;

import java.util.List;

public interface EmpTimeReportRepositoryCustom {
    public List<EmpTimeReport> searchEmpTimeSheet(EmpTimeReport empTimeReport) throws JsonProcessingException;
}
