package org.teksys.pmo.model;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name="LandingPageInfo")
public class PracticeManagementEntity implements Serializable {

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    @Column(name="PracticeID")
    private int id;
    @Column(name="PortletPracticeID")
    private String portletPracticeID;
    @Column(name="PracticeContent")
    private String practiceContent;
    @Column(name="Deleted")
    private boolean isDeleted = false;
    @Column(name="Active")
    private boolean active;
    @Column(name="CreatedDate")
    @CreationTimestamp
    private Date createdDate;
    @Column(name="CreatedBy")
    private String createdBy;
    @Column(name="ModifiedDate")
    @UpdateTimestamp
    private Date modifiedDate;
    @Column(name="ModifiedBy")
    private String modifiedBy;
    @ManyToOne
    @JoinColumn(name="PortletPracticeID", insertable = false, updatable = false)
    private PracticePortletEntity practicePortletEntity;
    @Transient
    private String activeStr;
    @Transient
    private String deletedStr;
    @Transient
    private String createdDt;


    public PracticeManagementEntity(int id, String portletPracticeID, String practiceContent, boolean deleted, boolean active, Date createdDate, String createdBy, String modifiedBy, PracticePortletEntity practicePortletEntity,String activeStr,String deletedStr,String createdDt,Date modifiedDate) {
        this.id = id;
        this.portletPracticeID = portletPracticeID;
        this.practiceContent = practiceContent;
        this.isDeleted = deleted;
        this.active = active;
        this.createdDate = createdDate;
        this.createdBy = createdBy;
        this.modifiedDate = modifiedDate;
        this.modifiedBy = modifiedBy;
        this.practicePortletEntity = practicePortletEntity;
        this.activeStr=activeStr;
        this.deletedStr=deletedStr;
        this.createdDt=createdDt;

    }
    public PracticeManagementEntity() {}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPortletPracticeID() {
        return portletPracticeID;
    }

    public void setPortletPracticeID(String portletPracticeID) {
        this.portletPracticeID = portletPracticeID;
    }

    public String getPracticeContent() {
        return practiceContent;
    }

    public void setPracticeContent(String practiceContent) {
        this.practiceContent = practiceContent;
    }
    public void setDeleted(boolean isDeleted)
    {
        this.isDeleted = isDeleted;
    }

    public boolean isDeleted()
    {
        return this.isDeleted;
    }

    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public void setCreatedDate(Date createdDate)
    {
        this.createdDate = createdDate;
    }

    public Date getCreatedDate()
    {
        return this.createdDate;
    }

    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }

    public String getCreatedBy()
    {
        return this.createdBy;
    }

    public void setModifiedDate(Date modifiedDate)
    {
        this.modifiedDate = modifiedDate;
    }

    public Date getModifiedDate()
    {
        return this.modifiedDate;
    }

    public void setModifiedBy(String modifiedBy)
    {
        this.modifiedBy = modifiedBy;
    }

    public String getModifiedBy()
    {
        return this.modifiedBy;
    }

    public PracticePortletEntity getPracticePortletEntity() {
        return practicePortletEntity;
    }

    public void setPracticePortletEntity(PracticePortletEntity practicePortletEntity) {
        this.practicePortletEntity = practicePortletEntity;
    }

    public String getActiveStr() {
        return activeStr;
    }

    public void setActiveStr(String activeStr) {
        this.activeStr = activeStr;
    }

    public String getDeletedStr() {
        return deletedStr;
    }

    public void setDeletedStr(String deletedStr) {
        this.deletedStr = deletedStr;
    }

    public String getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(String createdDt) {
        this.createdDt = createdDt;
    }
}
