package org.teksys.pmo.dao;

import org.springframework.stereotype.Repository;
import org.teksys.pmo.domain.EmployeeSalaryPerHourDTO;
import org.teksys.pmo.model.EmployeeSalaryPerHour;

import java.io.IOException;
import java.util.List;

public interface EmployeeSalaryPerHourRepositoryCustom {
   // List<EmployeeSalaryPerHour> addEmpSal(EmployeeSalaryPerHour employeeSalaryPerHour);
   List<EmployeeSalaryPerHour> historyOfDL(EmployeeSalaryPerHourDTO employeeSalaryPerHourDTO) throws IOException;
   List<EmployeeSalaryPerHour> employeeDL(EmployeeSalaryPerHourDTO employeeSalaryPerHourDTO) throws IOException;
}
