package org.teksys.pmo.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.teksys.pmo.dao.EmpTimeReportRepository;
import org.teksys.pmo.dao.UploadTimeSheetRepository;
import org.teksys.pmo.exception.FileStorageException;
import org.teksys.pmo.model.EmpTimeReportEntity;
import org.teksys.pmo.model.EmpTimeSheetCompoundKeyEntity;
import org.teksys.pmo.model.EmployeeEntity;
import org.teksys.pmo.model.ImportTimeSheetEntity;
import org.teksys.pmo.model.Project;

@Service
public class UploadTimeSheetService {
	private static final Logger logger = Logger.getLogger(UploadTimeSheetService.class);

	@Autowired
	private UploadTimeSheetRepository uploadTimeSheetRepository;
	@Autowired
	private EmpTimeReportRepository empTimeReportRepository;

	public ImportTimeSheetEntity storeFile(MultipartFile file) {
		// Normalize file name
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());

		try {
			if (fileName.contains("..")) {
				throw new FileStorageException("Sorry! Filename contains invalid path sequence " + fileName);
			}
			Boolean isContentSaved = prepareExcelDataToPersist(file);
			ImportTimeSheetEntity importTimeSheetEntity = null;
			if (isContentSaved) {
				importTimeSheetEntity = new ImportTimeSheetEntity();
				importTimeSheetEntity.setModifiedBy("admin-modifiedBy");
				importTimeSheetEntity.setCreatedBy("admin");
				importTimeSheetEntity.setFileName(fileName);
				return uploadTimeSheetRepository.save(importTimeSheetEntity);
			} else {

				return new ImportTimeSheetEntity();
			}

		} catch (Exception ex) {
			throw new FileStorageException("Could not store file " + fileName + ". Please try again!", ex);
		}
	}

	private Boolean prepareExcelDataToPersist(MultipartFile file) {
		try {

			// List<Test> tempStudentList = new ArrayList<Test>();
			XSSFWorkbook workbook = new XSSFWorkbook(file.getInputStream());
			XSSFSheet worksheet = workbook.getSheetAt(0);
			System.out.println("@@@@@@@@@ -->> " + worksheet.getPhysicalNumberOfRows());
			HashMap<Integer, String> xlDates = new HashMap<Integer, String>();

			/* Excel sheet header part */
			XSSFRow row = worksheet.getRow(0);
			for (int i = 4; i <= 10; i++) {
				xlDates.put(i, row.getCell(i).toString());
			}
			EmpTimeReportEntity empTimeReportEntity = null;
			EmployeeEntity employeeEntity = null;
			EmpTimeSheetCompoundKeyEntity compoundEntity = null;
			Project project = null;

			// setting data excluding header so i is from 1
			for (int i = 1; i < worksheet.getPhysicalNumberOfRows(); i++) {

				XSSFRow row1 = worksheet.getRow(i);
				empTimeReportEntity = new EmpTimeReportEntity();
				employeeEntity = new EmployeeEntity();
				compoundEntity = new EmpTimeSheetCompoundKeyEntity();

				// for validation identify mandatory fields

				// if all are presented continue below code

				// else return false saying that mandatory fileds are missing

				if (org.apache.commons.lang.StringUtils.isNotBlank(row1.getCell(0).toString())) {
					compoundEntity.setCompanyEmpId(row1.getCell(0).toString());
				} else {

					return false;
				}
				if (org.apache.commons.lang.StringUtils.isNotBlank(row1.getCell(2).toString())) {
					compoundEntity.setCompanyProjectId(row1.getCell(2).toString());

				} else {

					return false;
				}
				compoundEntity.setType(row1.getCell(3).toString());
				compoundEntity.setMonth("10");
				compoundEntity.setYear(2012);

				employeeEntity.setCompanyEmpId(row1.getCell(0).toString());
				if (org.apache.commons.lang.StringUtils.isNotBlank(row1.getCell(1).toString())) {
					employeeEntity.setFirstName(row1.getCell(1).toString().split(" ")[0]);
					employeeEntity.setLastName(row1.getCell(1).toString().split(" ")[1]);

				} else {

					return false;
				}
				try {
					for (int j = 4; j <= 10; j++) {
						SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
						Date date = formatter.parse(xlDates.get(j)); // your date
						Calendar cal = Calendar.getInstance();
						cal.setTime(date);
						int month = cal.get(Calendar.DAY_OF_MONTH);

						if (org.apache.commons.lang.StringUtils.isNotBlank(row1.getCell(j).toString())) {
							float dayValue = org.apache.commons.lang.StringUtils.isNotBlank(row1.getCell(j).toString())
									? Float.parseFloat(row1.getCell(j).toString())
									: 0;
							switch (month) {
							case 1:
								empTimeReportEntity.setDay1(dayValue);
								break;
							case 2:
								empTimeReportEntity.setDay2(dayValue);
								break;
							case 3:
								empTimeReportEntity.setDay3(dayValue);
								break;
							case 4:
								empTimeReportEntity.setDay4(dayValue);
								break;
							case 5:
								empTimeReportEntity.setDay5(dayValue);
								break;
							case 6:
								empTimeReportEntity.setDay6(dayValue);
								break;
							case 7:
								empTimeReportEntity.setDay7(dayValue);
								break;
							case 8:
								empTimeReportEntity.setDay8(dayValue);
								break;
							case 9:
								empTimeReportEntity.setDay9(dayValue);
								break;
							case 10:
								empTimeReportEntity.setDay10(dayValue);
								break;
							case 11:
								empTimeReportEntity.setDay11(dayValue);
								break;
							case 12:
								empTimeReportEntity.setDay12(dayValue);
								break;
							case 13:
								empTimeReportEntity.setDay13(dayValue);
								break;
							case 14:
								empTimeReportEntity.setDay14(dayValue);
								break;
							case 15:
								empTimeReportEntity.setDay15(dayValue);
								break;
							case 16:
								empTimeReportEntity.setDay16(dayValue);
								break;
							case 17:
								empTimeReportEntity.setDay17(dayValue);
								break;
							case 18:
								empTimeReportEntity.setDay18(dayValue);
								break;
							case 19:
								empTimeReportEntity.setDay19(dayValue);
								break;
							case 20:
								empTimeReportEntity.setDay20(dayValue);
								break;
							case 21:
								empTimeReportEntity.setDay21(dayValue);
								break;
							case 22:
								empTimeReportEntity.setDay22(dayValue);
								break;
							case 23:
								empTimeReportEntity.setDay23(dayValue);
								break;
							case 24:
								empTimeReportEntity.setDay24(dayValue);
								break;
							case 25:
								empTimeReportEntity.setDay25(dayValue);
								break;
							case 26:
								empTimeReportEntity.setDay26(dayValue);
								break;
							case 27:
								empTimeReportEntity.setDay27(dayValue);
								break;
							case 28:
								empTimeReportEntity.setDay28(dayValue);
								break;
							case 29:
								empTimeReportEntity.setDay29(dayValue);
								break;
							case 30:
								empTimeReportEntity.setDay30(dayValue);
								break;
							case 31:
								empTimeReportEntity.setDay31(dayValue);
								break;
							default:
								break;
							}
						} else {
							return false;
						}
					}
				} catch (Exception e) {
					logger.error("error when try to find employee :" + e);
				}
				if (!StringUtils.isEmpty(row1)) {
					empTimeReportEntity.setTotal(Float.parseFloat(row1.getCell(11).toString()));
				}
				empTimeReportEntity.setEmpTimeSheetCompoundKey(compoundEntity);
				// set employee entity to timesheet report
				// empTimeReportEntity.setEmployeeEntity(employeeEntity);
				empTimeReportRepository.save(empTimeReportEntity);
				// finally save empTimeReportEntity
			}
		} catch (IOException e) {
			logger.error("error when try to find employee :" + e);
		}

		return true;
	}

}