package org.teksys.pmo.model;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table (name="ImportEmployee")
public class ImportEmployee implements Serializable {


    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    @Column(name="ImportEmployeeID")
    private int id;
    @Column(name="FileName")
    private String fileName;
    @Column(name="CreatedBy")
    private String createdBy;
    @CreationTimestamp
    @Column(name="CreatedDate")
    private Date dateCreated;
    @Column(name="ModifiedBy")
    private String modifiedBy;
    @UpdateTimestamp
    @Column(name="ModifiedDate")
    private Date dateModified;
    
    @Transient
    private List<String> errorList;
    

    public ImportEmployee() {
    	
    }
    public ImportEmployee(String fileName, String createdBy, Date dateCreated, String modifiedBy, Date dateModified, List<String> errorList) {
		super();
		this.fileName = fileName;
		this.createdBy = createdBy;
		this.dateCreated = dateCreated;
		this.modifiedBy = modifiedBy;
		this.dateModified = dateModified;
		this.errorList = errorList;
	}

	public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Date getDateModified() {
        return dateModified;
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified;
    }
	public List<String> getErrorList() {
		return errorList;
	}
	public void setErrorList(List<String> errorList) {
		this.errorList = errorList;
	}


}
