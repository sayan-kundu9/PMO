package org.teksys.pmo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.teksys.pmo.model.ProjectPracticeMappingEntity;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ProjectPracticeMappingEntityRepository extends JpaRepository<ProjectPracticeMappingEntity, Integer> {
    @Override
    List<ProjectPracticeMappingEntity> findAll();

    @Transactional
    @Modifying
    @Query("delete from Project_Practice where CompanyProjectID = ?")
    void removeByCompanyProjectId(String companyProjectId);


    @Query("select count(CompanyProjectID) from Project_Practice where companyProjectID=?")
    Integer isExist(String companyProjectID);
}
