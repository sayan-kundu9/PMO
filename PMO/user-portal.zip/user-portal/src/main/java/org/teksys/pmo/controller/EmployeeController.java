package org.teksys.pmo.controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.teksys.pmo.dao.EmployeeCvRepo;
import org.teksys.pmo.dao.EmployeeRepository;
import org.teksys.pmo.domain.Employee;
import org.teksys.pmo.domain.EmployeeAllDetails;
import org.teksys.pmo.domain.EmployeeSalaryPerHourDTO;
import org.teksys.pmo.model.EmployeeCV;
import org.teksys.pmo.model.EmployeeEntity;
import org.teksys.pmo.model.EmployeeSalaryPerHour;
import org.teksys.pmo.model.ImportEmployee;
import org.teksys.pmo.service.EmployeeServiceImpl;
import org.teksys.pmo.service.UploadImportEmployeeService;

@RestController
//@CrossOrigin(origins = "http://localhost:4200")
public class EmployeeController {
	private static final Logger logger = Logger.getLogger(EmployeeController.class);
	@Autowired
	private EmployeeServiceImpl employeeService;
	@Autowired
	private UploadImportEmployeeService uploadImportEmployeeService;
	@Autowired
	private EmployeeRepository employeeRepository;
	@Autowired
	private EmployeeCvRepo employeeCvRepo;

	@GetMapping("/getAllEmployees")
	public @ResponseBody List<EmployeeAllDetails> getAllEmployees() {
		return employeeService.getAllEmployees();
	}

	@GetMapping("/findAllEmployees")
	public List<EmployeeEntity> findAllEmployees() {
		return employeeService.findAllEmployees();
	}

	@GetMapping("/findEmpByLocation/{location}")
	public List<Employee> findEmpByLocation(@PathVariable("location") String location) {
		return employeeService.findEmpByLocation(location);
	}

	@GetMapping("/findEmpName")
	public List<EmployeeEntity> findEmpName() {
		return employeeRepository.findEmpName();
	}

	@RequestMapping(value = "/findEmployee", method = RequestMethod.POST)
	public List<Employee> findEmployee(@RequestBody Employee employee) {
		try {
			return employeeService.findEmployees(employee);
		} catch (IOException e) {
			logger.error("error when try to find employee :" + e);
		}
		return null;

	}

	@RequestMapping(value = "/findEmployeesWithSpecificData", method = RequestMethod.POST)
	public List<Employee> findEmployeesWithSpecificData(@RequestBody Employee employee) {

		return employeeService.findEmployeesWithSpecificData(employee);

	}

	@PostMapping("/addEmployee")
	public void addEmployee(@RequestBody Employee employee) {
		employeeService.addEmployee(employee);
	}

	@RequestMapping(value = "/editEmployee", method = RequestMethod.PUT)
	public EmployeeEntity editEmployee(@RequestBody EmployeeEntity editEmployee) throws IOException {

		return employeeService.editEmployee(editEmployee);
	}

	@PutMapping("/addEmpSal")
	public void addEmpSal(@RequestBody EmployeeSalaryPerHour employeeSalaryPerHour) {
		employeeService.addEmpSal(employeeSalaryPerHour);
	}

	@PostMapping("/historyOfDL")
	public List<EmployeeSalaryPerHourDTO> historyOfDL(@RequestBody EmployeeSalaryPerHourDTO employeeSalaryPerHourDTO) {
		return employeeService.historyOfDL(employeeSalaryPerHourDTO);
	}

	@PostMapping("/importEmployeeFile")
	public ResponseEntity<Object> importFile(@Valid @RequestParam("file") MultipartFile file) {
		ImportEmployee result = null;
		try {
			result = uploadImportEmployeeService.storeFile(file);
			return ResponseEntity.accepted().body(result);
		} catch (ParseException | IOException e) {

			return ResponseEntity.status(HttpStatus.PARTIAL_CONTENT).body(result);
		}

	}

	@PostMapping("/employeeDL")
	public List<EmployeeSalaryPerHourDTO> employeeDL(@RequestBody EmployeeSalaryPerHourDTO employeeSalaryPerHourDTO) {
		return employeeService.employeeDL(employeeSalaryPerHourDTO);
	}

	// fetch, upload, download and delete functionality
	@GetMapping("/findAllEmployeeCv")
	public List<EmployeeCV> findAllEmployeeCv() {
		return employeeCvRepo.findAllEmployeeCv();
	}

	@GetMapping("/findEmployeeCvById/{empComId}")
	public List<EmployeeCV> findEmployeeCvById(@PathVariable String empComId) {
		return employeeCvRepo.findEmployeeCvById(empComId);
	}

	@GetMapping("/empIdExists/{empComId}")
	public Integer empIdExists(@PathVariable String empComId) {
		return employeeCvRepo.empIdExists(empComId);
	}

	@PostMapping("/uploadCv/{empComId}")
	public EmployeeCV uploadFile(@RequestParam("file") MultipartFile file, @PathVariable String empComId) {
		EmployeeCV employeeCV = employeeService.storeFile(file, empComId);
		return employeeCV;
	}

	@GetMapping("/downloadCv/{empCompanyId}")
	public byte[] downloadFile(@PathVariable String empCompanyId) {
		byte[] employeeCV = employeeService.downloadFile(empCompanyId);
		return employeeCV;
	}

	@PostMapping("/deleteCv/{empCompanyId}")
	public void deleteEmployeeCv(@PathVariable String empCompanyId) {
		employeeService.deleteEmployeeCv(empCompanyId);
	}
}
