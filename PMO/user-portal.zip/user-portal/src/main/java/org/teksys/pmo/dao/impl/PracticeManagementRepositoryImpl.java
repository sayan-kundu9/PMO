package org.teksys.pmo.dao.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.teksys.pmo.dao.PracticeManagementRepositoryCustom;
import org.teksys.pmo.domain.PracticeManagementDTO;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import java.util.List;

@Repository
public class PracticeManagementRepositoryImpl implements PracticeManagementRepositoryCustom {
    @Autowired
    EntityManager entityManager;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    EntityManagerFactory entityManagerFactory;

    public List<PracticeManagementDTO> updateById(PracticeManagementDTO practiceManagementDTO)
    {

    return  null;
       // return practiceManagementDTO;
    }
}
