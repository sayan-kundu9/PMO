package org.teksys.pmo.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.teksys.pmo.dao.EmpTimeReportRepositoryCustom;
import org.teksys.pmo.domain.EmpTimeReport;
import org.teksys.pmo.model.EmpTimeReportEntity;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EmpTimeReportRepositoryImpl implements EmpTimeReportRepositoryCustom {
	@Autowired
	private EntityManager entityManager;
	/* Map<Integer,String> practices = new HashMap(); */

	@Autowired
	private ObjectMapper objectMapper;

	List<EmpTimeReport> timeReportsList = new ArrayList<EmpTimeReport>();

	public List<EmpTimeReport> searchEmpTimeSheet(EmpTimeReport empTimeReport) {
		List<EmpTimeReportEntity> empTimeReportEntities = null;

		if (empTimeReport.getEmpTimeSheetCompoundKey().getCompanyEmpId() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getCompanyProjectId() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getMonth() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getYear() != null) {
			empTimeReportEntities = entityManager.createNativeQuery(
					"SELECT timesheet.Type,MonthReport,YearReport,timesheet.EmpCompanyID,timesheet.CompanyProjectID,Day1,Day2,Day3,Day4,Day5,Day6,Day7,Day8,Day9,Day10,Day11,Day12,Day13,Day14,Day15,Day16,Day17,Day18,Day19,Day20,Day21,Day22,Day23,Day24,Day25,Day26,Day27,Day28,Day29,Day30,Day31,Total,employee.FirstName +' '+ employee.LastName as empName,pd.ProjectName FROM EmployeeTimesheetReport timesheet INNER JOIN Employee employee ON timesheet.EmpCompanyID = employee.EmpCompanyID inner join ProjectDetails pd on pd.CompanyProjectID = timesheet.CompanyProjectID where MonthReport= :month and YearReport= :year and timesheet.EmpCompanyID= :companyEmpId and timesheet.CompanyProjectID= :companyProjectId ",
					EmpTimeReportEntity.class)
					.setParameter("month", empTimeReport.getEmpTimeSheetCompoundKey().getMonth())
					.setParameter("year", empTimeReport.getEmpTimeSheetCompoundKey().getYear())
					.setParameter("companyEmpId", empTimeReport.getEmpTimeSheetCompoundKey().getCompanyEmpId())
					.setParameter("companyProjectId", empTimeReport.getEmpTimeSheetCompoundKey().getCompanyProjectId())
					.getResultList();
		} else if (empTimeReport.getEmpTimeSheetCompoundKey().getCompanyEmpId() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getCompanyProjectId() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getMonth() != null) {
			empTimeReportEntities = entityManager.createNativeQuery(
					"SELECT timesheet.Type,MonthReport,YearReport,timesheet.EmpCompanyID,timesheet.CompanyProjectID,Day1,Day2,Day3,Day4,Day5,Day6,Day7,Day8,Day9,Day10,Day11,Day12,Day13,Day14,Day15,Day16,Day17,Day18,Day19,Day20,Day21,Day22,Day23,Day24,Day25,Day26,Day27,Day28,Day29,Day30,Day31,Total,employee.FirstName +' '+ employee.LastName as empName,pd.ProjectName FROM EmployeeTimesheetReport timesheet INNER JOIN Employee employee ON timesheet.EmpCompanyID = employee.EmpCompanyID inner join ProjectDetails pd on pd.CompanyProjectID = timesheet.CompanyProjectID where MonthReport= :month and timesheet.EmpCompanyID= :companyEmpId and timesheet.CompanyProjectID= :companyProjectId ",
					EmpTimeReportEntity.class)
					.setParameter("month", empTimeReport.getEmpTimeSheetCompoundKey().getMonth())
					.setParameter("companyEmpId", empTimeReport.getEmpTimeSheetCompoundKey().getCompanyEmpId())
					.setParameter("companyProjectId", empTimeReport.getEmpTimeSheetCompoundKey().getCompanyProjectId())
					.getResultList();
		} else if (empTimeReport.getEmpTimeSheetCompoundKey().getCompanyEmpId() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getCompanyProjectId() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getYear() != null) {
			empTimeReportEntities = entityManager.createNativeQuery(
					"SELECT timesheet.Type,MonthReport,YearReport,timesheet.EmpCompanyID,timesheet.CompanyProjectID,Day1,Day2,Day3,Day4,Day5,Day6,Day7,Day8,Day9,Day10,Day11,Day12,Day13,Day14,Day15,Day16,Day17,Day18,Day19,Day20,Day21,Day22,Day23,Day24,Day25,Day26,Day27,Day28,Day29,Day30,Day31,Total,employee.FirstName +' '+ employee.LastName as empName,pd.ProjectName FROM EmployeeTimesheetReport timesheet INNER JOIN Employee employee ON timesheet.EmpCompanyID = employee.EmpCompanyID inner join ProjectDetails pd on pd.CompanyProjectID = timesheet.CompanyProjectID where YearReport= :year and timesheet.EmpCompanyID= :companyEmpId and timesheet.CompanyProjectID= :companyProjectId ",
					EmpTimeReportEntity.class)
					.setParameter("year", empTimeReport.getEmpTimeSheetCompoundKey().getYear())
					.setParameter("companyEmpId", empTimeReport.getEmpTimeSheetCompoundKey().getCompanyEmpId())
					.setParameter("companyProjectId", empTimeReport.getEmpTimeSheetCompoundKey().getCompanyProjectId())
					.getResultList();
		} else if (empTimeReport.getEmpTimeSheetCompoundKey().getCompanyProjectId() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getMonth() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getYear() != null) {
			empTimeReportEntities = entityManager.createNativeQuery(
					"SELECT timesheet.Type,MonthReport,YearReport,timesheet.EmpCompanyID,timesheet.CompanyProjectID,Day1,Day2,Day3,Day4,Day5,Day6,Day7,Day8,Day9,Day10,Day11,Day12,Day13,Day14,Day15,Day16,Day17,Day18,Day19,Day20,Day21,Day22,Day23,Day24,Day25,Day26,Day27,Day28,Day29,Day30,Day31,Total,employee.FirstName +' '+ employee.LastName as empName,pd.ProjectName FROM EmployeeTimesheetReport timesheet INNER JOIN Employee employee ON timesheet.EmpCompanyID = employee.EmpCompanyID inner join ProjectDetails pd on pd.CompanyProjectID = timesheet.CompanyProjectID where MonthReport= :month and YearReport= :year and timesheet.CompanyProjectID= :companyProjectId",
					EmpTimeReportEntity.class)
					.setParameter("year", empTimeReport.getEmpTimeSheetCompoundKey().getYear())
					.setParameter("companyProjectId", empTimeReport.getEmpTimeSheetCompoundKey().getCompanyProjectId())
					.setParameter("month", empTimeReport.getEmpTimeSheetCompoundKey().getMonth()).getResultList();
		} else if (empTimeReport.getEmpTimeSheetCompoundKey().getCompanyEmpId() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getMonth() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getYear() != null) {
			empTimeReportEntities = entityManager.createNativeQuery(
					"SELECT timesheet.Type,MonthReport,YearReport,timesheet.EmpCompanyID,timesheet.CompanyProjectID,Day1,Day2,Day3,Day4,Day5,Day6,Day7,Day8,Day9,Day10,Day11,Day12,Day13,Day14,Day15,Day16,Day17,Day18,Day19,Day20,Day21,Day22,Day23,Day24,Day25,Day26,Day27,Day28,Day29,Day30,Day31,Total,employee.FirstName +' '+ employee.LastName as empName,pd.ProjectName FROM EmployeeTimesheetReport timesheet INNER JOIN Employee employee ON timesheet.EmpCompanyID = employee.EmpCompanyID inner join ProjectDetails pd on pd.CompanyProjectID = timesheet.CompanyProjectID where timeSheet.MonthReport= :month and timeSheet.YearReport= :year and timeSheet.EmpCompanyID= :companyEmpId ",
					EmpTimeReportEntity.class)
					.setParameter("companyEmpId", empTimeReport.getEmpTimeSheetCompoundKey().getCompanyEmpId())
					.setParameter("year", empTimeReport.getEmpTimeSheetCompoundKey().getYear())
					.setParameter("month", empTimeReport.getEmpTimeSheetCompoundKey().getMonth()).getResultList();
		} else if (empTimeReport.getEmpTimeSheetCompoundKey().getCompanyEmpId() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getCompanyProjectId() != null) {
			empTimeReportEntities = entityManager.createNativeQuery(
					"SELECT timesheet.Type,MonthReport,YearReport,timesheet.EmpCompanyID,timesheet.CompanyProjectID,Day1,Day2,Day3,Day4,Day5,Day6,Day7,Day8,Day9,Day10,Day11,Day12,Day13,Day14,Day15,Day16,Day17,Day18,Day19,Day20,Day21,Day22,Day23,Day24,Day25,Day26,Day27,Day28,Day29,Day30,Day31,Total,employee.FirstName +' '+ employee.LastName as empName,pd.ProjectName FROM EmployeeTimesheetReport timesheet INNER JOIN Employee employee ON timesheet.EmpCompanyID = employee.EmpCompanyID inner join ProjectDetails pd on pd.CompanyProjectID = timesheet.CompanyProjectID where  timeSheet.EmpCompanyID= :companyEmpId and timeSheet.CompanyProjectID= :companyProjectId",
					EmpTimeReportEntity.class)
					.setParameter("companyEmpId", empTimeReport.getEmpTimeSheetCompoundKey().getCompanyEmpId())
					.setParameter("companyProjectId", empTimeReport.getEmpTimeSheetCompoundKey().getCompanyProjectId())
					.getResultList();
		} else if (empTimeReport.getEmpTimeSheetCompoundKey().getCompanyProjectId() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getMonth() != null) {
			empTimeReportEntities = entityManager.createNativeQuery(
					"SELECT timesheet.Type,MonthReport,YearReport,timesheet.EmpCompanyID,timesheet.CompanyProjectID,Day1,Day2,Day3,Day4,Day5,Day6,Day7,Day8,Day9,Day10,Day11,Day12,Day13,Day14,Day15,Day16,Day17,Day18,Day19,Day20,Day21,Day22,Day23,Day24,Day25,Day26,Day27,Day28,Day29,Day30,Day31,Total,employee.FirstName +' '+ employee.LastName as empName,pd.ProjectName FROM EmployeeTimesheetReport timesheet INNER JOIN Employee employee ON timesheet.EmpCompanyID = employee.EmpCompanyID inner join ProjectDetails pd on pd.CompanyProjectID = timesheet.CompanyProjectID where timeSheet.MonthReport= :month  and timeSheet.CompanyProjectID= :companyProjectId",
					EmpTimeReportEntity.class)
					.setParameter("companyProjectId", empTimeReport.getEmpTimeSheetCompoundKey().getCompanyProjectId())
					.setParameter("month", empTimeReport.getEmpTimeSheetCompoundKey().getMonth()).getResultList();
		}

		else if (empTimeReport.getEmpTimeSheetCompoundKey().getMonth() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getYear() != null) {
			empTimeReportEntities = entityManager.createNativeQuery(
					"SELECT timesheet.Type,MonthReport,YearReport,timesheet.EmpCompanyID,timesheet.CompanyProjectID,Day1,Day2,Day3,Day4,Day5,Day6,Day7,Day8,Day9,Day10,Day11,Day12,Day13,Day14,Day15,Day16,Day17,Day18,Day19,Day20,Day21,Day22,Day23,Day24,Day25,Day26,Day27,Day28,Day29,Day30,Day31,Total,employee.FirstName +' '+ employee.LastName as empName,pd.ProjectName FROM EmployeeTimesheetReport timesheet INNER JOIN Employee employee ON timesheet.EmpCompanyID = employee.EmpCompanyID inner join ProjectDetails pd on pd.CompanyProjectID = timesheet.CompanyProjectID where MonthReport= :month and YearReport= :year",
					EmpTimeReportEntity.class)
					.setParameter("month", empTimeReport.getEmpTimeSheetCompoundKey().getMonth())
					.setParameter("year", empTimeReport.getEmpTimeSheetCompoundKey().getYear()).getResultList();
		} else if (empTimeReport.getEmpTimeSheetCompoundKey().getCompanyProjectId() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getYear() != null) {
			empTimeReportEntities = entityManager.createNativeQuery(
					"SELECT timesheet.Type,MonthReport,YearReport,timesheet.EmpCompanyID,timesheet.CompanyProjectID,Day1,Day2,Day3,Day4,Day5,Day6,Day7,Day8,Day9,Day10,Day11,Day12,Day13,Day14,Day15,Day16,Day17,Day18,Day19,Day20,Day21,Day22,Day23,Day24,Day25,Day26,Day27,Day28,Day29,Day30,Day31,Total,employee.FirstName +' '+ employee.LastName as empName,pd.ProjectName FROM EmployeeTimesheetReport timesheet INNER JOIN Employee employee ON timesheet.EmpCompanyID = employee.EmpCompanyID inner join ProjectDetails pd on pd.CompanyProjectID = timesheet.CompanyProjectID where timeSheet.CompanyProjectID= :companyProjectId and timeSheet.YearReport= :year",
					EmpTimeReportEntity.class)
					.setParameter("companyProjectId", empTimeReport.getEmpTimeSheetCompoundKey().getCompanyProjectId())
					.setParameter("year", empTimeReport.getEmpTimeSheetCompoundKey().getYear()).getResultList();
		} else if (empTimeReport.getEmpTimeSheetCompoundKey().getCompanyEmpId() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getMonth() != null) {
			empTimeReportEntities = entityManager.createNativeQuery(
					"SELECT timesheet.Type,MonthReport,YearReport,timesheet.EmpCompanyID,timesheet.CompanyProjectID,Day1,Day2,Day3,Day4,Day5,Day6,Day7,Day8,Day9,Day10,Day11,Day12,Day13,Day14,Day15,Day16,Day17,Day18,Day19,Day20,Day21,Day22,Day23,Day24,Day25,Day26,Day27,Day28,Day29,Day30,Day31,Total,employee.FirstName +' '+ employee.LastName as empName,pd.ProjectName FROM EmployeeTimesheetReport timesheet INNER JOIN Employee employee ON timesheet.EmpCompanyID = employee.EmpCompanyID inner join ProjectDetails pd on pd.CompanyProjectID = timesheet.CompanyProjectID where timeSheet.EmpCompanyID= :companyEmpId and timeSheet.MonthReport= :month",
					EmpTimeReportEntity.class)
					.setParameter("companyEmpId", empTimeReport.getEmpTimeSheetCompoundKey().getCompanyEmpId())
					.setParameter("month", empTimeReport.getEmpTimeSheetCompoundKey().getMonth()).getResultList();
		} else if (empTimeReport.getEmpTimeSheetCompoundKey().getYear() != null
				&& empTimeReport.getEmpTimeSheetCompoundKey().getCompanyEmpId() != null) {
			empTimeReportEntities = entityManager.createNativeQuery(
					"SELECT timesheet.Type,MonthReport,YearReport,timesheet.EmpCompanyID,timesheet.CompanyProjectID,Day1,Day2,Day3,Day4,Day5,Day6,Day7,Day8,Day9,Day10,Day11,Day12,Day13,Day14,Day15,Day16,Day17,Day18,Day19,Day20,Day21,Day22,Day23,Day24,Day25,Day26,Day27,Day28,Day29,Day30,Day31,Total,employee.FirstName +' '+ employee.LastName as empName,pd.ProjectName FROM EmployeeTimesheetReport timesheet INNER JOIN Employee employee ON timesheet.EmpCompanyID = employee.EmpCompanyID inner join ProjectDetails pd on pd.CompanyProjectID = timesheet.CompanyProjectID where timeSheet.YearReport= :year and timeSheet.EmpCompanyID= :companyEmpId ",
					EmpTimeReportEntity.class)
					.setParameter("year", empTimeReport.getEmpTimeSheetCompoundKey().getYear())
					.setParameter("companyEmpId", empTimeReport.getEmpTimeSheetCompoundKey().getCompanyEmpId())
					.getResultList();
		} else if (empTimeReport.getEmpTimeSheetCompoundKey().getMonth() != null) {
			empTimeReportEntities = entityManager.createNativeQuery(
					"SELECT timesheet.Type,MonthReport,YearReport,timesheet.EmpCompanyID,timesheet.CompanyProjectID,Day1,Day2,Day3,Day4,Day5,Day6,Day7,Day8,Day9,Day10,Day11,Day12,Day13,Day14,Day15,Day16,Day17,Day18,Day19,Day20,Day21,Day22,Day23,Day24,Day25,Day26,Day27,Day28,Day29,Day30,Day31,Total,employee.FirstName +' '+ employee.LastName as empName,pd.ProjectName FROM EmployeeTimesheetReport timesheet INNER JOIN Employee employee ON timesheet.EmpCompanyID = employee.EmpCompanyID inner join ProjectDetails pd on pd.CompanyProjectID = timesheet.CompanyProjectID where MonthReport= :month ",
					EmpTimeReportEntity.class)
					.setParameter("month", empTimeReport.getEmpTimeSheetCompoundKey().getMonth()).getResultList();

		} else if (empTimeReport.getEmpTimeSheetCompoundKey().getCompanyEmpId() != null) {
			empTimeReportEntities = entityManager.createNativeQuery(
					"SELECT timesheet.Type,MonthReport,YearReport,timesheet.EmpCompanyID,timesheet.CompanyProjectID,Day1,Day2,Day3,Day4,Day5,Day6,Day7,Day8,Day9,Day10,Day11,Day12,Day13,Day14,Day15,Day16,Day17,Day18,Day19,Day20,Day21,Day22,Day23,Day24,Day25,Day26,Day27,Day28,Day29,Day30,Day31,Total,employee.FirstName +' '+ employee.LastName as empName,pd.ProjectName FROM EmployeeTimesheetReport timesheet INNER JOIN Employee employee ON timesheet.EmpCompanyID = employee.EmpCompanyID inner join ProjectDetails pd on pd.CompanyProjectID = timesheet.CompanyProjectID where timeSheet.EmpCompanyID= :companyEmpId",
					EmpTimeReportEntity.class)
					.setParameter("companyEmpId", empTimeReport.getEmpTimeSheetCompoundKey().getCompanyEmpId())
					.getResultList();
		} else if (empTimeReport.getEmpTimeSheetCompoundKey().getCompanyProjectId() != null) {
			empTimeReportEntities = entityManager.createNativeQuery(
					"SELECT timesheet.Type,MonthReport,YearReport,timesheet.EmpCompanyID,timesheet.CompanyProjectID,Day1,Day2,Day3,Day4,Day5,Day6,Day7,Day8,Day9,Day10,Day11,Day12,Day13,Day14,Day15,Day16,Day17,Day18,Day19,Day20,Day21,Day22,Day23,Day24,Day25,Day26,Day27,Day28,Day29,Day30,Day31,Total,employee.FirstName +' '+ employee.LastName as empName,pd.ProjectName FROM EmployeeTimesheetReport timesheet INNER JOIN Employee employee ON timesheet.EmpCompanyID = employee.EmpCompanyID inner join ProjectDetails pd on pd.CompanyProjectID = timesheet.CompanyProjectID where timeSheet.CompanyProjectID= :companyProjectId",
					EmpTimeReportEntity.class)
					.setParameter("companyProjectId", empTimeReport.getEmpTimeSheetCompoundKey().getCompanyProjectId())
					.getResultList();
		} else if (empTimeReport.getEmpTimeSheetCompoundKey().getYear() != null) {
			empTimeReportEntities = entityManager.createNativeQuery(
					"SELECT timesheet.Type,MonthReport,YearReport,timesheet.EmpCompanyID,timesheet.CompanyProjectID,Day1,Day2,Day3,Day4,Day5,Day6,Day7,Day8,Day9,Day10,Day11,Day12,Day13,Day14,Day15,Day16,Day17,Day18,Day19,Day20,Day21,Day22,Day23,Day24,Day25,Day26,Day27,Day28,Day29,Day30,Day31,Total,employee.FirstName +' '+ employee.LastName as empName,pd.ProjectName FROM EmployeeTimesheetReport timesheet INNER JOIN Employee employee ON timeSheet.EmpCompanyID = employee.EmpCompanyID inner join ProjectDetails pd on pd.CompanyProjectID = timesheet.CompanyProjectID where YearReport= :year",
					EmpTimeReportEntity.class)
					.setParameter("year", empTimeReport.getEmpTimeSheetCompoundKey().getYear()).getResultList();
			System.out.println("in repo");
			System.out.println(empTimeReportEntities);
		}

		try {
			String empTimeReportInString = objectMapper.writeValueAsString(empTimeReportEntities);
			timeReportsList = objectMapper.readValue(empTimeReportInString, new TypeReference<List<EmpTimeReport>>() {
			});
		} catch (Exception e) {

		}
		return timeReportsList;

	}
}
