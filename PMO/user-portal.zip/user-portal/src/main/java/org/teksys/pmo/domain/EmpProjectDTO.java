package org.teksys.pmo.domain;

import java.util.Date;

public class EmpProjectDTO {

    private int empProjectId;
    private ProjectDTO project;
    private RoleDTO role;
    private Employee employee;
    private TechnologyDTO technology;
    private String empProjectEmpId;
    private String empProjectProjectId;
    private String empProjectProjectRole;
    private Date empProjectStartDate;
    private Date empProjectEndDate;
    private String empProjectTechnologyId;
    private String billable;
    private String revenue;

    public int getEmpProjectId() {
        return empProjectId;
    }

    public void setEmpProjectId(int empProjectId) {
        this.empProjectId = empProjectId;
    }

    public ProjectDTO getProject() {
        return project;
    }

    public void setProject(ProjectDTO project) {
        this.project = project;
    }

    public RoleDTO getRole() {
        return role;
    }

    public void setRole(RoleDTO role) {
        this.role = role;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public TechnologyDTO getTechnology() {
        return technology;
    }

    public void setTechnology(TechnologyDTO technology) {
        this.technology = technology;
    }

    public String getEmpProjectEmpId() {
        return empProjectEmpId;
    }

    public void setEmpProjectEmpId(String empProjectEmpId) {
        this.empProjectEmpId = empProjectEmpId;
    }

    public String getEmpProjectProjectId() {
        return empProjectProjectId;
    }

    public void setEmpProjectProjectId(String empProjectProjectId) {
        this.empProjectProjectId = empProjectProjectId;
    }

    public String getEmpProjectProjectRole() {
        return empProjectProjectRole;
    }

    public void setEmpProjectProjectRole(String empProjectProjectRole) {
        this.empProjectProjectRole = empProjectProjectRole;
    }

    public Date getEmpProjectStartDate() {
        return empProjectStartDate;
    }

    public void setEmpProjectStartDate(Date empProjectStartDate) {
        this.empProjectStartDate = empProjectStartDate;
    }

    public Date getEmpProjectEndDate() {
        return empProjectEndDate;
    }

    public void setEmpProjectEndDate(Date empProjectEndDate) {
        this.empProjectEndDate = empProjectEndDate;
    }

    public String getEmpProjectTechnologyId() {
        return empProjectTechnologyId;
    }

    public void setEmpProjectTechnologyId(String empProjectTechnologyId) {
        this.empProjectTechnologyId = empProjectTechnologyId;
    }

    public String getBillable() {
        return billable;
    }

    public void setBillable(String billable) {
        this.billable = billable;
    }

    public String getRevenue() {
        return revenue;
    }

    public void setRevenue(String revenue) {
        this.revenue = revenue;
    }
}
