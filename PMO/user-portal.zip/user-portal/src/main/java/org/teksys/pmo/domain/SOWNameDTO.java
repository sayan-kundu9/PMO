package org.teksys.pmo.domain;

public class SOWNameDTO {
    private String projectSowId;
    private String companyProjectId;
    private String sowName;
    private String contentType;
    private String projectName;
    private byte[] sowContent;

    public String getCompanyProjectId() {
        return companyProjectId;
    }

    public String getProjectSowId() {
        return projectSowId;
    }

    public void setProjectSowId(String projectSowId) {
        this.projectSowId = projectSowId;
    }

    public void setCompanyProjectId(String companyProjectId) {
        this.companyProjectId = companyProjectId;
    }

    public String getSowName() {
        return sowName;
    }

    public void setSowName(String sowName) {
        this.sowName = sowName;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public byte[] getSowContent() {
        return sowContent;
    }

    public void setSowContent(byte[] sowContent) {
        this.sowContent = sowContent;
    }
}
