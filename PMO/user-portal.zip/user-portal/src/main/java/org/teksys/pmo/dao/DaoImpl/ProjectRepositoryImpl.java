package org.teksys.pmo.dao.DaoImpl;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.teksys.pmo.dao.ProjectRepositoryCustom;
import org.teksys.pmo.domain.ProjectDTO;
import org.teksys.pmo.model.Project;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Repository
public class ProjectRepositoryImpl implements ProjectRepositoryCustom {

    @Autowired
    EntityManager entityManager;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    EntityManagerFactory entityManagerFactory;

    @PersistenceContext
    private EntityManager em;
    //@Override
    public List<Project> findAll(int page) {

        TypedQuery query = em.createQuery("select * from ProjectDetails", Project.class);

        query.setFirstResult(page);
        return query.getResultList();
    }

    public List<Project> findProjects(ProjectDTO projectDTO) throws IOException {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Project> cq = cb.createQuery(Project.class);
        Root<Project> proj = cq.from(Project.class);
        List<Predicate> predicates = new ArrayList<Predicate>();
        if(StringUtils.isNotBlank(projectDTO.getProjectId()))
        predicates.add(cb.like(proj.get("projectId"),projectDTO.getProjectId()));
        if(StringUtils.isNotBlank(projectDTO.getCompanyProjectId()))
            predicates.add(cb.like(proj.get("companyProjectId"),projectDTO.getCompanyProjectId()));
        if(StringUtils.isNotBlank(projectDTO.getProjectName()))
            predicates.add(cb.like(proj.get("projectName"),projectDTO.getProjectName()));


//    if(projectDTO.getClientName()!=null)
//         predicates.add(cb.like(proj.get("clientName") , projectDTO.getClientName()));
        if(projectDTO.getClientId() != null)
            predicates.add(cb.like(proj.get("clientId"), projectDTO.getClientId()));

        if(projectDTO.getRegionName() !=null)
            predicates.add(cb.equal(proj.get("regionName") , projectDTO.getRegionName()));




        if(projectDTO.getSeName() != null)
            predicates.add(cb.equal(proj.get("seName"), projectDTO.getSeName()));

//        if(projectDTO.getBdm() != null)
//            predicates.add(cb.like(proj.get("bdm"), projectDTO.getBdm().getName()));

        if(projectDTO.getBdmName() != null)
            predicates.add(cb.equal(proj.get("bdmName"), projectDTO.getBdmName()));

        //Practices need to implemented

//        if(StringUtils.isNotBlank(project.get.toString()))
//            predicates.add(cb.like(proj.get("regionName"),project.getRegionName().toString()));

        cq.select(proj);
        cq.where(predicates.toArray(new Predicate[predicates.size()]));
        TypedQuery<Project> q = entityManager.createQuery(cq);
        List<Project> resultList = q.getResultList();
        return resultList;
    }




}























