package org.teksys.pmo.domain;

import org.teksys.pmo.model.ProjectPracticeMappingEntity;

import java.util.Set;

public class PracticeDTO {

    private String practiceId;

    private String practiceName;

    private String practiceHead;

    private String companyId;
    private Set<ProjectPracticeMappingEntity> projectPracticeMappings;

    public String getPracticeId() {
        return practiceId;
    }

    public void setPracticeId(String practiceId) {
        this.practiceId = practiceId;
    }

    public String getPracticeName() {
        return practiceName;
    }

    public void setPracticeName(String practiceName) {
        this.practiceName = practiceName;
    }

    public String getPracticeHead() {
        return practiceHead;
    }

    public void setPracticeHead(String practiceHead) {
        this.practiceHead = practiceHead;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public Set<ProjectPracticeMappingEntity> getProjectPracticeMappings() {
        return projectPracticeMappings;
    }

    public void setProjectPracticeMappings(Set<ProjectPracticeMappingEntity> projectPracticeMappings) {
        this.projectPracticeMappings = projectPracticeMappings;
    }
}
