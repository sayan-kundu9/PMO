package org.teksys.pmo.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "Practice" )
public class Practice {

    @Id
    @Column(name="PracticeID", nullable=false, unique=true)
    private String practiceId;

    @Column(name="PracticeName")
    private String practiceName;

    @Column(name="PracticeHead")
    private String practiceHead;

    @Column(name="CompanyID")
    private String companyId;
//
//    @OneToMany(cascade = {javax.persistence.CascadeType.ALL},fetch = FetchType.EAGER, mappedBy = "practice")
//    private Set<ProjectPracticeMappingEntity> projectPracticeMappings;
//
//    public Set<ProjectPracticeMappingEntity> getProjectPracticeMappings() {
//        return projectPracticeMappings;
//    }
//
//    public void setProjectPracticeMappings(Set<ProjectPracticeMappingEntity> projectPracticeMappings) {
//        this.projectPracticeMappings = projectPracticeMappings;
//    }
/*@OneToMany(
            mappedBy = "practice"
    )

    @JsonManagedReference
    private Set<EmployeeEntity> employees;

    public Set<EmployeeEntity> getEmployees() {
        return employees;
    }

    public void setEmployees(Set<EmployeeEntity> employees) {
        this.employees = employees;
    }*/





    public String getPracticeId() {
        return practiceId;
    }

    public void setPracticeId(String practiceId) {
        this.practiceId = practiceId;
    }

    public String getPracticeName() {
        return practiceName;
    }

    public void setPracticeName(String practiceName) {
        this.practiceName = practiceName;
    }

    public String getPracticeHead() {
        return practiceHead;
    }

    public void setPracticeHead(String practiceHead) {
        this.practiceHead = practiceHead;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }
}
