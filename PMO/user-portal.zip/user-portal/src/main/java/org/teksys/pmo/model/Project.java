package org.teksys.pmo.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import org.teksys.pmo.domain.PracticeDTO;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;
import javax.persistence.*;

@Entity
@Table(name = "ProjectDetails ")
public class Project implements Serializable {


    @Id

    @Column(name = "CompanyProjectID", nullable = false, unique = true)
    private String companyProjectId;
    @Column(name = "ProjectID")
    private String projectId;
    @ManyToOne
    @JoinColumn(name = "ClientID", insertable = false, updatable = false)
    private Client client;
    @ManyToOne
    @JoinColumn(name = "RegionId", insertable = false, updatable = false)
    private Region region;
    @ManyToOne
    @JoinColumn(name = "BDMId", insertable = false, updatable = false)
    private BDM bdm;
    @ManyToOne
    @JoinColumn(name = "SEId", insertable = false, updatable = false)
    private SolutionExecutive solutionExecutive;


    //    @OneToMany(mappedBy="project")
//        private Set<ProjectRoleBilling> projectRoleBillings;

//        @OneToMany(mappedBy="project")
//        private Set<ProjectBidDetails> projectBidDetailses;

    @JsonManagedReference
    @OneToMany(cascade = {javax.persistence.CascadeType.ALL},fetch = FetchType.EAGER, mappedBy = "project")
    private Set<ProjectPracticeMappingEntity> projectPracticeMappings;

    public Set<ProjectPracticeMappingEntity> getProjectPracticeMappings() {
        return projectPracticeMappings;
    }

    public void setProjectPracticeMappings(Set<ProjectPracticeMappingEntity> projectPracticeMappings) {
        this.projectPracticeMappings = projectPracticeMappings;
    }
    //        @OneToMany(mappedBy="project", cascade={javax.persistence.CascadeType.REMOVE})
//        private Set<ProjectSow> projectSowSet;


//    @OneToMany(fetch=FetchType.LAZY, cascade={javax.persistence.CascadeType.ALL})
//    @JoinColumn(name="CompanyProjectID")
//    public Set<ProjectPracticeMapping> projectPracticeMappings;


//   public Set<EmpProject> getEmpProjects() {
//        return empProjects;
//    }

    @JsonBackReference(value = "projects")
    @OneToMany(mappedBy="project")
    private Set<EmpProject> empProjects;

    public Set<EmpProject> getEmpProjects() {
        return empProjects;
    }

    public void setEmpProjects(Set<EmpProject> empProjects) {
        this.empProjects = empProjects;
    }

    @Column(name = "ProjectName")
    private String projectName;
    @Temporal(TemporalType.DATE)
    @Column(name = "ProjectStartDate")
    private Date startDate;
    @Temporal(TemporalType.DATE)
    @Column(name = "ProjectEndDate")
    private Date endDate;


    @Column(name = "ClientID")
    private String clientId;

    @Column(name = "clientName")
    private String clientName;

    @Column(name = "RegionId")
    private Integer regionName;
    @Column(name = "BDMId")
    private Integer bdmName;
    @Column(name = "SEId")
    private Integer seName;
    @Column(name = "CreatedBy")
    private String createdBy;
    @Column(name = "CreatedDate")
    private Date dateCreated;
    @Column(name = "ModifiedBy")
    private String modifiedBy;
    @Column(name = "ModifiedDate")
    private Date dateModified;
    @Column(name = "Type")
    private char type;
    @Column(name = "ProjectAnalyst")
    private String projectAnalyst;
    @Column(name = "Email")
    private String email;
    @Column(name = "Contact")
    private String contact;


    //    public void setEmpProjects(Set<EmpProject> empProjects) {
//        this.empProjects = empProjects;
//    }


    public BDM getBdm() {
        return bdm;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public void setBdm(BDM bdm) {
        this.bdm = bdm;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }


    public SolutionExecutive getSolutionExecutive() {
        return solutionExecutive;
    }

    public void setSolutionExecutive(SolutionExecutive solutionExecutive) {
        this.solutionExecutive = solutionExecutive;
    }

    public Region getRegion() {
        return region;
    }

    public void setRegion(Region region) {
        this.region = region;
    }

    public void setCompanyProjectId(String companyProjectId) {
        this.companyProjectId = companyProjectId;
    }

    public String getCompanyProjectId() {
        return this.companyProjectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getProjectId() {
        return this.projectId;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectName() {
        return this.projectName;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Date getEndDate() {
        return this.endDate;
    }

//    public void setClientName(String clientName) {
//        this.clientName = clientName;
//    }
//
//    public String getClientName() {
//        return this.clientName;
//    }


    public void setRegionName(Integer regionName) {
        this.regionName = regionName;
    }

    public Integer getRegionName() {
        return this.regionName;
    }

    public void setBdmName(Integer bdmName) {
        this.bdmName = bdmName;
    }

    public Integer getBdmName() {
        return this.bdmName;
    }

    public void setSeName(Integer seName) {
        this.seName = seName;
    }

    public Integer getSeName() {
        return this.seName;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateCreated() {
        return this.dateCreated;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getModifiedBy() {
        return this.modifiedBy;
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified;
    }

    public Date getDateModified() {
        return this.dateModified;
    }

    public void setType(char type) {
        this.type = type;
    }

    public char getType() {
        return this.type;
    }

    public void setProjectAnalyst(String projectAnalyst) {
        this.projectAnalyst = projectAnalyst;
    }

    public String getProjectAnalyst() {
        return this.projectAnalyst;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return this.email;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getContact() {
        return this.contact;
    }



}