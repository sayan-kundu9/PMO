package org.teksys.pmo.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.teksys.encryption.converters.StringRSAConverter;

@Entity
@Table(name = "EmployeeSalaryPerHour")
public class EmployeeSalaryPerHour implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "EmployeeSalaryPerHourID", nullable = false, unique = true)
	private int id;
	@Column(name = "EmpCompanyID")
	private String companyEmpId;
	@Column(name = "EffectiveDate")
	private Date effectiveDate;
	@Column(name = "SalaryPerHour")
	@Convert(converter = StringRSAConverter.class)
	private String salaryPerHour;
	@Column(name = "CurrentTimeStamp")
	private Timestamp currentTimeStamp;
	@ManyToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	@JoinColumn(name = "EmpCompanyID", insertable = false, updatable = false)
	private EmployeeEntity employee;

	@Transient
	private String effDate;
	@Transient
	private int rowNo;
	@Transient
	private String columnNo;
	@Transient
	private String errorMsg;

	public EmployeeSalaryPerHour() {
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return this.id;
	}

	public void setCompanyEmpId(String companyEmpId) {
		this.companyEmpId = companyEmpId;
	}

	public String getCompanyEmpId() {
		return this.companyEmpId;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getEffectiveDate() {
		return this.effectiveDate;
	}

	public void setSalaryPerHour(String salaryPerHour) {
		this.salaryPerHour = salaryPerHour;
	}

	public String getSalaryPerHour() {
		return this.salaryPerHour;
	}

	public void setEmployee(EmployeeEntity employee) {
		this.employee = employee;
	}

	public EmployeeEntity getEmployee() {
		return this.employee;
	}

	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}

	public String getEffDate() {
		return this.effDate;
	}

	public void setRowNo(int rowNo) {
		this.rowNo = rowNo;
	}

	public int getRowNo() {
		return this.rowNo;
	}

	public void setColumnNo(String columnNo) {
		this.columnNo = columnNo;
	}

	public String getColumnNo() {
		return this.columnNo;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getErrorMsg() {
		return this.errorMsg;
	}

	public Timestamp getCurrentTimeStamp() {
		return currentTimeStamp;
	}

	public void setCurrentTimeStamp(Timestamp currentTimeStamp) {
		this.currentTimeStamp = currentTimeStamp;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((companyEmpId == null) ? 0 : companyEmpId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeSalaryPerHour other = (EmployeeSalaryPerHour) obj;
		if (companyEmpId == null) {
			if (other.companyEmpId != null)
				return false;
		} else if (!companyEmpId.equals(other.companyEmpId))
			return false;
		return true;
	}
}
