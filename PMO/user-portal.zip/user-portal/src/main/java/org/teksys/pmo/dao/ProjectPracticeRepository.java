package org.teksys.pmo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.teksys.pmo.model.ProjectPracticeMappingEntity;

import java.util.List;

public interface ProjectPracticeRepository extends JpaRepository<ProjectPracticeMappingEntity, Integer> {
    @Override
    List<ProjectPracticeMappingEntity> findAll();
}
