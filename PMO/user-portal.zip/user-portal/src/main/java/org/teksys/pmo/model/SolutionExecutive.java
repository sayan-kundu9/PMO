package org.teksys.pmo.model;
import java.io.Serializable;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="SolutionExecutive")
public class SolutionExecutive implements Serializable{

    @Id
    @Column(name="SEId", nullable=false, unique=true)
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int seId;
    @Column(name="Name")
    private String name;
//    @OneToMany(mappedBy="solutionExecutive")
//    private Set<ProjectDTO> projects;

    public void setSeId(int seId)
    {
        this.seId = seId;
    }

    public int getSeId()
    {
        return this.seId;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return this.name;
    }

}
