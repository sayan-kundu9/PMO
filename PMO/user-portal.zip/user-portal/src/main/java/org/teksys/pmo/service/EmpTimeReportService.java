package org.teksys.pmo.service;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.teksys.pmo.dao.EmpTimeReportRepository;
import org.teksys.pmo.domain.EmpTimeReport;
import org.teksys.pmo.model.EmpTimeReportEntity;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

@Service
public class EmpTimeReportService {
    private static final Logger logger = Logger.getLogger(EmpTimeReportService.class);

    @Autowired
    private EmpTimeReportRepository empTimeReportDao;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private EntityManager entityManager;

    public List<EmpTimeReport> findAllEmpTimeReports() {
        List<EmpTimeReport> timeReportsList = new ArrayList<EmpTimeReport>();
        List<EmpTimeReportEntity> timeReports = new ArrayList<EmpTimeReportEntity>();

        try {
            Query query = entityManager.createNativeQuery(" SELECT timeSheet.Type,timeSheet.MonthReport,timeSheet.YearReport,timeSheet.EmpCompanyID,timeSheet.CompanyProjectID,timeSheet.Day1,timeSheet.Day2,timeSheet.Day3,timeSheet.Day4,timeSheet.Day5,timeSheet.Day6,timeSheet.Day7,timeSheet.Day8,timeSheet.Day9,timeSheet.Day10,timeSheet.Day11,timeSheet.Day12,timeSheet.Day13,timeSheet.Day14,timeSheet.Day15,timeSheet.Day16,timeSheet.Day17,timeSheet.Day18,timeSheet.Day19,timeSheet.Day20,timeSheet.Day21,timeSheet.Day22,timeSheet.Day23,timeSheet.Day24,timeSheet.Day25,timeSheet.Day26,timeSheet.Day27,timeSheet.Day28,timeSheet.Day29,timeSheet.Day30,timeSheet.Day31,timeSheet.Total,employee.FirstName +' '+ employee.LastName as empName, pd.ProjectName as projectName FROM EmployeeTimesheetReport timeSheet INNER JOIN Employee employee ON timeSheet.EmpCompanyID = employee.EmpCompanyID INNER JOIN ProjectDetails pd ON timeSheet.CompanyProjectID = pd.CompanyProjectID",EmpTimeReportEntity.class);
            query.setMaxResults(20);

            List<EmpTimeReportEntity> timeReports1 = query.getResultList();
            String employeeListInString =  objectMapper.writeValueAsString(timeReports1);
            timeReportsList =  objectMapper.readValue(employeeListInString, new TypeReference<List<EmpTimeReport>>(){});

        } catch (Exception ex) {

        }
        return timeReportsList;
    }

    public List<EmpTimeReport> searchEmpTimeSheet(EmpTimeReport empTimeReport) throws JsonProcessingException {
        String empTimeReportInString = objectMapper.writeValueAsString( empTimeReportDao.searchEmpTimeSheet(empTimeReport));
        List<EmpTimeReport> timeReports = new ArrayList<EmpTimeReport>();
        try {
            timeReports = objectMapper.readValue(empTimeReportInString, new TypeReference<List<EmpTimeReport>>(){});
        } catch (IOException e) {
            logger.error("error when try to find employee :"+e);
        }
        return timeReports;
    }
}
