package org.teksys.pmo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.teksys.pmo.Response.ApiResponse;
import org.teksys.pmo.domain.ExpensesDTO;
import org.teksys.pmo.domain.PracticeExpenseDTO;
import org.teksys.pmo.service.PracticeService;

import java.util.List;

@RestController
public class PracticeController {

    @Autowired
    private PracticeService practiceService;

    @GetMapping("/findAllPracticeExpenses")
    public List<PracticeExpenseDTO> findAllPracticeExpenses() {
        return practiceService.findAllPracticeExpenses();
    }

    @GetMapping("/findAllExpenses")
    public List<ExpensesDTO> findAllExpenses() {
        return practiceService.findAllExpenses();
    }

    @PostMapping("/savePracticeExpense")
    public void saveProjectContent(@RequestBody PracticeExpenseDTO practiceExpenseDTO) {

        practiceService.savePracticeExpense(practiceExpenseDTO);
    }

    @PostMapping("/updatePracticeExpense")
    public void updatePracticeExpense(@RequestBody PracticeExpenseDTO practiceExpenseDTO) {
        practiceService.updatePracticeExpenseById(practiceExpenseDTO);
    }

}
