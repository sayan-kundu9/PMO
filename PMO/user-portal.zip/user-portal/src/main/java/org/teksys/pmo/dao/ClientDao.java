package org.teksys.pmo.dao;

import org.springframework.data.repository.CrudRepository;
import org.teksys.pmo.model.Client;
import org.teksys.pmo.model.Region;

import java.util.List;

public interface ClientDao extends CrudRepository<Client, String> {

    @Override
    List<Client> findAll();
}
