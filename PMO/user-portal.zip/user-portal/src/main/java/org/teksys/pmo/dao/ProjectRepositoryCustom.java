package org.teksys.pmo.dao;

import org.teksys.pmo.domain.ProjectDTO;
import org.teksys.pmo.model.Project;

import java.io.IOException;
import java.util.List;

public interface ProjectRepositoryCustom {
      List<Project> findProjects(ProjectDTO projectDTO) throws IOException;
}


