package org.teksys.pmo.domain;

import java.io.Serializable;
import java.util.Set;

public class PracticePortlet implements Serializable {
    private int id;
    private String practiceHead;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPracticeHead() {
        return practiceHead;
    }

    public void setPracticeHead(String practiceHead) {
        this.practiceHead = practiceHead;
    }

    public Set<PracticeManagementDTO> getPracticeManagementDTOS() {
        return practiceManagementDTOS;
    }

    public void setPracticeManagementDTOS(Set<PracticeManagementDTO> practiceManagementDTOS) {
        this.practiceManagementDTOS = practiceManagementDTOS;
    }

    private Set<PracticeManagementDTO> practiceManagementDTOS;

}
