package org.teksys.pmo.model;


import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@Entity
@Table(
        name = "Role"
)
public class Role implements Serializable{


    @Id
    @Column(
            name = "RoleID",
            nullable = false,
            unique = true
    )
    private String roleId;
    @Column(
            name = "RoleName"
    )
    private String roleName;
    /*@OneToMany(
            mappedBy = "role"
    )

    private Set<EmployeeEntity> employees;*/
    @OneToMany(
            mappedBy = "role"
    )
    private Set<ProjectRoleBilling> projectRoleBillings;
    /*@OneToMany(
            mappedBy = "role"
    )
    private Set<EmpProject> empProjects;*/

    public Role() {
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getRoleId() {
        return this.roleId;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getRoleName() {
        return this.roleName;
    }

    /*public void setEmployees(Set<EmployeeEntity> employees) {
        this.employees = employees;
    }

    public Set<EmployeeEntity> getEmployees() {
        return this.employees;
    }*/

    public void setProjectRoleBillings(Set<ProjectRoleBilling> projectRoleBillings) {
        this.projectRoleBillings = projectRoleBillings;
    }

    public Set<ProjectRoleBilling> getProjectRoleBillings() {
        return this.projectRoleBillings;
    }

    /*public void setEmpProjects(Set<EmpProject> empProjects) {
        this.empProjects = empProjects;
    }

    public Set<EmpProject> getEmpProjects() {
        return this.empProjects;
    }*/
}


