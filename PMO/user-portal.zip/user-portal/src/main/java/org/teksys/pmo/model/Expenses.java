package org.teksys.pmo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Expenses" )
public class Expenses {

    @Id
    @Column(name="ExpensesID", nullable=false, unique=true)
    private String expensesId;

    @Column(name="ExpensesName")
    private String expensesName;

    public String getExpensesId() {
        return expensesId;
    }

    public void setExpensesId(String expensesId) {
        this.expensesId = expensesId;
    }

    public String getExpensesName() {
        return expensesName;
    }

    public void setExpensesName(String expensesName) {
        this.expensesName = expensesName;
    }
}
