package org.teksys.pmo.dao;

import org.teksys.pmo.domain.ClientDTO;

import java.util.List;

public interface ClientRepositoryCustom {
    //List<ClientDTO> updateClientById(ClientDTO clientDTO, Integer id);
}
