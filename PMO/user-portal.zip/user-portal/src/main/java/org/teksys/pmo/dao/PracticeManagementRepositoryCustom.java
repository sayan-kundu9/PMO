package org.teksys.pmo.dao;

import org.teksys.pmo.domain.PracticeManagementDTO;

import java.util.List;

public interface PracticeManagementRepositoryCustom {
     List<PracticeManagementDTO> updateById(PracticeManagementDTO practiceManagementDTO);
}
