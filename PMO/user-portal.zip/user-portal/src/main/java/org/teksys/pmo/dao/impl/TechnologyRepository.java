package org.teksys.pmo.dao.impl;

import org.springframework.data.jpa.repository.JpaRepository;
import org.teksys.pmo.model.Technology;

import java.util.Optional;

//import org.springframework.data.repository.query.Param;

public interface TechnologyRepository extends JpaRepository<Technology,String> {

    Optional<Technology> findByTechnologyName(String technologyName);


}
