package org.teksys.pmo.model;


import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


@Entity
@Table(name = "PracticeExpenses")
public class PracticeExpense implements Serializable {

    @Id
    @Column(name = "PracticeExpensesID", nullable = false, unique = true)
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer practiceExpenseId;

    @ManyToOne
    @JoinColumn(name="PracticeID", insertable=false, updatable=false)
    private Practice practice;

    @Column(name = "PracticeID")
    private String practiceId;

    @ManyToOne
    @JoinColumn(name="ExpensesID", insertable=false, updatable=false)
    private Expenses expenses;

    @Column(name = "ExpensesID")
    private String expensesId;

    @Column(name = "Amount")
    private Double amount;

    @Column(name = "CurrencyName")
    private String currency_name;

    @Column(name = "ExpensesDescription")
    private String expenses_description;


    @Column(name = "DateOfExpense")
    private Date dateOfExpense;


    @Column(name = "Planned")
    private String planned;

    public Integer getPracticeExpenseId() {
        return practiceExpenseId;
    }

    public void setPracticeExpenseId(Integer practiceExpenseId) {
        this.practiceExpenseId = practiceExpenseId;
    }

    public String getPracticeId() {
        return practiceId;
    }

    public void setPracticeId(String practiceId) {
        this.practiceId = practiceId;
    }

    public String getExpensesId() {
        return expensesId;
    }

    public void setExpensesId(String expensesId) {
        this.expensesId = expensesId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getCurrency_name() {
        return currency_name;
    }

    public void setCurrency_name(String currency_name) {
        this.currency_name = currency_name;
    }

    public String getExpenses_description() {
        return expenses_description;
    }

    public void setExpenses_description(String expenses_description) {
        this.expenses_description = expenses_description;
    }

    public Date getDateOfExpense() {
        return dateOfExpense;
    }

    public void setDateOfExpense(Date dateOfExpense) {
        this.dateOfExpense = dateOfExpense;
    }

    public String getPlanned() {
        return planned;
    }

    public void setPlanned(String planned) {
        this.planned = planned;
    }

    public Practice getPractice() {
        return practice;
    }

    public void setPractice(Practice practice) {
        this.practice = practice;
    }

    public Expenses getExpenses() {
        return expenses;
    }

    public void setExpenses(Expenses expenses) {
        this.expenses = expenses;
    }

    public PracticeExpense(){

    }

    public PracticeExpense(Integer practiceExpenseId, String practiceId, String expensesId, Double amount, String currency_name, String expenses_description, Date dateOfExpense, String planned){

        this.practiceExpenseId = practiceExpenseId;
        this.practiceId = practiceId;
        this.expensesId = expensesId;
        this.amount = amount;
        this.dateOfExpense = dateOfExpense;
        this.expenses_description = expenses_description;
        this.currency_name = currency_name;
        this.planned = planned;

    }

}
