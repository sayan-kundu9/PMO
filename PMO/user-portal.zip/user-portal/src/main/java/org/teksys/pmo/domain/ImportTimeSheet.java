package org.teksys.pmo.domain;
import java.io.Serializable;
import java.util.Date;

public class ImportTimeSheet implements Serializable {
    private int id;
    private String fileName;
    private String createdBy;
    private Date dateCreated;
    private String modifiedBy;
    private Date dateModified;

    public ImportTimeSheet(){}

    public ImportTimeSheet(int id, String fileName, String createdBy, Date dateCreated, String modifiedBy, Date dateModified) {
        this.id = id;
        this.fileName = fileName;
        this.createdBy = createdBy;
        this.dateCreated = dateCreated;
        this.modifiedBy = modifiedBy;
        this.dateModified = dateModified;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return this.id;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileName() {
        return this.fileName;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateCreated() {
        return this.dateCreated;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getModifiedBy() {
        return this.modifiedBy;
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = dateModified;
    }

    public Date getDateModified() {
        return this.dateModified;
    }
}
