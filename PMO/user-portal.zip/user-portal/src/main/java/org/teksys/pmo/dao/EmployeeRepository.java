package org.teksys.pmo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.teksys.pmo.domain.EmpProjectDTO;
import org.teksys.pmo.model.EmpProject;
import org.teksys.pmo.model.EmployeeEntity;
//import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<EmployeeEntity,String>,EmployeeRepositoryCustom {

    EmployeeEntity findByCompanyEmpId(String companyEmpId);
    @Query("select firstName,companyEmpId from EmployeeEntity")
    List<EmployeeEntity> findEmpName();

}
