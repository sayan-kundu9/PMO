package org.teksys.pmo.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


@Entity
@Table(
        name = "ProjectRoleBillHours"
)
public class ProjectRoleBilling implements Serializable{

    @Id
    @Column(
            name = "ProjectRoleID",
            nullable = false,
            unique = true
    )
    @GeneratedValue(
            strategy = GenerationType.AUTO
    )
    private int id;
    @ManyToOne
    @JoinColumn(
            name = "CompanyProjectID",
            insertable = false,
            updatable = false
    )
    private Project project;
    @ManyToOne
    @JoinColumn(
            name = "RoleID",
            insertable = false,
            updatable = false
    )
    @JsonBackReference
    private Role role;
    @Column(
            name = "CompanyProjectID"
    )
    private String projectId;
    @Column(
            name = "RoleID"
    )
    private String roleId;
    @Column(
            name = "BillingAmount"
    )
    private Double billingAmount;
    @Column(
            name = "CurrencyName"
    )
    private String currency_name;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(
            name = "BillableDate",
            nullable = true
    )
    private Date billableDate;
    @Transient
    private String billableDateStr;
    @Transient
    private String projectName;
    @Transient
    private String roleName;
    @Transient
    private String delete;

    public ProjectRoleBilling() {
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return this.id;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public Project getProject() {
        return this.project;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Role getRole() {
        return this.role;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getProjectId() {
        return this.projectId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getRoleId() {
        return this.roleId;
    }

    public void setBillingAmount(Double billingAmount) {
        this.billingAmount = billingAmount;
    }

    public Double getBillingAmount() {
        return this.billingAmount;
    }

    public void setCurrency_name(String currency_name) {
        this.currency_name = currency_name;
    }

    public String getCurrency_name() {
        return this.currency_name;
    }

    public void setBillableDate(Date billableDate) {
        this.billableDate = billableDate;
    }

    public Date getBillableDate() {
        return this.billableDate;
    }

    public void setBillableDateStr(String billableDateStr) {
        this.billableDateStr = billableDateStr;
    }

    public String getBillableDateStr() {
        return this.billableDateStr;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectName() {
        return this.projectName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getRoleName() {
        return this.roleName;
    }

    public void setDelete(String delete) {
        this.delete = delete;
    }

    public String getDelete() {
        return this.delete;
    }


}
