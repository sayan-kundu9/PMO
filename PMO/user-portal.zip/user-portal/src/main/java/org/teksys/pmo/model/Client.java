package org.teksys.pmo.model;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name="Client")
public class Client implements Serializable{

    @Id
    @Column(name="ClientID", nullable=false, unique=true)
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer id;
    @Column(name="ClientName")
    private String clientName;
//    @OneToMany(mappedBy="client")
//    private Set<Project> projects;

    public Client() {
    }

    public Client(Integer id, String clientName) {
        this.id = id;
        this.clientName = clientName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

}
