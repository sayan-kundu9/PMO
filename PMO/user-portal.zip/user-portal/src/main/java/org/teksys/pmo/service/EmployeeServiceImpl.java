package org.teksys.pmo.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.codec.binary.Hex;
import org.hibernate.type.descriptor.sql.LongVarbinaryTypeDescriptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.teksys.pmo.dao.EmployeeCvRepo;
import org.teksys.pmo.dao.EmployeeRepository;
import org.teksys.pmo.dao.EmployeeSalaryPerHourRepository;
import org.teksys.pmo.dao.EmployeeSalaryPerHourRepositoryCustom;
import org.teksys.pmo.domain.Employee;
import org.teksys.pmo.domain.EmployeeAllDetails;
import org.teksys.pmo.domain.EmployeeSalaryPerHourDTO;
import org.teksys.pmo.exception.FileStorageException;
import org.teksys.pmo.model.EmployeeCV;
import org.teksys.pmo.model.EmployeeEntity;
import org.teksys.pmo.model.EmployeeSalaryPerHour;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    private static final Logger logger = Logger.getLogger(EmployeeServiceImpl.class);

    @Autowired
    private EmployeeRepository employeeDao;

    @Autowired
    private EmployeeSalaryPerHourRepository empSalDao;

@Autowired
private EmployeeCvRepo employeeCvRepo;
    @Autowired
    private EmployeeSalaryPerHourRepositoryCustom empSalCustDao;

    @Autowired
    ObjectMapper objectMapper;
    public static final String MODIFIED_BY= "DefaultUser";

    public List<Employee> findEmpByLocation(String location) {
        return employeeDao.searchEmployee(location);
    }

    public List<EmployeeAllDetails> getAllEmployees(){
        List<EmployeeAllDetails> employees = new ArrayList<EmployeeAllDetails>();

        employees = employeeDao.getAllEmployees();

        return employees;
    }



    public List<EmployeeEntity> findAllEmployees() {
        List<EmployeeEntity> employeeList = new ArrayList<>();
        try {
            //List<Employee> employees = new ArrayList<Employee>();
            employeeList = employeeDao.findAll();
            //String employeeListInString =  objectMapper.writeValueAsString(employeeList);
            //employees =  objectMapper.readValue(employeeListInString, new TypeReference<List<Employee>>(){});

        } catch (Exception ex) {

        }
        return employeeList;
    }

 public List<Employee> findEmployees(Employee employee) throws IOException
    {
        List<Employee> employees = new ArrayList<Employee>();
        if(employee.getProjectName()!=null){
            //String employeeAsString = objectMapper.writeValueAsString(employeeDao.findEmployeeByAll(employee));
            //employees = objectMapper.readValue(employeeAsString,new TypeReference<List<Employee>>(){});
            return employeeDao.findEmployeeByAll(employee);
        }
        else{
            String employeeAsString = objectMapper.writeValueAsString(employeeDao.findEmployees(employee));
            employees = objectMapper.readValue(employeeAsString,new TypeReference<List<Employee>>(){});
            return employees;
        }
    }

    @Override
    public List<Employee> findEmployeesWithSpecificData(Employee employee) {
        try {
            List<Employee> employees = new ArrayList<Employee>();
            String employeeAsString = objectMapper.writeValueAsString(employeeDao.findEmployeesWithSpecificData(employee));
            employees = objectMapper.readValue(employeeAsString,new TypeReference<List<Employee>>(){});
            return employees;
        } catch (IOException e) {
            logger.error("error when try to find employee :"+e);
        }
        return null;
    }


    public List<Employee> searchEmployee(Employee employee) throws IOException{
        List<Employee> employees = new ArrayList<Employee>();
        return employeeDao.findEmployeeByAll(employee);
    }



    public void addEmployee(Employee employee) {
        try {
            EmployeeEntity entity = new EmployeeEntity();
            entity.setCompanyEmpId(employee.getCompanyEmpId());
            entity.setEmpId(employee.getEmpId());
            entity.setFirstName(employee.getFirstName());
            entity.setLastName(employee.getLastName());
            entity.setTitle(employee.getTitle());
            entity.setBusinessLine(Integer.parseInt(employee.getBusinessLine()));
            entity.setReportingTo(employee.getReportingTo());
            entity.setHireDate(employee.getHireDate());
            entity.setTermination(employee.getTermination());
            entity.setLocation(employee.getLocation());
            entity.setSalary(employee.getSalary());
            entity.setOfficePhone(employee.getOfficePhone());
            entity.setMobilePhone(employee.getMobilePhone());
            entity.setTekEmail(employee.getTekEmail());
            entity.setAlternateEmail(employee.getAlternateEmail());
            entity.setCoe(employee.getCoe());
//        entity.setCreatedBy(employee.getCreatedBy());
            entity.setDateCreated(employee.getDateCreated());
            entity.setModifiedBy(employee.getModifiedBy());
//        entity.setDateModified(employee.getDateModified());
            entity.setType(employee.isType());
            entity.setEmployeeSalaryPerHours(employee.getEmployeeSalaryPerHours());

            employeeDao.save(entity);
        } catch  (Exception ex){ }
    }

    public EmployeeEntity editEmployee (EmployeeEntity editEmployee) {

        EmployeeEntity editEmployee1 = employeeDao.findByCompanyEmpId(editEmployee.getCompanyEmpId());
        editEmployee1.setTermination(editEmployee.getTermination());
        editEmployee1.setReportingTo(editEmployee.getReportingTo());
        editEmployee1.setType(editEmployee.isType());
        editEmployee1.setDateCreated(new Date());
        editEmployee1.setModifiedBy(MODIFIED_BY);
        return employeeDao.save(editEmployee1);
    }

    @Override
    public void addEmpSal(EmployeeSalaryPerHour employeeSalaryPerHour) {

        List<EmployeeSalaryPerHour> employeeSalaryPerHour1 = empSalDao.findByCompanyEmpId(employeeSalaryPerHour.getCompanyEmpId());

        employeeSalaryPerHour1.add(employeeSalaryPerHour);
         empSalDao.save(employeeSalaryPerHour1);

    }

    @Override
    public List<EmployeeSalaryPerHourDTO> historyOfDL(EmployeeSalaryPerHourDTO employeeSalaryPerHourDTO) {
        List<EmployeeSalaryPerHourDTO> dl = new ArrayList<EmployeeSalaryPerHourDTO>();
        try{
            List<EmployeeSalaryPerHour> dlList = empSalCustDao.historyOfDL(employeeSalaryPerHourDTO);
            String dlListInString = objectMapper.writeValueAsString(dlList);
            dl = objectMapper.readValue(dlListInString, new TypeReference<List<EmployeeSalaryPerHourDTO>>() {
            });
        }
        catch (Exception ex) {

        }

        return dl;
    }

    @Override
    public List<EmployeeSalaryPerHourDTO> employeeDL(EmployeeSalaryPerHourDTO employeeSalaryPerHourDTO) {
        List<EmployeeSalaryPerHourDTO> empDl = new ArrayList<EmployeeSalaryPerHourDTO>();
        try{
            List<EmployeeSalaryPerHour> dlList = empSalCustDao.employeeDL(employeeSalaryPerHourDTO);
            String dlListInString = objectMapper.writeValueAsString(dlList);
            empDl = objectMapper.readValue(dlListInString, new TypeReference<List<EmployeeSalaryPerHourDTO>>() {
            });
        }
        catch (Exception ex) {

        }
        return empDl;
    }

public EmployeeCV storeFile(MultipartFile file,String empComId) {
    // Normalize file name
    String fileName = StringUtils.cleanPath(file.getOriginalFilename());

    Integer empIdCount = employeeCvRepo.empIdExists(empComId);
    if(empIdCount > 0){
        System.out.println("employee cv exists");
        employeeCvRepo.deleteEmployeeCv(empComId);
        storeFile(file, empComId);
    }

    else {
        try {
            System.out.println(file.getContentType());
            if (file.getContentType() == "application/msword") {
              File word = new File("C:/Users/umadeeha/Desktop/cv1.doc");
                byte[] b = new byte[(int) word.length()];
               FileInputStream fileInputStream = new FileInputStream(word);
               fileInputStream.read(b);
               for (int i = 0; i < b.length; i++) {
                           System.out.print((char)b[i]);
                }
            } else {
                EmployeeCV cv = new EmployeeCV();
                cv.setCvName(fileName);
                cv.setCvContent(file.getBytes());
                cv.setType(file.getContentType());
                cv.setEmpCompanyId(empComId);
                return employeeCvRepo.save(cv);
            }
            } catch(Exception ex){
                throw new FileStorageException("Could not store file " + fileName + ". Please try again!", ex);
            }
    }
    return null;
}
    public void deleteEmployeeCv(String empCompanyId ) {
         employeeCvRepo.deleteEmployeeCv(empCompanyId);
    }
public byte[] downloadFile(String empCompanyId) {
    return employeeCvRepo.findCvByEmpId(empCompanyId);
}
}
