package org.teksys.pmo.dao;

import org.springframework.data.repository.CrudRepository;
import org.teksys.pmo.model.Expenses;
import org.teksys.pmo.model.PracticeExpense;

import java.util.List;

public interface ExpensesDao extends CrudRepository<Expenses, Integer> {

    @Override
    List<Expenses> findAll();

}
