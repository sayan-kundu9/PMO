package org.teksys.pmo.domain;

public class SOWDTO {
    private String companyProjectId;
    private String projectName;

    public String getCompanyProjectId() {
        return companyProjectId;
    }

    public void setCompanyProjectId(String companyProjectId) {
        this.companyProjectId = companyProjectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }
}
