package org.teksys.pmo.domain;

import org.teksys.pmo.model.EmployeeEntity;

public class EmployeeCV {
    private int cvId;
    private String empCompanyId;
    private String cvName;
    private byte[] cvContent;
    private String type;
    private EmployeeEntity employee;

    public int getCvId() {
        return cvId;
    }

    public void setCvId(int cvId) {
        this.cvId = cvId;
    }

    public String getEmpCompanyId() {
        return empCompanyId;
    }

    public void setEmpCompanyId(String empCompanyId) {
        this.empCompanyId = empCompanyId;
    }

    public String getCvName() {
        return cvName;
    }

    public void setCvName(String cvName) {
        this.cvName = cvName;
    }

    public byte[] getCvContent() {
        return cvContent;
    }

    public void setCvContent(byte[] cvContent) {
        this.cvContent = cvContent;
    }

    public EmployeeEntity getEmployee() {
        return employee;
    }

    public void setEmployee(EmployeeEntity employee) {
        this.employee = employee;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
