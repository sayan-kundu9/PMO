package org.teksys.pmo.model;

import javax.persistence.*;

@Entity(name = "ProjectDetails")
@Table(name = "ProjectDetails")
public class ProjectSOW {

    @Id
    @Column(name="CompanyProjectID", nullable=false, unique=true)
    @GeneratedValue(strategy=GenerationType.AUTO)
    private String companyProjectId;

    @Column(name = "ProjectName")
    private String projectName;

    public String getCompanyProjectId() {
        return companyProjectId;
    }

    public void setCompanyProjectId(String companyProjectId) {
        this.companyProjectId = companyProjectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }
}
