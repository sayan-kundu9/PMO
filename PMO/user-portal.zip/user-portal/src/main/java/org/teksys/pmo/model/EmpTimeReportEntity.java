package org.teksys.pmo.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name="EmployeeTimesheetReport")
public class EmpTimeReportEntity
        implements Serializable
{
    @Id
    @Embedded
    private EmpTimeSheetCompoundKeyEntity empTimeSheetCompoundKey;
    @Column(name="Day1")
    private Float day1;
    @Column(name="Day2")
    private Float day2;
    @Column(name="Day3")
    private Float day3;
    @Column(name="Day4")
    private Float day4;
    @Column(name="Day5")
    private Float day5;
    @Column(name="Day6")
    private Float day6;
    @Column(name="Day7")
    private Float day7;
    @Column(name="Day8")
    private Float day8;
    @Column(name="Day9")
    private Float day9;
    @Column(name="Day10")
    private Float day10;
    @Column(name="Day11")
    private Float day11;
    @Column(name="Day12")
    private Float day12;
    @Column(name="Day13")
    private Float day13;
    @Column(name="Day14")
    private Float day14;
    @Column(name="Day15")
    private Float day15;
    @Column(name="Day16")
    private Float day16;
    @Column(name="Day17")
    private Float day17;
    @Column(name="Day18")
    private Float day18;
    @Column(name="Day19")
    private Float day19;
    @Column(name="Day20")
    private Float day20;
    @Column(name="Day21")
    private Float day21;
    @Column(name="Day22")
    private Float day22;
    @Column(name="Day23")
    private Float day23;
    @Column(name="Day24")
    private Float day24;
    @Column(name="Day25")
    private Float day25;
    @Column(name="Day26")
    private Float day26;
    @Column(name="Day27")
    private Float day27;
    @Column(name="Day28")
    private Float day28;
    @Column(name="Day29")
    private Float day29;
    @Column(name="Day30")
    private Float day30;
    @Column(name="Day31")
    private Float day31;
    /*@Transient
    private String practiceId;*/
    @Column(name="Total")
    private Float total;
   /* @Transient
    private String[] practices;*/

    private String empName;
//
    private String projectName;

    /*@OneToOne(cascade = {javax.persistence.CascadeType.ALL})
    @JoinColumn(name = "EmpCompanyID", insertable = false, updatable = false)
    private EmployeeEntity  employeeEntity;

    public EmployeeEntity getEmployeeEntity() {
        return employeeEntity;
    }

    public void setEmployeeEntity(EmployeeEntity employeeEntity) {
        this.employeeEntity = employeeEntity;
    }*/

    public void setEmpTimeSheetCompoundKey(EmpTimeSheetCompoundKeyEntity empTimeSheetCompoundKey)
    {
        this.empTimeSheetCompoundKey = empTimeSheetCompoundKey;
    }

    public EmpTimeSheetCompoundKeyEntity getEmpTimeSheetCompoundKey()
    {
        return this.empTimeSheetCompoundKey;
    }

    public void setDay1(Float day1)
    {
        this.day1 = day1;
    }

    public Float getDay1()
    {
        return this.day1;
    }

    public void setDay2(Float day2)
    {
        this.day2 = day2;
    }

    public Float getDay2()
    {
        return this.day2;
    }
    public void setDay3(Float day3)
    {
        this.day3 = day3;
    }

    public Float getDay3()
    {
        return this.day3;
    }

    public void setDay4(Float day4)
    {
        this.day4 = day4;
    }

    public Float getDay4()
    {
        return this.day4;
    }

    public void setDay5(Float day5)
    {
        this.day5 = day5;
    }

    public Float getDay5()
    {
        return this.day5;
    }

    public void setDay6(Float day6)
    {
        this.day6 = day6;
    }

    public Float getDay6()
    {
        return this.day6;
    }

    public void setDay7(Float day7)
    {
        this.day7 = day7;
    }

    public Float getDay7()
    {
        return this.day7;
    }

    public void setDay8(Float day8)
    {
        this.day8 = day8;
    }

    public Float getDay8()
    {
        return this.day8;
    }

    public void setDay9(Float day9)
    {
        this.day9 = day9;
    }

    public Float getDay9()
    {
        return this.day9;
    }

    public void setDay10(Float day10)
    {
        this.day10 = day10;
    }

    public Float getDay10()
    {
        return this.day10;
    }

    public void setDay11(Float day11)
    {
        this.day11 = day11;
    }

    public Float getDay11()
    {
        return this.day11;
    }

    public void setDay12(Float day12)
    {
        this.day12 = day12;
    }

    public Float getDay12()
    {
        return this.day12;
    }

    public void setDay13(Float day13)
    {
        this.day13 = day13;
    }

    public Float getDay13()
    {
        return this.day13;
    }

    public void setDay14(Float day14)
    {
        this.day14 = day14;
    }

    public Float getDay14()
    {
        return this.day14;
    }

    public void setDay15(Float day15)
    {
        this.day15 = day15;
    }

    public Float getDay15()
    {
        return this.day15;
    }

    public void setDay16(Float day16)
    {
        this.day16 = day16;
    }

    public Float getDay16()
    {
        return this.day16;
    }

    public void setDay17(Float day17)
    {
        this.day17 = day17;
    }

    public Float getDay17()
    {
        return this.day17;
    }

    public void setDay18(Float day18)
    {
        this.day18 = day18;
    }

    public Float getDay18()
    {
        return this.day18;
    }

    public void setDay19(Float day19)
    {
        this.day19 = day19;
    }

    public Float getDay19()
    {
        return this.day19;
    }

    public void setDay20(Float day20)
    {
        this.day20 = day20;
    }

    public Float getDay20()
    {
        return this.day20;
    }

    public void setDay21(Float day21)
    {
        this.day21 = day21;
    }

    public Float getDay21()
    {
        return this.day21;
    }

    public void setDay22(Float day22)
    {
        this.day22 = day22;
    }

    public Float getDay22()
    {
        return this.day22;
    }

    public void setDay23(Float day23)
    {
        this.day23 = day23;
    }

    public Float getDay23()
    {
        return this.day23;
    }

    public void setDay24(Float day24)
    {
        this.day24 = day24;
    }

    public Float getDay24()
    {
        return this.day24;
    }

    public void setDay25(Float day25)
    {
        this.day25 = day25;
    }

    public Float getDay25()
    {
        return this.day25;
    }

    public void setDay26(Float day26)
    {
        this.day26 = day26;
    }

    public Float getDay26()
    {
        return this.day26;
    }

    public void setDay27(Float day27)
    {
        this.day27 = day27;
    }

    public Float getDay27()
    {
        return this.day27;
    }

    public void setDay28(Float day28)
    {
        this.day28 = day28;
    }

    public Float getDay28()
    {
        return this.day28;
    }

    public void setDay29(Float day29)
    {
        this.day29 = day29;
    }

    public Float getDay29()
    {
        return this.day29;
    }

    public void setDay30(Float day30)
    {
        this.day30 = day30;
    }

    public Float getDay30()
    {
        return this.day30;
    }

    public void setDay31(Float day31)
    {
        this.day31 = day31;
    }

    public Float getDay31()
    {
        return this.day31;
    }
    public void setEmpName(String empName)
    {
        this.empName = empName;
    }

    public String getEmpName()
    {
        return this.empName;
    }

    public void setProjectName(String projectName)
    {
        this.projectName = projectName;
    }

    public String getProjectName()
    {
        return this.projectName;
    }

   /* public void setPracticeId(String practiceId)
    {
        this.practiceId = practiceId;
    }

    public String getPracticeId()
    {
        return this.practiceId;
    }*/

    public void setTotal(Float total)
    {
        this.total = total;
    }

    public Float getTotal()
    {
        return this.total;
    }

  /*  public void setPractices(String[] practices)
    {
        this.practices = practices;
    }

    public String[] getPractices()
    {
        return this.practices;
    }*/
}
