package org.teksys.pmo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import org.teksys.pmo.model.SOWNames;

import java.util.List;

public interface ProjectDetailsSOWDao extends JpaRepository<SOWNames, Integer> {

    @Query(value = "select p from ProjectSOW p where p.companyProjectId = :id")
    List<SOWNames> getAllSowNamesById(@Param("id") String id);

    @Query("select sowContent from ProjectSOW where companyProjectId=?")
    byte[] findSowByProjectId(String comapnyProjectId);

    @Transactional
    @Modifying
    @Query("delete from ProjectSOW where companyProjectId=?")
    void deleteSow(String companyProjectId);
}
