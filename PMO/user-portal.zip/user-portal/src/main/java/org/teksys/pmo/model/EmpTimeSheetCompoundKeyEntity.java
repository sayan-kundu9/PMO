package org.teksys.pmo.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class EmpTimeSheetCompoundKeyEntity
        implements Serializable
{
    @Column(name="EmpCompanyID")
    private String companyEmpId;
    @Column(name="CompanyProjectID")
    private String companyProjectId;
    @Column(name="MonthReport")
    private String month;
    @Column(name="YearReport")
    private Integer year;
    @Column(name="Type")
    private String type;

    public EmpTimeSheetCompoundKeyEntity(String type, String companyEmpId, String companyProjectId, String month, Integer year)
    {
        this.type = type;
        this.companyEmpId = companyEmpId;
        this.companyProjectId = companyProjectId;
        this.month = month;
        this.year = year;
    }

    public EmpTimeSheetCompoundKeyEntity() {}

    public void setCompanyEmpId(String companyEmpId)
    {
        this.companyEmpId = companyEmpId;
    }

    public String getCompanyEmpId()
    {
        return this.companyEmpId;
    }

    public void setCompanyProjectId(String companyProjectId)
    {
        this.companyProjectId = companyProjectId;
    }

    public String getCompanyProjectId()
    {
        return this.companyProjectId;
    }

    public void setMonth(String month)
    {
        this.month = month;
    }

    public String getMonth()
    {
        return this.month;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public void setType(String type)
    {
        this.type = type;
    }

    public String getType()
    {
        return this.type;
    }
}
