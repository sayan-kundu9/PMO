package org.teksys.pmo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.teksys.pmo.model.ProjectSOW;
import org.teksys.pmo.model.SOWNames;

import java.util.List;

public interface ProjectSOWDao extends JpaRepository<ProjectSOW, Integer> {

    @Query(value = "select p from ProjectDetails p ")
    List<ProjectSOW> getAllProjectName();

    @Query("select count(companyProjectId) from ProjectSOW where companyProjectId=?")
    Integer sowIdExists(String companyProjectId);
}
