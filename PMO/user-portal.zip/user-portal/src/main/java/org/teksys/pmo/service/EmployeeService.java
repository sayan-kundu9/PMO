package org.teksys.pmo.service;

import org.springframework.stereotype.Service;
import org.teksys.pmo.domain.Employee;
import org.teksys.pmo.domain.EmployeeSalaryPerHourDTO;
import org.teksys.pmo.model.EmployeeEntity;
import org.teksys.pmo.model.EmployeeSalaryPerHour;

import java.io.IOException;
import java.util.List;

@Service
public interface EmployeeService {

    List<Employee> findEmpByLocation(String location);
    List<EmployeeEntity> findAllEmployees();
    List<Employee> findEmployees(Employee employee) throws IOException;
    List<Employee> findEmployeesWithSpecificData(Employee employee);
    public void addEmployee(Employee employee);
    EmployeeEntity editEmployee(EmployeeEntity editEmployee);
    void addEmpSal(EmployeeSalaryPerHour employeeSalaryPerHour);
    List<EmployeeSalaryPerHourDTO> historyOfDL(EmployeeSalaryPerHourDTO employeeSalaryPerHourDTO);
    List<EmployeeSalaryPerHourDTO> employeeDL(EmployeeSalaryPerHourDTO employeeSalaryPerHourDTO);


}
