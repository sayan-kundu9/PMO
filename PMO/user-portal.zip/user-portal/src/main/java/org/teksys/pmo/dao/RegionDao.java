package org.teksys.pmo.dao;

import org.springframework.data.repository.CrudRepository;
import org.teksys.pmo.model.Region;

import java.util.List;

public interface RegionDao extends CrudRepository<Region, String> {
    @Override
    List<Region> findAll();

}
