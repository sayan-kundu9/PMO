package org.teksys.pmo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.teksys.pmo.model.Client;

import java.util.List;

public interface ClientRepository extends JpaRepository<Client, Integer>, ClientRepositoryCustom {

    @Override
    List<Client> findAll();
    Client findOne(Integer integer);

    Client findById(Integer integer);
}
