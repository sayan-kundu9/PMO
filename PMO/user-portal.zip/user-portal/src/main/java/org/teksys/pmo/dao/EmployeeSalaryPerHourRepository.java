package org.teksys.pmo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.teksys.pmo.domain.EmployeeSalaryPerHourDTO;
import org.teksys.pmo.model.EmployeeSalaryPerHour;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@Repository
public interface EmployeeSalaryPerHourRepository extends JpaRepository<EmployeeSalaryPerHour, String> {
   List<EmployeeSalaryPerHour> findByCompanyEmpId(String companyEmpId);
}






