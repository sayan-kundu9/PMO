package org.teksys.pmo.domain;

public class SolutionExecutiveDTO {

    private int seId;
    private String name;

    public int getSeId() {
        return seId;
    }

    public void setSeId(int seId) {
        this.seId = seId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
