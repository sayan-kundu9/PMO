package org.teksys.pmo.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.teksys.pmo.dao.EmpTimeReportRepository;
import org.teksys.pmo.domain.EmpTimeReport;
import org.teksys.pmo.model.EmpTimeReportEntity;
import org.teksys.pmo.service.EmpTimeReportService;

import java.util.List;


@RestController
//@CrossOrigin(origins = "http://localhost:4200")
public class EmpTimeReportController {


    @Autowired
    private EmpTimeReportService empTimeReportService;

    @Autowired
    private EmpTimeReportRepository empTimeReportRepository;

   /* @GetMapping("/findAllTimeReports")
    public List<EmpTimeReport> findAllEmployees() {
        return empTimeReportService.findAllEmpTimeReports();*/

   @PostMapping("/searchEmpTimeSheet")
    public List<EmpTimeReport> searchEmpTimeSheet(@RequestBody EmpTimeReport empTimeReport) {
       try {
           return empTimeReportService.searchEmpTimeSheet(empTimeReport);
       } catch (JsonProcessingException e) {
           e.printStackTrace();
       }
       return null;
   }
    @GetMapping("/getAllTimeSheetReports")
    public List<EmpTimeReportEntity> getAllTimeSheetReports(){
        return empTimeReportRepository.findAll();
    }

}
