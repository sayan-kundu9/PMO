package org.teksys.pmo.domain;


import org.teksys.pmo.model.PracticePortletEntity;

import java.io.Serializable;
import java.util.Date;

public class PracticeManagementDTO implements Serializable {
    private int id;
    private String portletPracticeID;
    private String practiceContent;
    private boolean isDeleted =false;
    private boolean active;
    private Date createdDate;
    private String createdBy;
    private Date modifiedDate;
    private String modifiedBy;
    private PracticePortletEntity practicePortletEntity;
    private String activeStr;
    private String deletedStr;
    private String createdDt;

    public PracticeManagementDTO(int id, String portletPracticeID, String practiceContent,boolean deleted,boolean active,Date createdDate, String createdBy,  String modifiedBy,PracticePortlet practicePortlet,String activeStr,String deletedStr,String createdDt,Date modifiedDate) {
        this.id = id;
        this.portletPracticeID = portletPracticeID;
        this.practiceContent = practiceContent;
        this.isDeleted = deleted;
        this.active = active;
        this.createdDate = createdDate;
        this.createdBy = createdBy;
        this.modifiedDate = modifiedDate;
        this.modifiedBy = modifiedBy;
        this.practicePortletEntity=practicePortletEntity;
        this.activeStr=activeStr;
        this.deletedStr=deletedStr;
        this.createdDt=createdDt;
    }
    public PracticeManagementDTO() {}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPortletPracticeID() {
        return portletPracticeID;
    }

    public void setPortletPracticeID(String portletPracticeID) {
        this.portletPracticeID = portletPracticeID;
    }

    public String getPracticeContent() {
        return practiceContent;
    }

    public void setPracticeContent(String practiceContent) {
        this.practiceContent = practiceContent;
    }


    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public void setIsCreatedDate(Date createdDate)
    {
        this.createdDate = createdDate;
    }

    public Date getCreatedDate()
    {
        return this.createdDate;
    }

    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }

    public String getCreatedBy()
    {
        return this.createdBy;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public void setModifiedDate(Date modifiedDate)
    {
        this.modifiedDate = modifiedDate;
    }

    public Date getModifiedDate()
    {
        return this.modifiedDate;
    }

    public void setModifiedBy(String modifiedBy)
    {
        this.modifiedBy = modifiedBy;
    }

    public String getModifiedBy()
    {
        return this.modifiedBy;
    }

    public PracticePortletEntity getPracticePortletEntity() {
        return practicePortletEntity;
    }

    public void setPracticePortletEntity(PracticePortletEntity practicePortletEntity) {
        this.practicePortletEntity = practicePortletEntity;
    }

    public String getActiveStr() {
        return activeStr;
    }

    public void setActiveStr(String activeStr) {
        this.activeStr = activeStr;
    }

    public String getDeletedStr() {
        return deletedStr;
    }

    public void setDeletedStr(String deletedStr) {
        this.deletedStr = deletedStr;
    }

    public String getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(String createdDt) {
        this.createdDt = createdDt;
    }
}
