package org.teksys.pmo.dao;

import org.springframework.data.repository.CrudRepository;
import org.teksys.pmo.model.BDM;

import java.util.List;

public interface BdmDao extends CrudRepository<BDM, Integer> {
    @Override
    List<BDM> findAll();
}
