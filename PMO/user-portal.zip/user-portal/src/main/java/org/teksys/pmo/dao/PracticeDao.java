package org.teksys.pmo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.teksys.pmo.model.PracticeExpense;

import java.util.List;

public interface PracticeDao extends JpaRepository<PracticeExpense, Integer> {

    @Override
    List<PracticeExpense> findAll();

    PracticeExpense findOne(Integer integer);

    PracticeExpense findByPracticeExpenseId(Integer integer);
}
