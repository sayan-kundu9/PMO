package org.teksys.pmo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.teksys.pmo.model.EmpTimeReportEntity;

@org.springframework.stereotype.Repository
public interface EmpTimeReportRepository extends JpaRepository<EmpTimeReportEntity,Integer> , EmpTimeReportRepositoryCustom {

}





