package org.teksys.pmo.dao.DaoImpl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.teksys.pmo.dao.EmployeeRepositoryCustom;
import org.teksys.pmo.domain.Employee;
import org.teksys.pmo.domain.EmployeeAllDetails;
import org.teksys.pmo.model.EmpProject;
import org.teksys.pmo.model.EmployeeEntity;
import javax.persistence.*;
import javax.persistence.criteria.*;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;

@Repository
public class EmployeeRepositoryImpl  implements EmployeeRepositoryCustom {
    private static final Logger logger = Logger.getLogger(EmployeeRepositoryImpl.class);

    @Autowired
    EntityManager entityManager;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    EntityManagerFactory entityManagerFactory;


    public List<Employee> searchEmployee(String location) {
        List<Employee> employees = new ArrayList<Employee>();
        List<EmployeeEntity> employeeList = new ArrayList<EmployeeEntity>();
        Query query = entityManager.createNativeQuery("Select * from Employee where Location=?1", EmployeeEntity.class);
        query.setParameter(1, location);
        employeeList = query.getResultList();
        String employeeListInString = null;
        try {
            employeeListInString = objectMapper.writeValueAsString(employeeList);
        } catch (JsonProcessingException e) {
            logger.error("error when try to find employee :"+e);
        }
        try {
            employees = objectMapper.readValue(employeeListInString, new TypeReference<List<Employee>>() {
            });
        } catch (IOException e) {
            logger.error("error when try to find employee :"+e);
        }

        return employees;
    }

    public List<EmployeeEntity> findEmployees(Employee employee) throws IOException {

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<EmployeeEntity> cq = cb.createQuery(EmployeeEntity.class);
        Root<EmployeeEntity> emp = cq.from(EmployeeEntity.class);
        List<Predicate> predicates = new ArrayList<Predicate>();

        if (StringUtils.isNotBlank(employee.getEmpId()))
            predicates.add(cb.like(emp.get("empId"), employee.getEmpId()));
        if (StringUtils.isNotBlank(employee.getCompanyEmpId()))
            predicates.add(cb.like(emp.get("companyEmpId"), employee.getCompanyEmpId()));
        if (StringUtils.isNotBlank(employee.getFirstName()))
            predicates.add(cb.like(emp.get("firstName"), employee.getFirstName() + "%"));
        if (StringUtils.isNotBlank(employee.getLastName()))
            predicates.add(cb.like(emp.get("lastName"), employee.getLastName() + "%"));
        if (StringUtils.isNotBlank(employee.getTitle()))
            predicates.add(cb.like(emp.get("title"), employee.getTitle()));
        if (StringUtils.isNotBlank(employee.getCoe()))
           predicates.add(cb.like(emp.get("coe"), employee.getCoe()));
        if (StringUtils.isNotBlank(employee.getReportingTo()))
            predicates.add(cb.like(emp.get("reportingTo"), employee.getReportingTo()));
        if (StringUtils.isNotBlank(employee.getLocation()))
            predicates.add(cb.like(emp.get("location"), employee.getLocation()));
        if (StringUtils.isNotBlank(employee.getBusinessLine()))
            predicates.add(cb.equal(emp.get("businessLine"), employee.getBusinessLine()));

        cq.select(emp);
        cq.where(predicates.toArray(new Predicate[predicates.size()]));
        TypedQuery<EmployeeEntity> q = entityManager.createQuery(cq);
        List<EmployeeEntity> resultList = q.getResultList();
        return resultList;
    }


    public List<EmployeeAllDetails> getAllEmployees(){
        // List<EmployeeAllDetails> employees = new ArrayList<EmployeeAllDetails>();
        String s ="  select EmpCompanyID, EmployeeID, FirstName, LastName, A.RoleID, BusinessLine, ReportTo, HireDate, Termination, Location, OfficePhone, MobilePhone, TekEmail, AlternateEmail,  A.TechnologyID, CreatedBy, createdDate, ModifiedBy, ModifiedDate, Salary, VoluntaryType, effectiveDate, parentEmployee, SalaryPerHour, EmployeeSalaryPerHourId, RoleName, B.PracticeID, PracticeName,PracticeHead, CompanyID, TechnologyName  from Employee A, \n" +
                "              Role B , \n" +
                "              Practice C , \n" +
                "              Technology D \n" +
                "where \n" +
                "              A.RoleID = B.RoleID and \n" +
                "              B.PracticeID = c.PracticeID and \n" +
                "              A.TechnologyID = D.TechnologyID";
        Query query = entityManager.createNativeQuery(s);

        List<Object[]> employees =  query.getResultList();
        List<EmployeeAllDetails> finalResultSet = new ArrayList<>();
        employees.stream().forEach((emp)->
                {
                    EmployeeAllDetails empData = new EmployeeAllDetails();
                    empData.setEmpCompanyID(emp[0].toString());
                    empData.setEmployeeID(emp[1].toString());
                    empData.setFirstName(emp[2].toString());
                    empData.setLastName(emp[3].toString());
                    empData.setRoleID(emp[4].toString());
                    empData.setBusinessLine((int) emp[5]);
                    empData.setReportTo(emp[6].toString());
                    empData.setHireDate((Date) emp[7]);
                    empData.setTermination((Date) emp[8]);
                    empData.setLocation(emp[9].toString());
                    empData.setOfficePhone(emp[10].toString());
                    empData.setMobilePhone(emp[11].toString());
                    empData.setTekEmail(emp[12].toString());
                    empData.setAlternateEmail(emp[13].toString());
                    empData.setTechnologyID((int) emp[14]);
//                    empData.setCreatedBy(emp[15].toString());
                    empData.setCreatedDate((Date) emp[16]);
//                    empData.setModifiedBy(emp[17].toString());
                    empData.setModifiedDate((Date) emp[18]);
//                    empData.setSalary(emp[19].toString());
                    empData.setVoluntaryType((Boolean) emp[20]);
                    empData.setEffectiveDate((Date) emp[21]);
//                    empData.setParentEmployee(emp[22].toString());
//                    empData.setSalaryPerHour(emp[23].toString());
//                    empData.setEmployeeSalaryPerHourId(emp[24].toString());
                    empData.setRoleName(emp[25].toString());
                    empData.setPracticeID((int) emp[26]);
                    empData.setPracticeName(emp[27].toString());
                    empData.setPracticeHead(emp[28].toString());
                    empData.setCompanyID((int) emp[29]);
                    empData.setTechnologyName(emp[30].toString());

                    finalResultSet.add(empData);
                }
        );


        return finalResultSet;


    }


    public List<Employee> findEmployeeByAll(Employee employee) {

        List<Employee> employeeList = new ArrayList<Employee>();

        StringBuffer s = new StringBuffer();
        s.append("SELECT * FROM EmployeeProjectDetails \n" +
                "\tJOIN ProjectDetails ON\n" +
                "\t\tEmployeeProjectDetails.CompanyProjectID=ProjectDetails.CompanyProjectID\n" +
                "\tJOIN Employee ON\n" +
                "\t\tEmployeeProjectDetails.EmpCompanyID=Employee.EmpCompanyID\n" +
                "\t\twhere EmployeeProjectDetails.CompanyProjectID=?1 ");
        if(employee.getFirstName()!=null)
            s.append("and Employee.firstName=?2 ");
        if(employee.getCompanyEmpId()!= null)
           s.append("and Employee.empCompanyId=?3 ");
        if(employee.getEmpId()!=null)
            s.append("and Employee.employeeID=?4 ");
        if(employee.getLastName()!= null)
            s.append("and Employee.lastName=?5 ");
        if(employee.getTitle()!= null)
            s.append("and Employee.roleId=?6 ");
        if(employee.getBusinessLine()!=null)
            s.append("and Employee.businessLine=?7 ");
        if(employee.getCoe()!= null)
            s.append("and Employee.technologyId=?8 ");
        if(employee.getReportingTo()!= null)
            s.append("and Employee.reportTo=?9 ");
        if(employee.getLocation()!= null)
            s.append("and Employee.location=?10 ");


        Query query = entityManager.createNativeQuery(s.toString(), EmpProject.class);

        query.setParameter(1, employee.getProjectName());
        if(employee.getFirstName()!=null)
            query.setParameter(2,employee.getFirstName());
        if (employee.getCompanyEmpId()!=null)
           query.setParameter(3,employee.getCompanyEmpId());
        if (employee.getEmpId()!=null)
            query.setParameter(4,employee.getEmpId());
        if (employee.getLastName()!=null)
            query.setParameter(5,employee.getLastName());
        if (employee.getTitle()!=null)
            query.setParameter(6,employee.getTitle());
        if (employee.getBusinessLine()!=null)
            query.setParameter(7,employee.getBusinessLine());
        if (employee.getCoe()!=null)
            query.setParameter(8,employee.getCoe());
        if( employee.getReportingTo()!=null)
            query.setParameter(9, employee.getReportingTo());
        if( employee.getLocation()!= null)
            query.setParameter(10,employee.getLocation());
        employeeList = query.getResultList();
        return employeeList;

    }


    public List<EmployeeEntity> findEmployeesWithSpecificData(Employee employee) throws IOException {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Tuple> cq = cb.createTupleQuery();
        Root<EmployeeEntity> emp = cq.from(EmployeeEntity.class);
        List<Predicate> predicates = new ArrayList<Predicate>();
        if(StringUtils.isNotBlank(employee.getEmpId()))
            predicates.add(cb.like(emp.get("empId"),employee.getEmpId()));
        if(StringUtils.isNotBlank(employee.getCompanyEmpId()))
            predicates.add(cb.like(emp.get("companyEmpId"),employee.getCompanyEmpId()));
        if(StringUtils.isNotBlank(employee.getFirstName()))
            predicates.add(cb.like(emp.get("firstName"),employee.getFirstName()+"%"));
        if(StringUtils.isNotBlank(employee.getLastName()))
            predicates.add(cb.like(emp.get("lastName"),employee.getLastName()+"%"));
        if(StringUtils.isNotBlank(employee.getTitle()))
            predicates.add(cb.like(emp.get("title"),employee.getTitle()));
        if(StringUtils.isNotBlank(employee.getCoe()))
            predicates.add(cb.like(emp.get("coe"),employee.getCoe()));
        if(StringUtils.isNotBlank(employee.getReportingTo()))
            predicates.add(cb.like(emp.get("reportingTo"),employee.getReportingTo()));
        if(StringUtils.isNotBlank(employee.getLocation()))
            predicates.add(cb.like(emp.get("location"),employee.getLocation()));
        if(StringUtils.isNotBlank(employee.getBusinessLine()))
            predicates.add(cb.equal(emp.get("businessLine"),employee.getBusinessLine()));
        cq.multiselect(emp.get("firstName").alias("firstName"),
                emp.get("lastName").alias("lastName"),
                emp.get("empId").alias("empId"),
                emp.get("companyEmpId").alias("companyEmpId"),
                emp.get("coe").alias("coe"),emp.get("title").alias("title"));
        cq.where(predicates.toArray(new Predicate[predicates.size()]));
        List<Tuple> resultList = entityManager.createQuery(cq).getResultList();
        List<EmployeeEntity> employeeEntityList = new ArrayList<EmployeeEntity>();
        for(Tuple employeeResult:resultList)
        {
            EmployeeEntity entity = new EmployeeEntity();
            entity.setFirstName((String) employeeResult.get("firstName"));
            entity.setLastName((String) employeeResult.get("lastName"));
            entity.setEmpId((String) employeeResult.get("empId"));
            entity.setCompanyEmpId((String) employeeResult.get("companyEmpId"));
            entity.setCoe((String) employeeResult.get("coe"));
            entity.setTitle((String) employeeResult.get("title"));
            employeeEntityList.add(entity);
        }
        return employeeEntityList;
    }






}