package org.teksys.pmo.domain;

import org.teksys.pmo.model.*;

import java.util.Date;
import java.util.Set;

public class Employee {
    private String companyEmpId;
    private String empId;
    private String firstName;
    private String lastName;
    private String title;
    private String businessLine;
    private String coe;
    private String reportingTo;
    private Date hireDate;
    private Date termination;
    private String location;
    private String salary;
    private String officePhone;
    private String mobilePhone;
    private String tekEmail;
    private String alternateEmail;
//    private String createdBy;
    private Date dateCreated;
    private String modifiedBy;
//    private Date dateModified;
    private boolean type;

    private String effectiveDate;
    private String salaryPerHour;
    private String hrDate;
    private String trDate;
    private int rowNo;
    private String columnNo;
    private String errorMsg;
    private String projectName;
    private String businessLineDesc;
    private String titleDesc;
    private String coeDesc;

    private Role role;
    private Technology technology;
    private Practice practice;
    private Set<EmpProject> empProjects;

    private Set<EmployeeSalaryPerHour> employeeSalaryPerHours;
    private Set<EmployeeCV> employeeCVs;

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Technology getTechnology() {
        return technology;
    }

    public void setTechnology(Technology technology) {
        this.technology = technology;
    }

    public Practice getPractice() {
        return practice;
    }

    public void setPractice(Practice practice) {
        this.practice = practice;
    }

    public Set<EmpProject> getEmpProjects() {
        return empProjects;
    }

    public void setEmpProjects(Set<EmpProject> empProjects) {
        this.empProjects = empProjects;
    }

    public Set<EmployeeSalaryPerHour> getEmployeeSalaryPerHours() {
        return employeeSalaryPerHours;
    }

    public void setEmployeeSalaryPerHours(Set<EmployeeSalaryPerHour> employeeSalaryPerHours) {
        this.employeeSalaryPerHours = employeeSalaryPerHours;
    }

    public Set<EmployeeCV> getEmployeeCVs() {
        return employeeCVs;
    }

    public void setEmployeeCVs(Set<EmployeeCV> employeeCVs) {
        this.employeeCVs = employeeCVs;
    }

    public String getCompanyEmpId() {
        return companyEmpId;
    }

    public void setCompanyEmpId(String companyEmpId) {
        this.companyEmpId = companyEmpId;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBusinessLine() {
        return businessLine;
    }

    public void setBusinessLine(String businessLine) {
        this.businessLine = businessLine;
    }

    public String getCoe() {
        return coe;
    }

    public void setCoe(String coe) {
        this.coe = coe;
    }

    public String getReportingTo() {
        return reportingTo;
    }

    public void setReportingTo(String reportingTo) {
        this.reportingTo = reportingTo;
    }

    public Date getHireDate() {
        return hireDate;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    public Date getTermination() {
        return termination;
    }

    public void setTermination(Date termination) {
        this.termination = termination;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getOfficePhone() {
        return officePhone;
    }

    public void setOfficePhone(String officePhone) {
        this.officePhone = officePhone;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getTekEmail() {
        return tekEmail;
    }

    public void setTekEmail(String tekEmail) {
        this.tekEmail = tekEmail;
    }

    public String getAlternateEmail() {
        return alternateEmail;
    }

    public void setAlternateEmail(String alternateEmail) {
        this.alternateEmail = alternateEmail;
    }

//    public String getCreatedBy() {
//        return createdBy;
//    }
//
//    public void setCreatedBy(String createdBy) {
//        this.createdBy = createdBy;
//    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

//    public Date getDateModified() {
//        return dateModified;
//    }
//
//    public void setDateModified(Date dateModified) {
//        this.dateModified = dateModified;
//    }


    public boolean isType() {
        return type;
    }

    public void setType(boolean type) {
        this.type = type;
    }

    public String getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String getSalaryPerHour() {
        return salaryPerHour;
    }

    public void setSalaryPerHour(String salaryPerHour) {
        this.salaryPerHour = salaryPerHour;
    }

    public String getHrDate() {
        return hrDate;
    }

    public void setHrDate(String hrDate) {
        this.hrDate = hrDate;
    }

    public String getTrDate() {
        return trDate;
    }

    public void setTrDate(String trDate) {
        this.trDate = trDate;
    }

    public int getRowNo() {
        return rowNo;
    }

    public void setRowNo(int rowNo) {
        this.rowNo = rowNo;
    }

    public String getColumnNo() {
        return columnNo;
    }

    public void setColumnNo(String columnNo) {
        this.columnNo = columnNo;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getBusinessLineDesc() {
        return businessLineDesc;
    }

    public void setBusinessLineDesc(String businessLineDesc) {
        this.businessLineDesc = businessLineDesc;
    }

    public String getTitleDesc() {
        return titleDesc;
    }

    public void setTitleDesc(String titleDesc) {
        this.titleDesc = titleDesc;
    }

    public String getCoeDesc() {
        return coeDesc;
    }

    public void setCoeDesc(String coeDesc) {
        this.coeDesc = coeDesc;
    }

}
