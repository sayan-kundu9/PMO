package org.teksys.pmo.domain;

import java.util.Date;

public class PracticeExpenseDTO {

    private Integer practiceExpenseId;

    private PracticeDTO practice;

    private String practiceId;

    private ExpensesDTO expenses;

    private String expensesId;

    private Double amount;

    private String currency_name;

    private String expenses_description;

    private Date dateOfExpense;

    private String planned;

    public Integer getPracticeExpenseId() {
        return practiceExpenseId;
    }

    public void setPracticeExpenseId(Integer practiceExpenseId) {
        this.practiceExpenseId = practiceExpenseId;
    }

    public String getPracticeId() {
        return practiceId;
    }

    public void setPracticeId(String practiceId) {
        this.practiceId = practiceId;
    }

    public String getExpensesId() {
        return expensesId;
    }

    public void setExpensesId(String expensesId) {
        this.expensesId = expensesId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getCurrency_name() {
        return currency_name;
    }

    public void setCurrency_name(String currency_name) {
        this.currency_name = currency_name;
    }

    public String getExpenses_description() {
        return expenses_description;
    }

    public void setExpenses_description(String expenses_description) {
        this.expenses_description = expenses_description;
    }

    public Date getDateOfExpense() {
        return dateOfExpense;
    }

    public void setDateOfExpense(Date dateOfExpense) {
        this.dateOfExpense = dateOfExpense;
    }

    public String getPlanned() {
        return planned;
    }

    public void setPlanned(String planned) {
        this.planned = planned;
    }

    public PracticeDTO getPractice() {
        return practice;
    }

    public void setPractice(PracticeDTO practice) {
        this.practice = practice;
    }

    public ExpensesDTO getExpenses() {
        return expenses;
    }

    public void setExpenses(ExpensesDTO expenses) {
        this.expenses = expenses;
    }
}
