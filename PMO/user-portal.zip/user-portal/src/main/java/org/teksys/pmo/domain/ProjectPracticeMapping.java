package org.teksys.pmo.domain;

import org.teksys.pmo.model.Practice;
import org.teksys.pmo.model.Project;

public class ProjectPracticeMapping {

    private int ProjectPracticeID;
    private String companyProjectId;
    private String practiceId;
    private Project project;
    private  Practice practice;

    public int getProjectPracticeID() {
        return ProjectPracticeID;
    }

    public void setProjectPracticeID(int projectPracticeID) {
        ProjectPracticeID = projectPracticeID;
    }

    public String getCompanyProjectId() {
        return companyProjectId;
    }

    public void setCompanyProjectId(String companyProjectId) {
        this.companyProjectId = companyProjectId;
    }

    public String getPracticeId() {
        return practiceId;
    }

    public void setPracticeId(String practiceId) {
        this.practiceId = practiceId;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public Practice getPractice() {
        return practice;
    }

    public void setPractice(Practice practice) {
        this.practice = practice;
    }
}
