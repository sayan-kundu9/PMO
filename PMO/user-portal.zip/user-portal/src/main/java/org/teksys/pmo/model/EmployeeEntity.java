
package org.teksys.pmo.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
//import org.codehaus.jackson.annotate.JsonBackReference;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity

@Table(name = "Employee")

public class EmployeeEntity implements Serializable {
    @Id
    @Column(name = "EmpCompanyID", nullable = false, unique = true)
    private String companyEmpId;
    @Column(name = "EmployeeID")
    private String empId;
    @ManyToOne()
    @JoinColumn(name = "RoleID", insertable = false, updatable = false)
    private Role role;
    @ManyToOne
    @JoinColumn(name = "TechnologyID", insertable = false, updatable = false)
    private Technology technology;
    @ManyToOne
    @JoinColumn(name = "BusinessLine", insertable = false, updatable = false)
    private Practice practice;
    /*@ManyToOne
    @JoinColumn(name = "ReportTo", insertable = false, updatable = false)
    private EmployeeEntity parentEmployee;
    @OneToMany(cascade = {javax.persistence.CascadeType.ALL}, mappedBy = "parentEmployee")
    private Set<EmployeeEntity> childEmployees;*/
    @JsonBackReference(value = "emp-project")
    @OneToMany(cascade = {javax.persistence.CascadeType.REMOVE}, mappedBy = "employee")
    private Set<EmpProject> empProjects;
    @JsonBackReference(value = "employee-salary")
    @OneToMany(cascade = {javax.persistence.CascadeType.ALL}, mappedBy = "employee")
    private Set<EmployeeSalaryPerHour> employeeSalaryPerHours;
    @JsonBackReference(value = "employee-cv")
    @OneToMany(cascade = {javax.persistence.CascadeType.REMOVE}, mappedBy = "employee")
    private Set<EmployeeCV> employeeCVs;

    @Column(name = "FirstName")
    private String firstName;
    @Column(name = "LastName")
    private String lastName;
    @Column(name = "RoleID")
    private String title;
    @Column(name = "BusinessLine")
    private Integer businessLine;
    @Column(name = "TechnologyID")
    private String coe;
    @Column(name = "ReportTo")
    private String reportingTo;
    @Temporal(TemporalType.DATE)
    @Column(name = "HireDate", nullable = true)
    private Date hireDate;
    @Temporal(TemporalType.DATE)
    @Column(name = "Termination", nullable = true)
    private Date termination;
    @Column(name = "Location")
    private String location;
    @Column(name = "Salary")
    private String salary;
    @Column(name = "OfficePhone")
    private String officePhone;
    @Column(name = "MobilePhone")
    private String mobilePhone;
    @Column(name = "TekEmail")
    private String tekEmail;
    @Column(name = "AlternateEmail")
    private String alternateEmail;
//    @Column(name = "CreatedBy")
//    private String createdBy;
    @Column(name = "CreatedDate")
    private Date dateCreated;
    @Column(name = "ModifiedBy")
    private String modifiedBy;
//    @Column(name = "ModifiedDate")
//    private Date dateModified;
    @Column(name = "VoluntaryType", columnDefinition = "tinyint(1)" )
    private boolean type;


    @Column(
            name = "EffectiveDate",
            nullable = true
    )
    private Date effectiveDate;


    @Column(
            name = "SalaryPerHour"
    )
    private String salaryPerHour;


    public Integer getEmployeeSalaryPerHourID() {
        return employeeSalaryPerHourID;
    }

    public void setEmployeeSalaryPerHourID(Integer employeeSalaryPerHourID) {
        this.employeeSalaryPerHourID = employeeSalaryPerHourID;
    }

    @Column(
            name = "EmployeeSalaryPerHourID"

    )
    private Integer employeeSalaryPerHourID;

    @Transient
    private String hrDate;
    @Transient
    private String trDate;
    @Transient
    private int rowNo;
    @Transient
    private String columnNo;
    @Transient
    private String errorMsg;
    @Transient
    private String projectName;
    @Transient
    private String businessLineDesc;
    @Transient
    private String titleDesc;
    @Transient
    private String coeDesc;

    public String getCompanyEmpId() {
        return companyEmpId;
    }

    public void setCompanyEmpId(String companyEmpId) {
        this.companyEmpId = companyEmpId;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getBusinessLine() {
        return businessLine;
    }

    public void setBusinessLine(Integer businessLine) {
        this.businessLine = businessLine;
    }

    public String getCoe() {
        return coe;
    }

    public void setCoe(String coe) {
        this.coe = coe;
    }

    public String getReportingTo() {
        return reportingTo;
    }

    public void setReportingTo(String reportingTo) {
        this.reportingTo = reportingTo;
    }

    public Date getHireDate() {
        return hireDate;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    public Date getTermination() {
        return termination;
    }

    public void setTermination(Date termination) {
        this.termination = termination;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getOfficePhone() {
        return officePhone;
    }

    public void setOfficePhone(String officePhone) {
        this.officePhone = officePhone;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getTekEmail() {
        return tekEmail;
    }

    public void setTekEmail(String tekEmail) {
        this.tekEmail = tekEmail;
    }

    public String getAlternateEmail() {
        return alternateEmail;
    }

    public void setAlternateEmail(String alternateEmail) {
        this.alternateEmail = alternateEmail;
    }

//    public String getCreatedBy() {
//        return createdBy;
//    }
//
//    public void setCreatedBy(String createdBy) {
//        this.createdBy = createdBy;
//    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

//    public Date getDateModified() {
//        return dateModified;
//    }
//
//    public void setDateModified(Date dateModified) {
//        this.dateModified = dateModified;
//    }


    public boolean isType() {
        return type;
    }

    public void setType(boolean type) {
        this.type = type;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Technology getTechnology() {
        return technology;
    }

    public void setTechnology(Technology technology) {
        this.technology = technology;
    }

    public Practice getPractice() {
        return practice;
    }

    public void setPractice(Practice practice) {
        this.practice = practice;
    }

    /*public EmployeeEntity getParentEmployee() {
        return parentEmployee;
    }

    public void setParentEmployee(EmployeeEntity parentEmployee) {
        this.parentEmployee = parentEmployee;
    }*/

    /*public Set<EmployeeEntity> getChildEmployees() {
        return childEmployees;
    }

    public void setChildEmployees(Set<EmployeeEntity> childEmployees) {
        this.childEmployees = childEmployees;
    }*/

    public Set<EmpProject> getEmpProjects() {
        return empProjects;
    }

    public void setEmpProjects(Set<EmpProject> empProjects) {
        this.empProjects = empProjects;
    }

    public Set<EmployeeSalaryPerHour> getEmployeeSalaryPerHours() {
        return employeeSalaryPerHours;
    }

    public void setEmployeeSalaryPerHours(Set<EmployeeSalaryPerHour> employeeSalaryPerHours) {
        this.employeeSalaryPerHours = employeeSalaryPerHours;
    }

    public Set<EmployeeCV> getEmployeeCVs() {
        return employeeCVs;
    }

    public void setEmployeeCVs(Set<EmployeeCV> employeeCVs) {
        this.employeeCVs = employeeCVs;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date date) {
        this.effectiveDate = date;
    }

    public String getSalaryPerHour() {
        return salaryPerHour;
    }

    public void setSalaryPerHour(String salaryPerHour) {
        this.salaryPerHour = salaryPerHour;
    }

    public String getHrDate() {
        return hrDate;
    }

    public void setHrDate(String hrDate) {
        this.hrDate = hrDate;
    }

    public String getTrDate() {
        return trDate;
    }

    public void setTrDate(String trDate) {
        this.trDate = trDate;
    }

    public int getRowNo() {
        return rowNo;
    }

    public void setRowNo(int rowNo) {
        this.rowNo = rowNo;
    }

    public String getColumnNo() {
        return columnNo;
    }

    public void setColumnNo(String columnNo) {
        this.columnNo = columnNo;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getBusinessLineDesc() {
        return businessLineDesc;
    }

    public void setBusinessLineDesc(String businessLineDesc) {
        this.businessLineDesc = businessLineDesc;
    }

    public String getTitleDesc() {
        return titleDesc;
    }

    public void setTitleDesc(String titleDesc) {
        this.titleDesc = titleDesc;
    }

    public String getCoeDesc() {
        return coeDesc;
    }

    public void setCoeDesc(String coeDesc) {
        this.coeDesc = coeDesc;
    }

}

