package org.teksys.pmo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.teksys.pmo.model.ImportTimeSheetEntity;
import org.teksys.pmo.service.UploadTimeSheetService;

@RestController
public class UploadTimeSheetController {

    @Autowired
    private UploadTimeSheetService uploadTimeSheetService;

    //@CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/uploadFile")
    public ImportTimeSheetEntity uploadFile(@RequestParam("file") MultipartFile file) {
        ImportTimeSheetEntity importTimeSheetEntity = uploadTimeSheetService.storeFile(file);

        return  importTimeSheetEntity;
    }

}