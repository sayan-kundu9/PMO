package org.teksys.pmo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.teksys.pmo.model.Role;

import java.util.Optional;

//import org.springframework.data.repository.query.Param;

public interface RoleRepository extends JpaRepository<Role,String> {

    Optional<Role> findByRoleName(String roleName);


}
