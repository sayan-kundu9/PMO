package org.teksys.pmo.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.teksys.pmo.dao.EmployeeRepository;
import org.teksys.pmo.dao.EmployeeSalaryPerHourRepository;
import org.teksys.pmo.dao.UploadImportEmployeeRepository;
import org.teksys.pmo.model.EmployeeEntity;
import org.teksys.pmo.model.EmployeeSalaryPerHour;
import org.teksys.pmo.model.ImportEmployee;

@Service
public class UploadImportEmployeeService {

	private static final Logger logger = LoggerFactory.getLogger(UploadImportEmployeeService.class);
	@Autowired
	private UploadImportEmployeeRepository uploadImportEmployeeRepository;
	@Autowired
	private EmployeeSalaryPerHourRepository employeeSalaryPerHourRepository;
	@Autowired
	private EmployeeRepository employeeRepository;

	public ImportEmployee storeFile(MultipartFile file) throws ParseException, IOException {

		ImportEmployee importEmployee = new ImportEmployee(file.getOriginalFilename(), "admin", new Date(),
				"admin-modifiedBy", new Date(), ingestDataToDB(file));
		return uploadImportEmployeeRepository.save(importEmployee);

	}

	List<String> ingestDataToDB(MultipartFile file) throws ParseException, IOException {
		DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		XSSFWorkbook workBook = new XSSFWorkbook(file.getInputStream());
		XSSFSheet worksheet = workBook.getSheetAt(0);
		List<String> errorList = new LinkedList<>();
		logger.info("Number of entries: {}", worksheet.getPhysicalNumberOfRows());
		LinkedList<EmployeeSalaryPerHour> employeeSalaryPerHourList = new LinkedList<>();
		EmployeeSalaryPerHour employeeSalaryPerHour;
		for (int i = 1; i < worksheet.getPhysicalNumberOfRows(); i++) {
			XSSFRow row = worksheet.getRow(i);
			employeeSalaryPerHour = new EmployeeSalaryPerHour();
			if (row.getCell(0).getRawValue() == null || row.getCell(1).getRawValue() == null
					|| row.getCell(2).getRawValue() == null) {
				errorList.add(row.getCell(0).getRawValue() == null ? String.valueOf(i) : row.getCell(0).toString());
				continue;
			}
			employeeSalaryPerHour.setCompanyEmpId(row.getCell(0).toString());
			employeeSalaryPerHour.setEffectiveDate(sdf.parse(row.getCell(1).toString()));
			employeeSalaryPerHour
					.setSalaryPerHour((new BigDecimal(row.getCell(2).toString()).toBigInteger().toString()));
			employeeSalaryPerHour.setCurrentTimeStamp(new Timestamp(new Date().getTime()));
			employeeSalaryPerHourList.add(employeeSalaryPerHour);
		}
		workBook.close();
		LinkedList<EmployeeEntity> employeeList = new LinkedList<>();
		employeeSalaryPerHourRepository.save(employeeSalaryPerHourList).forEach(t -> {
			EmployeeEntity employee = employeeRepository.findByCompanyEmpId(t.getCompanyEmpId());
			employee.setSalaryPerHour(t.getSalaryPerHour());
			employee.setEffectiveDate(t.getEffectiveDate());
			employee.setEmployeeSalaryPerHourID(t.getId());
			employeeList.add(employee);
		});
		employeeRepository.save(employeeList);
		return errorList;
	}
}
