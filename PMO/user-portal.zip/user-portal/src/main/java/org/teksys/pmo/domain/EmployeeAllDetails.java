package org.teksys.pmo.domain;

import java.io.Serializable;
import java.util.Date;


public class EmployeeAllDetails implements Serializable {

    private static final long serialVersionUID = -7788619177798333712L;

    private String EmpCompanyID;
    private String EmployeeID;
    private String FirstName;
    private String LastName;
    private String RoleID;
    private int BusinessLine;
    private String ReportTo;
    private Date HireDate;
    private Date Termination;
    private String Location;
    private String OfficePhone;
    private String MobilePhone;
    private String TekEmail;
    private String AlternateEmail;
    private int TechnologyID;
    private String CreatedBy;
    private Date createdDate;
    private String ModifiedBy;
    private Date ModifiedDate;
    private String Salary;
    private boolean VoluntaryType;
    private Date effectiveDate;
    private String parentEmployee;
    private String SalaryPerHour;
    private String EmployeeSalaryPerHourId;
    private String RoleName;
    private int PracticeID;
    private String PracticeName;
    private String PracticeHead;
    private int CompanyID;
    private String TechnologyName;

    public String getEmpCompanyID() {
        return EmpCompanyID;
    }

    public void setEmpCompanyID(String empCompanyID) {
        EmpCompanyID = empCompanyID;
    }

    public String getEmployeeID() {
        return EmployeeID;
    }

    public void setEmployeeID(String employeeID) {
        EmployeeID = employeeID;
    }
    public String getRoleID() {
        return RoleID;
    }

    public void setRoleID(String roleID) {
        RoleID = roleID;
    }

    public int getPracticeID() {
        return PracticeID;
    }

    public void setPracticeID(int practiceID) {
        PracticeID = practiceID;
    }

    public int getTechnologyID() {
        return TechnologyID;
    }

    public void setTechnologyID(int technologyID) {
        TechnologyID = technologyID;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public int getBusinessLine() {
        return BusinessLine;
    }

    public void setBusinessLine(int businessLine) {
        BusinessLine = businessLine;
    }

    public String getReportTo() {
        return ReportTo;
    }

    public void setReportTo(String reportTo) {
        ReportTo = reportTo;
    }

    public Date getHireDate() {
        return HireDate;
    }

    public void setHireDate(Date hireDate) {
        HireDate = hireDate;
    }

    public Date getTermination() {
        return Termination;
    }

    public void setTermination(Date termination) {
        Termination = termination;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public String getOfficePhone() {
        return OfficePhone;
    }

    public void setOfficePhone(String officePhone) {
        OfficePhone = officePhone;
    }

    public String getMobilePhone() {
        return MobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        MobilePhone = mobilePhone;
    }

    public String getTekEmail() {
        return TekEmail;
    }

    public void setTekEmail(String tekEmail) {
        TekEmail = tekEmail;
    }

    public String getAlternateEmail() {
        return AlternateEmail;
    }

    public void setAlternateEmail(String alternateEmail) {
        AlternateEmail = alternateEmail;
    }

    public String getCreatedBy() {
        return CreatedBy;
    }

    public void setCreatedBy(String createdBy) {
        CreatedBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getModifiedBy() {
        return ModifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        ModifiedBy = modifiedBy;
    }

    public Date getModifiedDate() {
        return ModifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        ModifiedDate = modifiedDate;
    }

    public String getSalary() {
        return Salary;
    }

    public void setSalary(String salary) {
        Salary = salary;
    }

    public boolean isVoluntaryTypepe() {
        return VoluntaryType;
    }

    public void setVoluntaryType(boolean voluntaryType) {
        VoluntaryType = voluntaryType;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }


    public String getParentEmployee() {
        return parentEmployee;
    }

    public void setParentEmployee(String parentEmployee) {
        this.parentEmployee = parentEmployee;
    }

    public String getSalaryPerHour() {
        return SalaryPerHour;
    }

    public void setSalaryPerHour(String salaryPerHour) {
        SalaryPerHour = salaryPerHour;
    }

    public boolean isVoluntaryType() {
        return VoluntaryType;
    }

//    public int getEmployeeSalaryPerHourId() {
//        return EmployeeSalaryPerHourId;
//    }
//
//    public void setEmployeeSalaryPerHourId(int employeeSalaryPerHourId) {
//        EmployeeSalaryPerHourId = employeeSalaryPerHourId;
//    }


    public String getEmployeeSalaryPerHourId() {
        return EmployeeSalaryPerHourId;
    }

    public void setEmployeeSalaryPerHourId(String employeeSalaryPerHourId) {
        EmployeeSalaryPerHourId = employeeSalaryPerHourId;
    }

    public String getRoleName() {
        return RoleName;
    }

    public void setRoleName(String roleName) {
        RoleName = roleName;
    }

    public String getPracticeName() {
        return PracticeName;
    }

    public void setPracticeName(String practiceName) {
        PracticeName = practiceName;
    }

    public String getPracticeHead() {
        return PracticeHead;
    }

    public void setPracticeHead(String practiceHead) {
        PracticeHead = practiceHead;
    }

    public int getCompanyID() {
        return CompanyID;
    }

    public void setCompanyID(int companyID) {
        CompanyID = companyID;
    }

    public String getTechnologyName() {
        return TechnologyName;
    }

    public void setTechnologyName(String technologyName) {
        TechnologyName = technologyName;
    }
}
