package org.teksys.pmo.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import javax.persistence.*;
import java.io.Serializable;

@Entity(name = "Project_Practice")
@Table(name="Project_Practice")
public class ProjectPracticeMappingEntity implements Serializable {
    @Id
    @Column(name="ProjectPracticeID", nullable=false, unique=true)
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int ProjectPracticeID;
    @Column(name="CompanyProjectID")
    private String companyProjectId;
    @Column(name="PracticeID")
    private String practiceId;
    @ManyToOne
    @JoinColumn(name="CompanyProjectID", insertable=false, updatable=false)
    @JsonBackReference
    private Project project;
    @ManyToOne
    @JoinColumn(name="PracticeID", insertable=false, updatable=false)
    private Practice practice;

    public int getProjectPracticeID() {
        return ProjectPracticeID;
    }

    public void setProjectPracticeID(int projectPracticeID) {
        ProjectPracticeID = projectPracticeID;
    }

    public String getCompanyProjectId() {
        return companyProjectId;
    }

    public void setCompanyProjectId(String companyProjectId) {
        this.companyProjectId = companyProjectId;
    }

    public String getPracticeId() {
        return practiceId;
    }

    public void setPracticeId(String practiceId) {
        this.practiceId = practiceId;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public Practice getPractice() {
        return practice;
    }

    public void setPractice(Practice practice) {
        this.practice = practice;
    }
}
