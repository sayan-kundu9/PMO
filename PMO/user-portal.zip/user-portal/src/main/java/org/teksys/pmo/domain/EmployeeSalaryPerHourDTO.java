package org.teksys.pmo.domain;

import org.teksys.pmo.model.EmployeeEntity;

import java.util.Date;

public class EmployeeSalaryPerHourDTO {
    private int id;
    private String companyEmpId;
    private Date effectiveDate;
    private String salaryPerHour;
    private EmployeeEntity employee;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCompanyEmpId() {
        return companyEmpId;
    }

    public void setCompanyEmpId(String companyEmpId) {
        this.companyEmpId = companyEmpId;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String getSalaryPerHour() {
        return salaryPerHour;
    }

    public void setSalaryPerHour(String salaryPerHour) {
        this.salaryPerHour = salaryPerHour;
    }

    public EmployeeEntity getEmployee() {
        return employee;
    }

    public void setEmployee(EmployeeEntity employee) {
        this.employee = employee;
    }

}
