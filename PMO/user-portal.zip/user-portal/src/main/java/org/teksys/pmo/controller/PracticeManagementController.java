package org.teksys.pmo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.teksys.pmo.Response.ApiResponse;
import org.teksys.pmo.domain.PracticeManagementDTO;
import org.teksys.pmo.service.PracticeManagementService;
import java.util.List;

@RestController
//@CrossOrigin(origins = "http://localhost:4200")
public class PracticeManagementController {
    @Autowired
    private PracticeManagementService practiceManagementService;

    @PostMapping( "/saveProjectContent")
    public ApiResponse saveProjectContent(@RequestBody PracticeManagementDTO practiceManagementDTO) {
        if (!practiceManagementService.isPracticeExist(practiceManagementDTO)) {
            return new ApiResponse("FAILURE","","iNTERNAL ERROR : PracticeId doesn't exist");
        }

            practiceManagementService.saveProjectContent(practiceManagementDTO);
            return new ApiResponse("SUCESS","Project Content is Saved Sucessfully","");
    }
    @GetMapping("/findAllProjectInfo")
    public List<PracticeManagementDTO> findAllProjectInfo() {
        return practiceManagementService.findAllProjectInfo();
    }


    @PostMapping("/updatePractice")
    public ApiResponse updatePractice(@RequestBody PracticeManagementDTO practiceManagementDTO) {
        if (practiceManagementService.isPracticeExist(practiceManagementDTO)) {
            return new ApiResponse("FAILURE","","iNTERNAL ERROR : PracticeId doesn't exist");
        }
        practiceManagementService.updateById(practiceManagementDTO);
        return new ApiResponse("SUCESS","Project Content is updated Sucessfully","");

    }

}
