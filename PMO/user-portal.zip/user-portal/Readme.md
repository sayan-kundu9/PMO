Running jar
=============================

##### Compile and test, build all jars

`mvn clean package`

##### Install the modules jars into your local Maven cache

`mvn install`

##### Use -DSpring.profiles.active arguement for using application-development.properties

`java -Dspring.profiles.active=development -jar user-portal-0.0.1-SNAPSHOT.jar`

###### you may need to add the same in your VM args of eclipse.

