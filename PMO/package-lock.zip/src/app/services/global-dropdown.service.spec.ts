import { TestBed, inject } from '@angular/core/testing';

import { GlobalDropdownService } from './global-dropdown.service';

describe('GlobalDropdownService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GlobalDropdownService]
    });
  });

  it('should be created', inject([GlobalDropdownService], (service: GlobalDropdownService) => {
    expect(service).toBeTruthy();
  }));
});
