import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class GlobalDropdownService {

  constructor(private http: HttpClient) { }
  //Project Dropdowns
  getClient() {
    return this.http.get('assets/common-dropdowns/client.json');
  }
  getRegion() {
    return this.http.get('assets/common-dropdowns/region.json');
  }
  getSolutionExecutives() {
    return this.http.get('assets/common-dropdowns/solutionExecutive.json');
  }
  getBdmName() {
    return this.http.get('assets/common-dropdowns/bdmName.json');
  }
// Below BDMNames,getClients, getRegions, getSolutionExecutive are not working
  getBdmNames() {
    return this.http.get('/findAllBdm');
  }
  getClients() {
    return this.http.get('/findAllClients');
  }
  getPractices() {
    return this.http.get('/findAllPractices');
  }
  getPracticePortlets() {
    return this.http.get('/assets/common-dropdowns/practicePortlet.json');
  }
  getRegions() {
    return this.http.get('/findAllRegions');
  }
  getSolutionExecutive() {
    return this.http.get('/findAllSolutionExecutive');
  }

  //Employee management-add-employee
  getBusinessLines() {
    return this.http.get('/assets/common-dropdowns/businessLine.json');
  }
  getCenterOfExcel() {
    return this.http.get('/assets/common-dropdowns/centerOfExcel.json');
  }
  getReportings() {
    return this.http.get('/assets/common-dropdowns/reportingTo.json');
  }
  getTitle() {
    return this.http.get('/assets/common-dropdowns/title.json');
  }

  getEmployees() {
    return this.http.get('/findEmpName');
  }
   getEmployeeCvs() {
    return this.http.get('/findAllEmployeeCv');
   }

  //practice expenses currency name
  getCurrencies() {
    return this.http.get('/assets/common-dropdowns/currency.json');
  }
  getExpenses() {
    return this.http.get('/findAllExpenses');
  }
  getEmployeeTitle(){
             return this.http.get('/assets/common-dropdowns/employeeTitle.json');
  }
   getEmployeeBusinessLines() {
           return this.http.get('/assets/common-dropdowns/employeeBusinessLines.json');
  }

    getEmployeeCenterOfExcellence() {
           return this.http.get('/assets/common-dropdowns/employeeCenterOfExcellences.json');
    }

     getEmployeeReportingTo() {
           return this.http.get('/assets/common-dropdowns/employeeReportingTo.json');
    }
    getEmployeeProjectName() {
           return this.http.get('/assets/common-dropdowns/employeeProjectNames.json');
    }
}

