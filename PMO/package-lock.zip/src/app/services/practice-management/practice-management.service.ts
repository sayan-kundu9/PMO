import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PracticeUpdateListModel } from '../../model/practice-management/practice-update-list-model';
import { PracticeExpensesListModel } from '../../model/practice-management/practice-expenses-list.model';

@Injectable({
  providedIn: 'root'
})
export class PracticeManagementService {

  constructor(private http: HttpClient) { }
  public dataSource:any;
  public noData: boolean;
  getPracticeExpenses(){
    
    return this.http.get('/findAllPracticeExpenses');
  }

  getProjectUpdates(){
    return this.http.get('/findAllProjectInfo');
  }

  savePracticeUpdateInfo(practiceUpdateListModel : PracticeUpdateListModel){
    
    return this.http.post('/saveProjectContent', practiceUpdateListModel);
  }

  savePracticeExpensesInfo(practiceExpensesListModel : PracticeExpensesListModel){
    return this.http.post('/savePracticeExpense', practiceExpensesListModel);
  }

  updatePracticeInfo(practiceUpdateListModel : PracticeUpdateListModel){
    return this.http.post('/updatePractice', practiceUpdateListModel);
  }

  updatePracticeExpense(practiceExpensesListModel : PracticeExpensesListModel){
    return this.http.post('/updatePracticeExpense', practiceExpensesListModel);
  }
}
