import { TestBed, inject } from '@angular/core/testing';

import { PracticeManagementService } from './practice-management.service';

describe('PracticeManagementService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PracticeManagementService]
    });
  });

  it('should be created', inject([PracticeManagementService], (service: PracticeManagementService) => {
    expect(service).toBeTruthy();
  }));
});
