import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ProjectListModel } from '../../model/project-management/project';
import { client } from '../../model/project-management/client';
@Injectable({
  providedIn: 'root'
})
export class ProjectListService {
public total:any;
  constructor(private http:HttpClient) { }
  url='/findAllProjects?page:currentPage&size:Pagesize';
  searchUrl='/findProject';
  public searchResult:any;
  getProjectList(currentPage:any,Pagesize:any){
    return this.http.get(this.url);
  }
  getProjectCount(){
    return this.http.get('/totalProjectsCount');
  }

  getClientList(){
    //return this.http.get('assets/searchProject_table.json');
    return this.http.get('/findAllClients');
  }

  private headers = new HttpHeaders({'Content-Type': 'application/json'});

  public searchProject(projectList : ProjectListModel ) {
    // console.log(projectList);
    // console.log("serve");
    return this.http.post(this.searchUrl, projectList, {headers: this.headers});

   }

   public saveProject(project : ProjectListModel) {
    console.log(project);
    return this.http.post('/addProject', project, {headers: this.headers});
  }

  updateProject(project : ProjectListModel){
    return this.http.post('/updateProject', project, {headers: this.headers});
  }

   getClientById(id:Number) {
      return this.http.get('/editClient/id');
    }
  public saveClient(clients : client) {
    console.log(clients);
    return this.http.post('/addClient', clients, {headers: this.headers});
  }

  public updateClient(clientId : Number, clientbody: any) {
    return this.http.post(`/editClient/${clientId}`, clientbody, {headers: this.headers});
  }

}
