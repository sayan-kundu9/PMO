
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { EmployeeSearchModel } from '../../model/employee-management/employee-search.model';
import { Employee } from '../../model/employee-management/employee';
import { map } from 'rxjs/operators';
import { EditEmployee } from '../../model/employee-management/editEmployee';
import { Response, ResponseContentType } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeManagementService {
  public noData: boolean;
 constructor(private http:HttpClient) { }
  url='/getAllEmployees';
    addUrl = '/addEmployee';
  empDL = '/employeeDL';
getEmployeeList(){
               return this.http.get(this.url);
  }
  private headers = new HttpHeaders({'Content-Type': 'application/json'});

  public  search(employeeSearchModel : EmployeeSearchModel ) {

    return this.http.post('/findEmployee' , employeeSearchModel, {headers: this.headers}).pipe(
      map((data) => {
        return [].map.call(data, d => {
          console.log(d);
          const em=d.employee;
          const pr=d.project;
          d = {...d, ...em, ...pr};
         //  d = {...d, ...pr};
          return d;
        })
      })
  );
   }

   public saveEmp(employee : Employee) {
     return this.http.post('/addEmployee', employee, {headers: this.headers});
   }

   public updateEmp(editEmployee) {
    return this.http.put('/editEmployee', editEmployee, {headers: this.headers});
  }

    public updateEmployeeDL(updateEmployeeDL){
      return this.http.put('/addEmpSal', updateEmployeeDL, {headers: this.headers});
    }

    public employeeDL(employeeDL){
      return this.http.post(this.empDL, employeeDL ,{headers: this.headers});
    }
    public deleteEmpcv(cv){
      return this.http.post(`/deleteCv/${cv}`, {} , {headers: this.headers} );
    }
    public downloadEmpcv(cv) {
      return this.http.get(`downloadCv/${cv}`, { responseType: 'blob'})
    }
    public getEmployeeCvById(cv) {
      return this.http.get(`findEmployeeCvById/${cv}`);
     }

    public submitCv(empId,empCv) {
      let formData:FormData = new FormData();
      formData.append('file', empCv, empCv.name);
      let formHeaders = new HttpHeaders();
      formHeaders.append('Content-Type', 'multipart/form-data');
      formHeaders.append('Accept', 'application/json');
      return this.http.post(`uploadCv/${empId}`,formData, {headers: formHeaders});
    }

    public  importEmployee(timesheetFile : any ) {
            let formData:FormData = new FormData();
             formData.append('file', timesheetFile, timesheetFile.name);
              let formHeaders = new HttpHeaders();
             formHeaders.append('Content-Type', 'multipart/form-data');
             formHeaders.append('Accept', 'application/json');
           return this.http.post('/importEmployeeFile', formData, {headers: formHeaders});
      }

      public  importEmployees(importEmployeeFile : any ) {
        let formData:FormData = new FormData();
         formData.append('file', importEmployeeFile, importEmployeeFile.name);
         let formHeaders = new HttpHeaders();
         formHeaders.append('Content-Type', 'multipart/form-data');
         formHeaders.append('Accept', 'application/json');
       return this.http.post('/importEmployeesFile', formData, {headers: formHeaders});
  }

}
