import { Injectable } from '@angular/core';
import { HttpClient , HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Timesheet } from '../../model/timesheet/timesheet';
@Injectable({
  providedIn: 'root'
})
export class TimesheetService {

  constructor(public http: HttpClient) { }
  searchTimeUrl='/searchEmpTimeSheet';
   private headers = new HttpHeaders();
   public  searchTimesheet(timesheet : any ) {
     console.log(timesheet);
      this.headers.append('Content-Type', 'application/json');
      return this.http.post('/searchEmpTimeSheet', timesheet, {headers: this.headers});
     }
     public  monthList() {
      return this.http.get('/assets/common-dropdowns/monthList.json');
      }
     public  uploadTimesheet(timesheetFile : any ) {
            let formData:FormData = new FormData();
             formData.append('file', timesheetFile, timesheetFile.name);
             this.headers.append('Content-Type', 'multipart/form-data');
             this.headers.append('Accept', 'application/json');
           return this.http.post('/uploadFile', formData, {headers: this.headers});
      }
}
