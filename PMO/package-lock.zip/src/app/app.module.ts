import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import {UrlPermission} from "./urlPermission/url.permission";
//import { SearchProjectComponent } from './components/project-management/search-project/search-project/search-project.component';
//import { HomeComponent } from './components/home/home.component';
//import { ProjectListTableComponent } from './components/project-management/search-project/project-list-table/project-list-table.component';
import { HomeComponent } from './home/home.component';
import { SearchProjectComponent } from './home/project-management/search-project/search-project/search-project.component';
import { ProjectListTableComponent } from './home/project-management/search-project/project-list-table/project-list-table.component';
import {HttpModule} from "@angular/http";
import {routing} from "./app.routing";

//Material imports
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MatButtonModule, MatCheckboxModule,MatFormFieldModule, MatInputModule, MatSelectModule, MatSortModule } from '@angular/material';
import { HttpClientModule } from '@angular/common/http';
import {MatTableModule} from '@angular/material/table';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { ErrorStateMatcher } from '@angular/material';
import { MatNativeDateModule } from '@angular/material';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatRadioModule} from '@angular/material/radio';
import {MatIconModule} from '@angular/material/icon';
import {MatMenuModule} from '@angular/material';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatToolbarModule } from '@angular/material/toolbar';
import { CdkTableModule } from '@angular/cdk/table';
import {MatProgressBarModule} from '@angular/material/progress-bar';



// import { LoginPageComponent1 } from './components/user/login-page/login-page.component';
import { UserComponent } from './user/user.component';
import { LoginPageComponent } from './user/login-page/login-page.component';
import { NavBarComponent } from './home/nav-bar/nav-bar.component';
import { FooterComponent } from './home/footer/footer.component';
import { HeaderComponent } from './home/header/header.component';
import { TimesheetComponent } from './home/timesheet/timesheet/timesheet.component';
import { TimesheetTableComponent } from './home/timesheet/timesheet-table/timesheet-table.component';
import { AddEmployeeComponent } from './home/employee-management/add-employee/add-employee.component';
import { PracticeExpensesComponent } from './home/practice-management/practice-expenses/practice-expenses/practice-expenses.component';
import { ExpenseDatatableComponent } from './home/practice-management/practice-expenses/expense-datatable/expense-datatable.component';
import { EmployeeSearchProjectComponent } from './home/employee-management/search-employee/employee-search/employee-search-project.component';
import { EmployeeProjectListTableComponent } from './home/employee-management/search-employee/employee-project-list-table/employee-project-list-table.component';
import { DollerEuroReplacementPipe } from './home/practice-management/practice-expenses/expense-datatable/doller-euro-replacement.pipe';
import { YesOrNoPipe } from './home/practice-management/practice-expenses/expense-datatable/yes-or-no.pipe';
import { ReplaceUnderscorePipe } from '../app/pipes/replaceUnderscore.pipe';

import {MatDialogModule} from '@angular/material';
import { EditEmployeeProjectComponent } from './home/employee-management/search-employee/edit-employee-project/edit-employee-project.component';
import { EditProjectComponent } from './home/project-management/search-project/edit-project/edit-project.component';
import { UploadDlComponent } from '../app/home/employee-management/upload-dL/upload-dL.component';

import { AddPracticeUpdatesComponent } from './home/practice-management/practice-updates/add-practice-updates/add-practice-updates.component';
import { ProjectUpdateDatatableComponent } from './home/practice-management/practice-updates/project-update-datatable/project-update-datatable.component';
import { EditProjectUpdatePopupComponent } from './home/practice-management/practice-updates/edit-project-update-popup/edit-project-update-popup.component';
import { AddProjectComponent } from './home/project-management/add-project/add-project.component';
import { AddClientComponent } from './home/project-management/add-clients/add-client/add-client.component';
import { ClientListTableComponent } from './home/project-management/add-clients/client-list-table/client-list-table.component';
import { EditClientComponent } from '../app/home/project-management/add-clients/edit-client/edit-client.component';
import { EditPracticeExpenseComponent } from './home/practice-management/practice-expenses/edit-practice-expense/edit-practice-expense.component';
import { UploadEmployeeCvComponent } from './home/employee-management/upload-cv/upload-employee-cv/upload-employee-cv.component';
import { FileDropModule } from 'ngx-file-drop';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { ChartsComponent } from './home/charts/charts.component';
import { ChartsModule } from 'ng2-charts';
import { ImportEmployeeComponent } from './home/employee-management/import-employee/import-employee.component';

import { ToastrModule } from 'ngx-toastr';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    SearchProjectComponent,
    ProjectListTableComponent,
    LoginPageComponent,
    UserComponent,
    NavBarComponent,
    FooterComponent,
    HeaderComponent,
    TimesheetComponent,
    TimesheetTableComponent,
    AddEmployeeComponent,
    PracticeExpensesComponent,
    ExpenseDatatableComponent,
    EmployeeSearchProjectComponent,
    EmployeeProjectListTableComponent,
    DollerEuroReplacementPipe,
    YesOrNoPipe,
    ReplaceUnderscorePipe,
    EditEmployeeProjectComponent,
    AddPracticeUpdatesComponent,
    ProjectUpdateDatatableComponent,
    EditProjectUpdatePopupComponent,
    AddProjectComponent,
    AddClientComponent,
    ClientListTableComponent,
    EditClientComponent,
    EditProjectComponent,
    UploadDlComponent,
    EditPracticeExpenseComponent,
    UploadEmployeeCvComponent,
    ChartsComponent,
    ImportEmployeeComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    routing,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    BrowserAnimationsModule,
    MatMenuModule,
    MatButtonModule,
        MatCheckboxModule,
        MatSelectModule,
        HttpClientModule,
        MatTableModule,
        MatSortModule,
        MatPaginatorModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatRadioModule,
        ReactiveFormsModule,
        MatGridListModule,
        MatToolbarModule,
        CdkTableModule,MatDialogModule,
        MatProgressBarModule,
        Ng4LoadingSpinnerModule.forRoot(),
        MatProgressBarModule,
        FileDropModule,
        ChartsModule,
        FileDropModule,
        ToastrModule.forRoot(),


  ],
  providers: [UrlPermission],
  entryComponents: [EditEmployeeProjectComponent, EditProjectUpdatePopupComponent,EditProjectComponent, EditPracticeExpenseComponent,ImportEmployeeComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
