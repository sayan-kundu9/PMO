import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PracticeExpensesComponent } from './practice-expenses.component';

describe('PracticeExpensesComponent', () => {
  let component: PracticeExpensesComponent;
  let fixture: ComponentFixture<PracticeExpensesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PracticeExpensesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PracticeExpensesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
