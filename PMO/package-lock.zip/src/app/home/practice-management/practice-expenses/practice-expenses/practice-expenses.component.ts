import { Component, OnInit, Directive, HostListener } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { GlobalDropdownService } from '../../../../services/global-dropdown.service';

import { Practices, YesNo, Expenses, Currency } from '../../../../model/global-dropdown.model';
import { Router } from "@angular/router";
import { PracticeExpensesListModel } from '../../../../model/practice-management/practice-expenses-list.model';
import { PracticeManagementService } from '../../../../services/practice-management/practice-management.service';

import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-practice-expenses',
  templateUrl: './practice-expenses.component.html',
  styleUrls: ['./practice-expenses.component.css']
})
export class PracticeExpensesComponent implements OnInit {

  public practiceExpensesListModel: PracticeExpensesListModel = new PracticeExpensesListModel();

  public practices: Practices[];
  public currency: Currency[];
  public expense: Expenses[];

  amountControl = new FormControl('', [Validators.required]);
  expenceControl = new FormControl('', [Validators.required]);
  practiceControl = new FormControl('', [Validators.required]);
  pickerControl = new FormControl('', [Validators.required]);
  currencyControl = new FormControl('', [Validators.required]);
  expenceDescControl = new FormControl('', [Validators.required]);

  constructor(private toastr: ToastrService, private practiceManagementService: PracticeManagementService, private globalDropdownService: GlobalDropdownService, private router: Router) { }

  public plans: YesNo[] = [
    { value: 'Y', name: 'Yes' },
    { value: 'N', name: 'No' }
  ];

  home() {
    this.router.navigate(['home']);
  }

  showSuccess() {
    this.toastr.success('practice expense saved', 'SUCCESS',{
      positionClass: 'toast-top-center',
    });
    
  }

  ngOnInit() {

    this.globalDropdownService.getPractices().subscribe((practices: any) => {
      this.practices = practices;
    });

    this.globalDropdownService.getCurrencies().subscribe((dataPractices: any) => {
      this.currency = dataPractices.currency;
    });

    this.globalDropdownService.getExpenses().subscribe((expenses: any) => {
      this.expense = expenses;
    });
  }

  savePracticeExpensesInfo() {
    this.practiceManagementService.savePracticeExpensesInfo(this.practiceExpensesListModel).subscribe(data => {
      this.toastr.success('practice expense saved', 'SUCCESS',{
        positionClass: 'toast-top-center',
      });
      
    });
  }

}
