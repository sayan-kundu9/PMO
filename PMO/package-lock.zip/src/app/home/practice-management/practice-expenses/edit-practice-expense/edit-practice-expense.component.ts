import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { PracticeExpensesListModel } from '../../../../model/practice-management/practice-expenses-list.model';
import { Practices, Currency, Expenses, YesNo } from '../../../../model/global-dropdown.model';
import { FormControl, Validators } from '@angular/forms';
import { GlobalDropdownService } from '../../../../services/global-dropdown.service';
import { PracticeManagementService } from '../../../../services/practice-management/practice-management.service';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-edit-practice-expense',
  templateUrl: './edit-practice-expense.component.html',
  styleUrls: ['./edit-practice-expense.component.css']
})
export class EditPracticeExpenseComponent implements OnInit {

  public practiceExpensesListModel: PracticeExpensesListModel = new PracticeExpensesListModel();

  constructor(private toastr: ToastrService, private practiceManagementService: PracticeManagementService, private globalDropdownService: GlobalDropdownService, private dialogRef: MatDialogRef<EditPracticeExpenseComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {

    this.practiceExpensesListModel.practiceExpenseId = data.dataKey.practiceExpenseId;
    this.practiceExpensesListModel.practiceId = data.dataKey.practiceId;
    this.practiceExpensesListModel.expensesId = data.dataKey.expensesId;
    this.practiceExpensesListModel.amount = data.dataKey.amount;
    this.practiceExpensesListModel.currency_name = data.dataKey.currency_name;
    this.practiceExpensesListModel.dateOfExpense = new Date(data.dataKey.dateOfExpense);
    this.practiceExpensesListModel.expenses_description = data.dataKey.expenses_description;
    this.practiceExpensesListModel.planned = data.dataKey.planned;
  }

  public practices: Practices[];
  public currency: Currency[];
  public expense: Expenses[];

  amountControl = new FormControl('', [Validators.required]);
  expenceControl = new FormControl('', [Validators.required]);
  practiceControl = new FormControl('', [Validators.required]);
  pickerControl = new FormControl('', [Validators.required]);
  currencyControl = new FormControl('', [Validators.required]);
  expenceDescControl = new FormControl('', [Validators.required]);

  public plans: YesNo[] = [
    { value: 'Y', name: 'Yes' },
    { value: 'N', name: 'No' }
  ];

  ngOnInit() {

    this.globalDropdownService.getPractices().subscribe((practices: any) => {
      this.practices = practices;
    });

    this.globalDropdownService.getCurrencies().subscribe((dataPractices: any) => {
      this.currency = dataPractices.currency;
    });

    this.globalDropdownService.getExpenses().subscribe((expenses: any) => {
      this.expense = expenses;
    });
  }

  updatePracticeExpense() {
    this.practiceManagementService.updatePracticeExpense(this.practiceExpensesListModel).subscribe(data => {
      this.dialogRef.close();
      this.toastr.success('practice expense updated', 'SUCCESS',{
        positionClass: 'toast-top-center',
        //timeOut: 5000,
    });
    });
  }

}
