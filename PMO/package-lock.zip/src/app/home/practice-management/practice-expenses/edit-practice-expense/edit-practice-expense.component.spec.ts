import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPracticeExpenseComponent } from './edit-practice-expense.component';

describe('EditPracticeExpenseComponent', () => {
  let component: EditPracticeExpenseComponent;
  let fixture: ComponentFixture<EditPracticeExpenseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditPracticeExpenseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditPracticeExpenseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
