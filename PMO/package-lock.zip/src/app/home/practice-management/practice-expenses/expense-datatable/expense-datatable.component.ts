import { Component, OnInit, ViewChild, ElementRef, ContentChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort, MatDialog } from '@angular/material';
import { PracticeManagementService } from '../../../../services/practice-management/practice-management.service';
import { EditPracticeExpenseComponent } from '../edit-practice-expense/edit-practice-expense.component';

@Component({
  selector: 'app-expense-datatable',
  templateUrl: './expense-datatable.component.html',
  styleUrls: ['./expense-datatable.component.css'],
})

export class ExpenseDatatableComponent implements OnInit {

  private dataSource: any;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  displayedColumns: string[] = ['practice', 'expenses', 'currency', 'planned', 'date', 'amount', 'actions'];

  constructor(public dialog: MatDialog, private practiceManagementService: PracticeManagementService) { }

  ngOnInit() {
    this.practiceManagementService.getPracticeExpenses().subscribe((data: any) => {
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.sortingDataAccessor = (item, property) => {
        switch (property) {
          case 'practice': return item.practice.practiceName;
          case 'expenses': return item.expenses.expensesName;
          case 'currency': return item.currency_name;
          case 'date': return item.dateOfExpense;
          default: return item[property];
        }
      };
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
    });
  }

  displayEditWindow = false;

  openDialog($event, dataKey) {
    const width = '3000px';
    const height = '400px';
    this.displayEditWindow = true;
    const dialogRef = this.dialog.open(EditPracticeExpenseComponent, { width, height, data: { dataKey } });
    dialogRef.afterClosed().subscribe(result => { });
  }
}
