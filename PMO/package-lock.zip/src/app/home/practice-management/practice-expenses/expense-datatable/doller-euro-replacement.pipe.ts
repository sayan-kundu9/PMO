import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dollerEuroReplacement'
})
export class DollerEuroReplacementPipe implements PipeTransform {

  transform(value: string): string {
    if (value === 'D') {
      return value.replace(value, '$');
    } else {
     return value.replace(value, '€'); 
    }
  }

}
