import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpenseDatatableComponent } from './expense-datatable.component';

describe('ExpenseDatatableComponent', () => {
  let component: ExpenseDatatableComponent;
  let fixture: ComponentFixture<ExpenseDatatableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExpenseDatatableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpenseDatatableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
