import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'yesOrNo'
})
export class YesOrNoPipe implements PipeTransform {

  transform(value: string): string {
    if (value === 'Y') {
      return value.replace(value, 'Yes');
    } else {
      return value.replace(value, 'No');
    }
  }

}
