import { DollerEuroReplacementPipe } from './doller-euro-replacement.pipe';

describe('DollerEuroReplacementPipe', () => {
  it('create an instance', () => {
    const pipe = new DollerEuroReplacementPipe();
    expect(pipe).toBeTruthy();
  });
});
