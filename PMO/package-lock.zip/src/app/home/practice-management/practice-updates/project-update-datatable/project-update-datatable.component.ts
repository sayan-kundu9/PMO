import { Component, OnInit, ViewChild, Input, SimpleChanges } from '@angular/core';
import { PracticeUpdateListModel } from '../../../../model/practice-management/practice-update-list-model';
import { PracticeManagementService } from '../../../../services/practice-management/practice-management.service';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { Practices } from '../../../../model/global-dropdown.model';
import { GlobalDropdownService } from '../../../../services/global-dropdown.service';
import { EditProjectUpdatePopupComponent } from '../edit-project-update-popup/edit-project-update-popup.component';
import {MatDialog} from '@angular/material';

@Component({
  selector: 'app-project-update-datatable',
  templateUrl: './project-update-datatable.component.html',
  styleUrls: ['./project-update-datatable.component.css'],
  providers: [ EditProjectUpdatePopupComponent]
})
export class ProjectUpdateDatatableComponent implements OnInit {
  
   // @Input('dataSource') dataSource : any;
  
   practices: Practices[];

   displayEditWindow = false;

  // displayedColumns: string[] = ['position','practiceContent', 'active', 'deleted', 'id', 'practiceHead', 'actions'];
  displayedColumns: string[] = ['position','practiceContent', 'active', 'actions'];

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
 
  constructor(public dialog: MatDialog, private practiceManagementService: PracticeManagementService, private globalDropdownService : GlobalDropdownService) { }
  
  ngOnInit() {

    this.globalDropdownService.getPracticePortlets().subscribe((dataPractices:any)=>{
      this.practices = dataPractices.practicePortlet;
       });

    //this.practiceManagementService.getProjectUpdates().subscribe((data: any) => {
     
      this.practiceManagementService.dataSource = new MatTableDataSource(this.practiceManagementService.dataSource);
      this.practiceManagementService.dataSource.sort = this.sort;
      this.practiceManagementService.dataSource.paginator = this.paginator;
    //});
  }

//   ngOnChanges(changes: SimpleChanges) {
//     this.practiceManagementService.dataSource = new MatTableDataSource(this.practiceManagementService.dataSource);
//     console.log("Get the data Child -->>",this.practiceManagementService.dataSource)
//            this.practiceManagementService.dataSource.sort = this.sort;
//            this.practiceManagementService.dataSource.paginator = this.paginator;
//  }

  // onSelect(val){
  //   console.log(val);
  //   this.practiceManagementService.getProjectUpdates().subscribe((data: any) => {
  //     this.practiceManagementService.dataSource = data.filter(x => x.practicePortlet.id  === val) ;
  //   });
  // }



  openEditDialog($event,object){
    this.displayEditWindow= true;
    console.log(' value - ',object);
    let dialogRef = this.dialog.open(EditProjectUpdatePopupComponent, 
      {
        //disableClose: true,
        width: '1000px',
        height: '300px',
        data: {
          element: object
        } 
        
      }
    );
    console.log('Dialog data ',dialogRef);  
    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  getColor(x){
    if (!x) {
      return "silver";
    }
  }
  
}



