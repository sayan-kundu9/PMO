import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectUpdateDatatableComponent } from './project-update-datatable.component';

describe('ProjectUpdateDatatableComponent', () => {
  let component: ProjectUpdateDatatableComponent;
  let fixture: ComponentFixture<ProjectUpdateDatatableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectUpdateDatatableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectUpdateDatatableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
