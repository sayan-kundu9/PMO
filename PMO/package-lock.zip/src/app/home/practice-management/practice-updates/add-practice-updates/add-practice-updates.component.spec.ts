import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPracticeUpdatesComponent } from './add-practice-updates.component';

describe('AddPracticeUpdatesComponent', () => {
  let component: AddPracticeUpdatesComponent;
  let fixture: ComponentFixture<AddPracticeUpdatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddPracticeUpdatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPracticeUpdatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
