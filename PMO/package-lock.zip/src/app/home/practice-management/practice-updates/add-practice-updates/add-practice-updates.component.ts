import { Component, OnInit } from '@angular/core';
import { Validators, FormControl } from '@angular/forms';
import { Practices1 } from '../../../../model/global-dropdown.model';
import { GlobalDropdownService } from '../../../../services/global-dropdown.service';
import { Router } from '@angular/router';
import { PracticeManagementService } from '../../../../services/practice-management/practice-management.service';
import { PracticeUpdateListModel } from '../../../../model/practice-management/practice-update-list-model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-practice-updates',
  templateUrl: './add-practice-updates.component.html',
  styleUrls: ['./add-practice-updates.component.css']
})
export class AddPracticeUpdatesComponent implements OnInit {
  public practices: Practices1[];

  public dataSource: any;

  public practiceUpdateListModel: PracticeUpdateListModel = new PracticeUpdateListModel();

  practiceControl = new FormControl('', [Validators.required]);
  contentControl = new FormControl('', [Validators.required]);

  constructor(private toastr: ToastrService, private practiceManagementService: PracticeManagementService, private globalDropdownService: GlobalDropdownService, private router: Router) {
    // this.practiceManagementService.getProjectUpdates().subscribe((data: any) => {
    //   this.dataSource = data;
    // });
  }

  ngOnInit() {
    this.globalDropdownService.getPracticePortlets().subscribe((dataPractices: any) => {
      this.practices = dataPractices.practicePortlet;
      //this.practiceUpdateListModel.isActive = true;
      this.practiceUpdateListModel.portletPracticeID = this.practices[0].value;
    });

    //  this.practiceManagementService.getProjectUpdates().subscribe((data: any) => {
    //   this.dataSource = data;
    // });
  }

  onSelect(val) {

    //console.log(val);
    this.practiceManagementService.getProjectUpdates().subscribe((data: any) => {
      //console.log("On select data -->>",data);
      this.practiceManagementService.dataSource = data.filter(x => x.portletPracticeID === val);
      if (this.practiceManagementService.dataSource.length === 0) {
        this.practiceManagementService.noData = true;
        console.log(this.practiceManagementService.noData);
      } else {
        this.practiceManagementService.noData = false;
        console.log(this.practiceManagementService.noData);
      }
      //console.log('length -> ', this.practiceManagementService.dataSource.length)
      //console.log("On select amo data Source -->>", this.practiceManagementService.dataSource);
    });
  }

  savePracticeUpdateInfo() {
    //console.log("in ts");
    //console.log("just before save")
    //console.log(this.practiceUpdateListModel);
    // this.practiceUpdateListModel.modifiedBy="0";
    // if(this.practiceUpdateListModel.isActive){
    //   this.practiceUpdateListModel.modifiedBy="1";
    // }
    //console.log(this.practiceUpdateListModel);
    this.practiceManagementService.savePracticeUpdateInfo(this.practiceUpdateListModel).subscribe(data => {
     
      this.toastr.success('practice created', 'SUCCESS', {
        positionClass: 'toast-top-center',
      });

    });

  }

  home() {
    this.router.navigate(['home']);
  }

}
