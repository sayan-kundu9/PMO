import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditProjectUpdatePopupComponent } from './edit-project-update-popup.component';

describe('EditProjectUpdatePopupComponent', () => {
  let component: EditProjectUpdatePopupComponent;
  let fixture: ComponentFixture<EditProjectUpdatePopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditProjectUpdatePopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditProjectUpdatePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
