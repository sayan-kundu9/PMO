import { Component, OnInit, Inject } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { PracticeManagementService } from '../../../../services/practice-management/practice-management.service';
//import { PracticeExpenseListModel } from '../../../../model/practice-management/practice-expense-list.model';
import { PracticeUpdateListModel } from '../../../../model/practice-management/practice-update-list-model';
//import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-edit-project-update-popup',
  templateUrl: './edit-project-update-popup.component.html',
  styleUrls: ['./edit-project-update-popup.component.css']
})
export class EditProjectUpdatePopupComponent implements OnInit {

  contentControl = new FormControl('', [Validators.required]);
  
  dataSource: any;
  practiceUpdateListModel: PracticeUpdateListModel = new PracticeUpdateListModel();

  constructor(private toastr: ToastrService, private practiceManagementService: PracticeManagementService, private dialogRef: MatDialogRef<EditProjectUpdatePopupComponent>, @Inject(MAT_DIALOG_DATA) public data: any) { 
    
    // for preventing destry the popup clicking outside
    //dialogRef.disableClose = true;
    
    //auto check in popup if this is an active project
    this.practiceUpdateListModel.id=data.element.id;
    this.practiceUpdateListModel.practiceContent = data.element.practiceContent;
    if (data.element.active) {
      this.practiceUpdateListModel.active = true;
    }
    


  }

  updateData() {
    
    console.log(this.practiceUpdateListModel);
    console.log(this.practiceUpdateListModel.isDeleted);
    this.practiceManagementService.updatePracticeInfo(this.practiceUpdateListModel).subscribe (data =>   { 
      this.dialogRef.close();
      this.toastr.success('practice updated', 'SUCCESS',{
        positionClass: 'toast-top-center',
    });
  });
  }

  ngOnInit() {
  }

  

}
