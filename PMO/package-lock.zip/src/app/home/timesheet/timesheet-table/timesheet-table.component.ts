import { OnInit, Component, ViewChild } from '@angular/core';
import { DataSource } from '@angular/cdk/collections';
import { Observable,BehaviorSubject } from 'rxjs';
import {FormControl} from "@angular/forms";
//import { Timesheet} from '../domain/timesheet';
//import { TimesheetService } from '../service/timesheet.service';
import { Timesheet } from '../../../model/timesheet/timesheet';
import { TimesheetService } from '../../../services/timesheet/timesheet.service';

import {MatPaginator, MatTableDataSource,MatSort} from '@angular/material';
import {Router} from "@angular/router";
@Component({
  selector: 'app-timesheet-table',
  templateUrl: './timesheet-table.component.html',
  styleUrls: ['./timesheet-table.component.css']
})

export class TimesheetTableComponent implements OnInit {
  selectedMonth :any;
timesheetList:any[];
  data: any = {};
  year: number;
  month:any;
  curentmonth: string;
  showdata:any;
  searchdata:any;
  monthList : any[];
  monthJsonList : any[];
   //monthList = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  //monthList = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']
  toppings = new FormControl();
  toppingList: string[] = ['AMO', 'Application Development', 'Data Services', 'Enablers', 'PMO', 'Quality Assurance'];
  dataSource :any;
  displayedColumns : string [] = [];
  columns : object [] = [];
  tableData : string [] = [];
  getdata$:Observable<Timesheet[]>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
   @ViewChild(MatSort) sort: MatSort;
  constructor(public service: TimesheetService,private router: Router) {
  }
  ngOnInit() {
    /*this.getdata$ = this.service.getTimeSheetData();
    this.getdata$.subscribe(data => {
      this.showdata=data;
      this.searchdata=data;
      this.updateTableData();
    });*/
  this.allMonths();
   
   
  }
  allMonths() {
    this.service.monthList().subscribe((data:any) => {
     this.monthJsonList = data.month;
      this.monthList = data.month.map((month)=>{
        return month.name;
      });
      this.getCurrentMonth(null);
      this.formSearch();
    });
  }
  updateTableData(){
    this.getCurrentyear();
    this.displayedColumns = this.generateHeaders ();
    this.columns = this.generateColumns ();
    this.tableData = this.generateData ();
    this.dataSource = new MatTableDataSource<any>(this.tableData);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  generateHeaders() {
    let displayedColumns : string [] = ['PS_Employee_ID', 'Employee_Name', 'Project_Id', 'Project_Name','Year','Month','Type'];
    let totaldays=new Date(this.year, Number(this.curentmonth), 0).getDate();
    let mm=this.monthList[Number(this.curentmonth)];
    for(let m=1;m<=totaldays;m++){
      displayedColumns.push ((mm+"-"+m).toString());
    }
    displayedColumns.push('Total');
    return displayedColumns;
  }
  generateColumns() {
    let columnObj : object;
    let columns : object[] = [{'columnDef':'PS_Employee_ID','header':'PS_Employee_ID','cell':[]},
      {'columnDef':'Employee_Name','header':'Employee_Name','cell':[]},
      {'columnDef':'Project_Id','header':'Project_Id','cell':[]},
      {'columnDef':'Project_Name','header':'Project_Name','cell':[]},
      {'columnDef':'Year','header':'Year','cell':[]},
      {'columnDef':'Month','header':'Month','cell':[]},
      {'columnDef':'Type','header':'Type','cell':[]}
      ];
    let totaldays=new Date(this.year, Number(this.curentmonth), 0).getDate();
    let mm=this.monthList[Number(this.curentmonth)];
    for(let m=1;m<=totaldays;m++){
      columnObj = new function()
      {
        this.columnDef = ((mm+"-"+m).toString());
        this.header    = ((mm+"-"+m).toString());
        this.cell      = [];
      }
      columns.push(columnObj);
    }
    let totalsec={'columnDef':'Total','header':'Total','cell':[]};
    columns.push(totalsec);
    return columns;
  }

  generateData () {
    let tableData : any [] = [];
    for(let i=0;i<this.searchdata.length;i++){
      let tableRow={};
      tableRow = {
        'PS_Employee_ID': this.searchdata[i].empTimeSheetCompoundKey.companyEmpId,
        'Employee_Name': this.searchdata[i].empName,
        'Project_Id': this.searchdata[i].empTimeSheetCompoundKey.companyProjectId,
        'Project_Name': this.searchdata[i].projectName,
        'Year': this.searchdata[i].empTimeSheetCompoundKey.year,
        'Month': this.searchdata[i].empTimeSheetCompoundKey.month,
        'Type': this.searchdata[i].empTimeSheetCompoundKey.type
      };
      let totaldays=new Date(this.year, Number(this.curentmonth), 0).getDate();
      let mm=this.monthList[Number(this.curentmonth)];
      for(let j=0;j<totaldays;j++){
        let day='day'+(j+1);
        tableRow[(mm+"-"+(j+1)).toString()]=this.searchdata[i][day];
      }
      tableRow['Total']=this.searchdata[i].total;
      tableData.push(tableRow);
    }
    return tableData;

  }
  getCurrentMonth(evt){
  if (evt) {
    this.data.month=evt;
  }else{
    let d = new Date();
    this.curentmonth = (d.getMonth()).toString();
    this.data.month = this.monthJsonList[this.curentmonth].value;
    this.selectedMonth=this.monthJsonList[this.curentmonth].value;
    }
  }
  getCurrentyear(){
    let d = new Date();
    this.year = d.getFullYear();
  }
  onChange(){
    // this.getCurrentMonth();
    if(this.data.year){
      this.year=this.data.year;
    }else{
      this.getCurrentyear();
    }

  }
  selectMonth(event) {
    this.getCurrentMonth(event.source.value);
  }
  formSearch(){
    let parseObj = {}
    this.onChange();
    let reqData={};
    for (var propName in this.data) { 
      if (this.data[propName] != '' ) {
        parseObj[propName] = this.data[propName];
      }
    }
    reqData['empTimeSheetCompoundKey']=parseObj;
    console.log(reqData);
        this.service.searchTimesheet(reqData).subscribe((data:any[])=>{
                  if(data){
                  this.searchdata = data;
                      this.updateTableData();
                }
      });
}
 home() {
          this.router.navigate(['home']);
        }
}