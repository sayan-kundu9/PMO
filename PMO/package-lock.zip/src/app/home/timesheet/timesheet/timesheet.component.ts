import {Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { TimesheetService } from '../../../services/timesheet/timesheet.service';
import {Router} from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-timesheet',
  templateUrl: './timesheet.component.html',
  styleUrls: ['./timesheet.component.css']
})
export class TimesheetComponent implements OnInit {
  data: any = {};
  msg:string =null;
  errorMsg:string=null;
  year: number;
  showerror = false;
  progresbar= false;
  status= false;
  curentmonth: string;
  fileToUpload: File  = null;
  filename: string ='Choose file';
  monthList = ['Jan', 'Feb', 'Mar', 'April', 'May', 'June', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  toppings = new FormControl();
  toppingList: string[] = ['AMO', 'Application Development', 'Data Services', 'Enablers', 'PMO', 'Quality Assurance'];
  constructor(private toastr: ToastrService, public service: TimesheetService,private router: Router) { }

  ngOnInit() {
  }

  onFileInput(files: FileList) {
    let fileItem = files.item(0);
    this.filename=fileItem.name;
    this.fileToUpload = fileItem;
    this.showerror=false;
    this.status=false;
  }
  uploadTimesheet()
 {

 console.log(this.fileToUpload);
     if(this.fileToUpload){
      this.showerror=false;
      this.progresbar=true;
       this.service.uploadTimesheet(this.fileToUpload).subscribe((data:any)=>{
                 if(data['fileName']){
                       this.filename='Choose file';
                       this.fileToUpload=null;
                       this.progresbar=false;
                 }
                if (data.createdBy==null){
                  this.toastr.error('upload failed', 'Error', {
                    positionClass: 'toast-top-center',
                    //timeOut: 3000
                  });
                  this.errorMsg="FAILED TO UPLOAD "
                }else{
                 this.msg="SUCCESS"
                 this.toastr.success('timesheet uploaded', 'SUCCESS',{
                  positionClass: 'toast-top-center',
              });
                }
               console.log('Upload timesheet data ',data)

       });

     }else{
       this.showerror=true;
       this.toastr.info('choose a file first', 'Error', {
        positionClass: 'toast-top-center',
        //timeOut: 3000
      });

     }
   }


}
