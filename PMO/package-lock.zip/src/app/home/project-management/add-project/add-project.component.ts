import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { GlobalDropdownService } from '../../../services/global-dropdown.service';
import { BdmNames, Clients, Practices, Regions, SolutionExecutives } from '../../../model/global-dropdown.model';
import {Router} from "@angular/router";
import { ProjectListModel } from '../../../model/project-management/project';
import { ProjectListService } from '../../../services/project-management/project-list.service';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms'
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']
})
export class AddProjectComponent implements OnInit {
  public regions: Regions[];
  public namesOfBDMs: BdmNames[];
  public clients : Clients[];
  public practices: Practices[];
  public solutionExecutives : SolutionExecutives[];

  project: ProjectListModel = new ProjectListModel();

  constructor(private toastr: ToastrService, private router: Router,private globalDropdownService: GlobalDropdownService,private projectListService: ProjectListService) { }

  CompanyProjectIdFormControl = new FormControl('', [Validators.required]);
  ProjectnameFormControl = new FormControl('', [Validators.required]);
  RegionFormControl = new FormControl('', [Validators.required]);
  BdmFormControl = new FormControl('', [Validators.required]);
  ProjectIdFormControl = new FormControl('', [Validators.required]);
  ClientFormControl = new FormControl('', [Validators.required]);
  SeFormControl = new FormControl('', [Validators.required]);
  StartDateFormControl = new FormControl('', [Validators.required]);
  PracticeFormControl = new FormControl('', [Validators.required]);
  ProjectAnalystFormController = new FormControl();
  ContactFormControl = new FormControl();
  EmailFormControl = new FormControl();


  ngOnInit() {
    this.project.type = '0';
    this.project.projectPracticeMappings = [] ;
    this.globalDropdownService.getRegions().subscribe((dataRegion: any) => {
      this.regions = dataRegion;
    });
    this.globalDropdownService.getBdmNames().subscribe((databdmNames: any) => {
      this.namesOfBDMs = databdmNames;
    });

    this.globalDropdownService.getPractices().subscribe((dataPractices: any) => {
      this.practices = dataPractices;
    });

    this.globalDropdownService.getClients().subscribe((dataClients:any) => {
      this.clients = dataClients.map((client)=>{
        client.clientId = client['id'];
        delete client['id'];
        return client
      })
    });
    this.globalDropdownService.getSolutionExecutive().subscribe((dataSolutionExecutives: any) => {
      this.solutionExecutives = dataSolutionExecutives;
    });
  }

  home() {
    this.router.navigate(['home']);
  }

  saveProject() {
     this.projectListService.saveProject(this.project).subscribe (data =>   {
      // console.log(data);
      // alert("Project created successfully.");
      this.toastr.success('practice saved', 'SUCCESS',{
        positionClass: 'toast-top-center',
    });
  });
}
  change(e) {
    e.source._selected? this.project.projectPracticeMappings.push({companyProjectId: this.project.companyProjectId,practiceId: e.source.value }) :   this.project.projectPracticeMappings = this.project.projectPracticeMappings.filter(item =>item.practiceId !== e.source.value)
  }
  isSaveValid() {
    if ((this.project.companyProjectId === undefined || this.project.companyProjectId === "" ) || 
    (this.project.projectName === undefined || this.project.projectName === "") || 
    this.project.regionName === undefined || this.project.bdmName === undefined || 
    (this.project.projectId === undefined ||  this.project.projectId === "") || 
    (this.project.clientId === undefined || this.project.clientId === "") || 
    this.project.seName === undefined || (this.project.startDate === undefined || this.project.startDate === null) || 
    this.project.projectPracticeMappings.length === 0)
        return true;
    else {
        return false;
    }
}

isPatternValid(){
  if(this.EmailFormControl.hasError('pattern') || this.ContactFormControl.hasError('pattern') || this.ContactFormControl.hasError('pattern') || 
  this.ProjectAnalystFormController.hasError('pattern') || 
  this.CompanyProjectIdFormControl.hasError('pattern') || this.ProjectIdFormControl.hasError('pattern')){
    return true;
  }
  else{
    return false;
  }
}
}
