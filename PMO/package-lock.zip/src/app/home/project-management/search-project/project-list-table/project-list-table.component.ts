import { Component, OnInit, Input, SimpleChanges, OnChanges, DoCheck } from '@angular/core';
import { MatSort, MatTableDataSource, MatPaginator } from '@angular/material';
import { ViewChild } from '@angular/core';
import { ProjectListModel } from '../../../../model/project-management/project-list.model';
import { ProjectListService } from '../../../../services/project-management/project-list.service';
import { MatDialog } from '@angular/material';
import { EditProjectComponent } from '../edit-project/edit-project.component';

@Component({
  selector: 'app-project-list-table',
  templateUrl: './project-list-table.component.html',
  styleUrls: ['./project-list-table.component.css']
})
export class ProjectListTableComponent implements OnInit, OnChanges, DoCheck {

  //Loader
  private loader: boolean;
  private noData: boolean;
  public currentPage: number;
  public Pagesize: number;
  public totalCount: any;
  projectDetails: ProjectListModel[];
  displayEditWindow = false;
  public data: any[];
  displayedColumns: string[] = ['companyProjectId', 'projectId', 'projectName', 'clientName', 'edit'];
  public dataSource: any

  @ViewChild(MatSort, ) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @Input() project;

  constructor(private projectListService: ProjectListService, public dialog: MatDialog) {
   }
  ngOnInit() {
    alert("hi");
    
  }
  ngOnChanges() {
    alert("yes");
   
  }
  ngDoCheck() {
    if (Object.keys(this.project).length !== 0) {
      this.projectListService.searchProject(this.project).subscribe((data: any[]) => {
        this.projectListService.searchResult = new MatTableDataSource(data);
        if (this.projectListService.searchResult.data.length === 0) {
          this.noData = true;
        } else {
          this.noData = false;
        }
        this.projectListService.searchResult.sort = this.sort;
        this.projectListService.searchResult.paginator = this.paginator;
        this.loader = true;
      });
    } else {
      this.loader = false;
      this.projectListService.getProjectList(this.currentPage, this.Pagesize).subscribe((data: any) => {
        this.projectListService.searchResult = new MatTableDataSource(data);
        if (this.projectListService.searchResult.data.length === 0) {
          this.noData = true;
        } else {
          this.noData = false;
        }
        this.projectListService.searchResult.sort = this.sort;
        this.projectListService.searchResult.paginator = this.paginator;
        this.loader = true;
      });
  }
  }
  onPaginateChange(e) {
    this.currentPage = e.pageIndex;
    this.Pagesize = e.pageSize;
    this.projectListService.getProjectList(this.currentPage, this.Pagesize).subscribe((data: any) => {
      this.projectListService.searchResult = new MatTableDataSource(data);
      if (this.projectListService.searchResult.data.length === 0) {
        this.noData = true;
      } else {
        this.noData = false;
      }
      this.projectListService.searchResult.sort = this.sort;
      this.projectListService.searchResult.paginator = this.paginator;
      this.loader = true;
    });
  }
  projectCount() {
    this.projectListService.getProjectCount().subscribe(data => {
      this.totalCount = data;
    });
  }
  openDialog($event, object) {
    //console.log('object data ',object);
    this.displayEditWindow = true;


    let dialogRef = this.dialog.open(EditProjectComponent,
      {

        width: '6000px',
        height: '500px',
        data:
          {
            dataKey: object
          }
      }


    );

    dialogRef.afterClosed().subscribe(result => {
      //console.log(`Dialog result: ${result}`);
    });
  }


}

