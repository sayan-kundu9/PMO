import { BdmNames, Clients, Practices, Regions, SolutionExecutives } from '../../../../model/global-dropdown.model';
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { GlobalDropdownService } from '../../../../services/global-dropdown.service';
import { FormControl, Validators } from '@angular/forms';
import { ProjectListModel } from '../../../../model/project-management/project';
import { ProjectListService } from '../../../../services/project-management/project-list.service';
//import { debug } from 'util';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'edit-project',
  templateUrl: './edit-project.component.html',
  styleUrls: ['./edit-project.component.css']
})
export class EditProjectComponent {

  public regions: Regions[];
  public namesOfBDMs: BdmNames[];
  public clients: Clients[];
  public practices: Practices[];
  public solutionExecutives: SolutionExecutives[];
  public cpId: string;
  public cn: number;
  ppm: Array<{ practiceId: String }> = [];

  public count: number;

  project: ProjectListModel = new ProjectListModel();

  constructor(private toastr: ToastrService, private projectListService: ProjectListService, private globalDropdownService: GlobalDropdownService, private dialogRef: MatDialogRef<EditProjectComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    dialogRef.disableClose = true;
  }

  CompanyProjectIdFormControl = new FormControl('', [Validators.required]);
  ProjectnameFormControl = new FormControl('', [Validators.required]);
  RegionFormControl = new FormControl('', [Validators.required]);
  BdmFormControl = new FormControl('', [Validators.required]);
  ProjectIdFormControl = new FormControl('', [Validators.required]);
  ClientFormControl = new FormControl('', [Validators.required]);
  SeFormControl = new FormControl('', [Validators.required]);
  StartDateFormControl = new FormControl('', [Validators.required]);
  EndDateFormControl = new FormControl('', [Validators.required]);
  PracticeFormControl = new FormControl('', [Validators.required]);
  email = new FormControl('', [Validators.required, Validators.email]);
  projectAnalystController = new FormControl('', [Validators.required]);
  contactFromController = new FormControl('', [Validators.required, Validators.minLength(10)]);
  //contactMinLength = new FormControl('', Validators.minLength(10))

  getErrorMessage() {
    return this.email.hasError('required') ? 'You must enter email' :
        this.email.hasError('email') ? 'Not a valid email' :
            '';
  }

  dateVal(){
    if(this.project.startDate > this.project.endDate){
      return true;
    }
    else{
      return false;
    }
  }
  change(e) {
    this.count++;
    console.log('*** this.count', this.count)
    //console.log(e.source._selected);
  }
  ngOnInit() {

    this.globalDropdownService.getRegions().subscribe((dataRegion: any) => {
      this.regions = dataRegion;
    });
    this.globalDropdownService.getBdmNames().subscribe((databdmNames: any) => {
      this.namesOfBDMs = databdmNames;
    });

    this.globalDropdownService.getPractices().subscribe((dataPractices: any) => {
      this.practices = dataPractices;
    });
    this.globalDropdownService.getClients().subscribe((dataClients: any) => {
      this.clients = dataClients;
      //console.log("clients -->>",this.clients);
    });
    this.globalDropdownService.getSolutionExecutive().subscribe((dataSolutionExecutives: any) => {
      this.solutionExecutives = dataSolutionExecutives;
    });

    this.project.companyProjectId = this.data.dataKey.companyProjectId;
    this.project.projectName = this.data.dataKey.projectName;
    this.project.regionName = this.data.dataKey.regionName;
    this.project.bdmName = this.data.dataKey.bdmName;

    this.project.startDate = new Date(this.data.dataKey.startDate);
    this.project.endDate = new Date(this.data.dataKey.endDate);

    this.project.email = this.data.dataKey.email;
    this.project.projectId = this.data.dataKey.projectId;
    this.project.type = this.data.dataKey.type;

    //debugger

    //console.log('this.data - ', this.data);
    this.project.clientId = this.data.dataKey.clientId;
    //console.log('this.project.clientId - ', this.project.clientId);
    //console.log('this.data.dataKey.clientId - ', this.data.dataKey.clientId);
    //console.log('this.data.dataKey.client.id - ', this.data.dataKey.client.id);
    this.cn = this.data.dataKey.client.id;
    //debugger

    //this.clientName = this.data.dataKey.clients.clientName;
    // for(let result of this.clients){
    //   if(this.project.clientId == result.clientId){
    //     this.clientName = result.clientName;
    //   }
    //  }
    this.project.seName = this.data.dataKey.seName;
    this.project.projectAnalyst = this.data.dataKey.projectAnalyst;
    this.project.contact = this.data.dataKey.contact;

    this.project.projectPracticeMappings = [];
    console.log('this.data.dataKey.projectPracticeMappings >> ', this.data.dataKey.projectPracticeMappings);
    

    for (let result of this.data.dataKey.projectPracticeMappings) {
      this.cpId = result.companyProjectId;
      this.ppm.push({ practiceId: result.practiceId });
    }

    console.log('this.ppm >> ', this.ppm);
    this.count = 0;
    console.log('reinitialized to 0 this.count >> ', this.count)
  }

  // change(e) {
  //   this.project.projectPracticeMappings.push({ companyProjectId: this.project.companyProjectId, practiceId: e.source.value });
  // }

  equals(objOne, objTwo) {
    if (typeof objOne !== 'undefined' && typeof objTwo !== 'undefined') {
      return objOne === objTwo.practiceId;
    }
  }

  // noPractice(){
  //   if(this.ppm.length === 0){
  //     return true;
  //   }
  // }

  updatePractices() {
    console.log('inside update () ppm  >> ', this.ppm);
    this.ppm.forEach(element => {
    
      console.log('element >> ', element);
      console.log('element.practiceId >> ', element.practiceId);
      if(this.count > this.ppm.length ){
        console.log('touched !!!!');
        this.project.projectPracticeMappings.push({ companyProjectId: this.cpId, practiceId: element.toString()  });
      }
      else{
        console.log('untouched ');
        this.project.projectPracticeMappings.push({ companyProjectId: this.cpId, practiceId: element.practiceId  });
      }

      
    
    });
    console.log('this.project.projectPracticeMappings >> ', this.project.projectPracticeMappings);
    

    console.log('this.project >> ', this.project);
    this.project.clientId = this.cn.toString();
    this.updateProject();
  }

  updateProject() {
    this.projectListService.updateProject(this.project).subscribe(data => {
      // console.log('inside updateProject() this.project >> ', this.project);
      // alert("Project updated successfully.");
    });
    this.dialogRef.close();
    //console.log('this.project - ', this.project);
    //console.log('this.project.clientId - ',this.project.clientId);
    //console.log('cn >> ', this.cn);
    this.toastr.success('project updated', 'SUCCESS',{
      positionClass: 'toast-top-center',
  });

  }


}
