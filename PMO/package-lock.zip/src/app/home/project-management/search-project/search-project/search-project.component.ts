import { Component, OnInit } from '@angular/core';
import { GlobalDropdownService } from '../../../../services/global-dropdown.service';
import {MatSort, MatTableDataSource, MatPaginator} from '@angular/material';
import { BdmNames, Clients, Practices, Regions, SolutionExecutives } from '../../../../model/global-dropdown.model';
import {Router} from "@angular/router";
import { ProjectListModel } from '../../../../model/project-management/project';
import { ProjectListService } from '../../../../services/project-management/project-list.service';
import {ViewChild} from '@angular/core';

@Component({
  selector: 'app-search-project',
  templateUrl: './search-project.component.html',
  styleUrls: ['./search-project.component.css']
})
export class SearchProjectComponent implements OnInit {

   public regions : Regions[];
   public namesOfBDMs : BdmNames[];
   public clients : Clients[];
   public solutionExecutives : SolutionExecutives[];
   public practices : Practices[];

  project :ProjectListModel = new ProjectListModel();
  searchdata={};
      constructor(private globalDropdownService : GlobalDropdownService, 
                  private router: Router, 
                  private projectListService : ProjectListService) { }
    

      home() {
        this.router.navigate(['home']);
      }

      ngOnInit() {
             // regions
             this.globalDropdownService.getRegion().subscribe((dataRegion:any)=>{
                  this.regions = dataRegion.regions;
                });
                

                //bdmNames

                this.globalDropdownService.getBdmName().subscribe((databdmNames:any)=>{
                                this.namesOfBDMs = databdmNames.namesOfBDMs;
                                 });

              //Clients
               this.globalDropdownService.getClient().subscribe((dataClients:any)=>{
                                            this.clients = dataClients.clients;
                                             });

              // solution Executives
                this.globalDropdownService.getSolutionExecutives().subscribe((dataSolutionExecutives:any)=>{
                                                          this.solutionExecutives = dataSolutionExecutives.solutionExecutives;
                                              });
              //Practices
              this.globalDropdownService.getPractices().subscribe((dataPractices:any)=>{
                                                                      this.practices = dataPractices.practices;
                                                                       });
      }
      @ViewChild(MatSort , ) sort: MatSort;
      @ViewChild(MatPaginator) paginator: MatPaginator;
      searchProject() {
        this.searchdata=Object.assign({}, this.project);
      }

      

}


 