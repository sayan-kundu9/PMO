import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { MatSort, MatTableDataSource, MatPaginator } from '@angular/material';
import { ViewChild } from '@angular/core';
import { GlobalDropdownService } from '../../../../services/global-dropdown.service';
import { Clients } from '../../../../model/global-dropdown.model';
import { ProjectListModel } from '../../../../model/project-management/project';
import { ProjectListService } from '../../../../services/project-management/project-list.service';
import { AddClientComponent } from '../add-client/add-client.component';

@Component({
  selector: 'app-client-list-table',
  templateUrl: './client-list-table.component.html',
  styleUrls: ['./client-list-table.component.css']
})
export class ClientListTableComponent implements OnInit {

  displayedColumns: string[] = ['clientName','edit'];
  public clients : Clients[];
  public dataSource:any

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private changeDetectorRefs: ChangeDetectorRef,private globalDropdownService: GlobalDropdownService,private projectListService: ProjectListService) { }

  ngOnInit() {
    this.getAllClients();
  }
  setClientName(name) {
    localStorage.setItem('clientName',name);
    console.log(name);
  }
  getAllClients() {
    this.globalDropdownService.getClients().subscribe((dataClients:any) => {
      this.dataSource = new MatTableDataSource(dataClients);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
      this.changeDetectorRefs.detectChanges();
    });
  }
}
