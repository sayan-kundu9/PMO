import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Router } from "@angular/router";
import { FormControl, Validators } from '@angular/forms';
import { client } from '../../../../model/project-management/client';
import { ProjectListService } from '../../../../services/project-management/project-list.service';
import { GlobalDropdownService } from '../../../../services/global-dropdown.service';
import { MatSort, MatTableDataSource, MatPaginator } from '@angular/material';
import { ClientListTableComponent } from '../client-list-table/client-list-table.component';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-client',
  templateUrl: './add-client.component.html',
  styleUrls: ['./add-client.component.css']
})
export class AddClientComponent implements OnInit {
  clients: client = new client();
  public dataSource: any
  constructor(private toastr: ToastrService, private router: Router, private projectListService: ProjectListService, private globalDropdownService: GlobalDropdownService) { }

  ClientNameIdFormControl = new FormControl('', [Validators.required]);
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(ClientListTableComponent) clientListTableComponent: ClientListTableComponent;
  ngOnInit() {
  }

  home() {
    this.router.navigate(['home']);
  }

  AddClient() {
    this.projectListService.saveClient(this.clients).subscribe(data => {
      //alert("Client added successfully.");
      this.toastr.success('practice added', 'SUCCESS', {
        positionClass: 'toast-top-center',
      });
      this.clientListTableComponent.getAllClients();
    });
  }

  isSaveValid() {
    if (this.clients.clientName === '' || this.clients.clientName === undefined) {
      return true;
    } else {
      return false;
    }
  }
}
