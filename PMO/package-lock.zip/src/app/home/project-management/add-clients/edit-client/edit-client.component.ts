import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { FormControl, Validators } from '@angular/forms';
import { Clients } from '../../../../model/global-dropdown.model';
import { GlobalDropdownService } from '../../../../services/global-dropdown.service';
import { ProjectListService } from '../../../../services/project-management/project-list.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-edit-client',
  templateUrl: './edit-client.component.html',
  styleUrls: ['./edit-client.component.css']
})
export class EditClientComponent implements OnInit {
  public clients: Clients[];
  public paramId: Number;
  public clientName: String;
  constructor(private toastr: ToastrService, private router: Router, private route: ActivatedRoute, private globalDropdownService: GlobalDropdownService, private projectListService: ProjectListService) {
  }
  ClientNameIdFormControl = new FormControl('', [Validators.required]);
  ngOnInit() {
    this.clientName = localStorage.getItem('clientName');
    this.route.params.subscribe(params => { this.paramId = params.id });
    this.projectListService.getClientById(this.paramId);
  }
  home() {
    this.router.navigate(['home']);
  }
  client() {
    this.router.navigate(['home/projectManagement/addClient']);
  }
  update() {
    this.projectListService.updateClient(this.paramId, {
      clientName: this.clientName
    }).subscribe(data => {
      //alert("Client updated successfully.");
    });
    this.toastr.success('client name updated', 'SUCCESS', {
      positionClass: 'toast-top-center',
    });
  }
  isSaveValid() {
    if (this.clientName === '' || this.clientName === undefined) {
      return true;
    } else {
      return false;
    }
  }
}
