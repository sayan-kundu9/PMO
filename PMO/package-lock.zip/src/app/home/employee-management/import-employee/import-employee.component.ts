import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import  {Router } from "@angular/router";
import { EmployeeManagementService } from '../../../services/employee-management/employee-management.service';
import { GlobalDropdownService } from '../../../services/global-dropdown.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-import-employee',
  templateUrl: './import-employee.component.html',
  styleUrls: ['./import-employee.component.css']
})
export class ImportEmployeeComponent implements OnInit {
  fileToUpload: File  = null;
  filename:string='Choose file';
  showerror = false;
  progresbar= false;
  msg: string = null;
  errorMsg:string =null;
  constructor(private toastr: ToastrService, private employeeManagementService : EmployeeManagementService) { }

  ngOnInit() {
  }
  onFileInput(files: FileList) {
    this.filename='Choose file';
    this.fileToUpload=null;
    let fileItem = files.item(0);
    this.filename=fileItem.name;
    this.fileToUpload = fileItem;
    this.showerror=false;
  }

  uploadEmployee()
{
debugger;
console.log(this.fileToUpload);
    if(this.fileToUpload){
     this.showerror=false;
     this.progresbar=true;
     this.errorMsg='';
      this.employeeManagementService.importEmployees(this.fileToUpload).subscribe((data:any)=>{
                if(data['fileName']){
                      this.filename='Choose file';
                      this.fileToUpload=null;
                      this.progresbar=false;
                }
               if (data.createdBy==null){
                 //this.errorMsg="FAILED TO UPLOAD "
                 
                 this.toastr.error('file upload failed', 'Error', {
                  positionClass: 'toast-top-center',
                  // timeOut: 3000
                 });
                 
               }else{
                //this.msg=" File Uploaded Successfully "
                this.toastr.success('file uploaded', 'SUCCESS',{
                  positionClass: 'toast-top-center',
                });
               }
              console.log('Upload Employee data ',data)

      });

    }else{
      this.showerror=true;
      //this.errorMsg="Please Select a file to Upload";
      this.toastr.info('choose file', 'Error', {
        positionClass: 'toast-top-center',
        // timeOut: 3000
      });
    
    }
  }
}
