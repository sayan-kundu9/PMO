import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import  {Router } from "@angular/router";
import { EmployeeManagementService } from '../../../services/employee-management/employee-management.service';
import { GlobalDropdownService } from '../../../services/global-dropdown.service';
import { Employee } from '../../../model/employee-management/employee';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  public titles:any
  public reportings:any
  public businessLines:any
  public centerOfExcels:any

     employee: Employee = new Employee();

  constructor(private toastr: ToastrService, private globalDropdownService : GlobalDropdownService, private router: Router,private emoloyeeService : EmployeeManagementService) { }

  //validations
  PsIdFormControl = new FormControl('', [Validators.required]);
  IdFormControl = new FormControl('', [Validators.required]);
  FnameFormControl = new FormControl('', [Validators.required]);
  LnameFormControl = new FormControl('', [Validators.required]);
  TitleFormControl = new FormControl('', [Validators.required]);
  BusinessFormControl = new FormControl('', [Validators.required]);
  CoeFormControl = new FormControl('', [Validators.required]);
  ReportingFormControl = new FormControl('', [Validators.required]);
  HireFormControl = new FormControl('', [Validators.required]);
  LocationFormControl = new FormControl('', [Validators.required]);
  SalaryFormControl = new FormControl('', [Validators.required]);
  TekemailFormControl = new FormControl('', [Validators.required,Validators.email]);
  AlteremailFormControl = new FormControl('', [Validators.required,Validators.email]);
  dlFormControl = new FormControl('', [Validators.required]);
  DateFormControl = new FormControl('', [Validators.required]);
  ContactFormControl = new FormControl();
  OfficeContactFormControl = new FormControl('', [Validators.required]);

  home() {
    this.router.navigate(['home']);
  }

  dateVal(){
    if(this.employee.hireDate > this.employee.termination){
      return true;
    }
    else{
      return false;
    }
  }

  EffectiveDateVal(){
    if(this.employee.hireDate > this.employee.dateCreated || this.employee.dateCreated > this.employee.tekEmail){
      return true;
    }
    else{
      return false;
    }
  }

  ngOnInit() {
    this.globalDropdownService.getTitle().subscribe((dataTitle:any)=>{
      this.titles = dataTitle.titles;
    });
    this.globalDropdownService.getReportings().subscribe((dataReports:any)=>{
      this.reportings = dataReports.reportings;
    });
    this.globalDropdownService.getCenterOfExcel().subscribe((dataCenterOfExcels:any)=>{
      this.centerOfExcels = dataCenterOfExcels.centerOfExcels;
    })
    this.globalDropdownService.getBusinessLines().subscribe((dataBusinessLines:any)=>{
      this.businessLines = dataBusinessLines.businessLines;
    });
  }


  saveEmployee() {
    this.emoloyeeService.saveEmp(this.employee).subscribe (data =>   { 

  });
  this.toastr.success('user created', 'SUCCESS',{
    positionClass: 'toast-top-center',
});
  }
  isSaveValid() {
    if ((this.employee.companyEmpId === undefined || this.employee.companyEmpId === "" ) || 
    (this.employee.firstName === undefined || this.employee.firstName === "") || 
    (this.employee.title === undefined || this.employee.title === "") || 
    ( this.employee.coe === undefined || this.employee.coe === "") || 
    (this.employee.hireDate === undefined || this.employee.hireDate === "" || this.employee.hireDate === null) || 
    ( this.employee.location === "" || this.employee.location === undefined) || 
    (this.employee.salary === undefined || this.employee.salary === "") || 
    ( this.employee.alternateEmail === "" || this.employee.alternateEmail === undefined) || 
    (this.employee.empId === undefined || this.employee.empId === "") || 
    (this.employee.lastName === undefined || this.employee.lastName === "") || 
    (this.employee.businessLine === undefined || this.employee.businessLine === "") ||  
    (this.employee.reportingTo === undefined || this.employee.reportingTo === "") || 
    (this.employee.tekEmail === undefined || this.employee.tekEmail === "") ||  
    (this.employee.modifiedBy === undefined || this.employee.modifiedBy === "") ||
    (this.employee.officePhone === undefined || this.employee.officePhone === "") || 
    (this.employee.dateCreated === undefined || this.employee.dateCreated === "" || this.employee.dateCreated === null))
        return true;
    else {
        return false;
    }
}

isFormValid(){
  if (this.PsIdFormControl.hasError('pattern') || this.FnameFormControl.hasError('pattern') || this.SalaryFormControl.hasError('pattern') ||
  this.ContactFormControl.hasError('pattern') || this.LnameFormControl.hasError('pattern') || this.OfficeContactFormControl.hasError('pattern') ||
  this.dlFormControl.hasError('pattern')) {
    return true;
    
  }
  else{
    return false;
  }
}



}
