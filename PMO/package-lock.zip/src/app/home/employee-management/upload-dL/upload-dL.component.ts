import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import  {Router } from "@angular/router";
import { EmployeeManagementService } from '../../../services/employee-management/employee-management.service';
import { GlobalDropdownService } from '../../../services/global-dropdown.service';
import { Employee } from '../../../model/employee-management/employee';


@Component({
  selector: 'upload-dL-employee',
  templateUrl: './upload-dL.component.html',
  styleUrls: ['./upload-dL.component.css']
})
export class UploadDlComponent implements OnInit {

 fileToUpload: File  = null;
  filename:string='Choose file';
showerror = false;
  progresbar= false;
 msg: string = null;
errorMsg:string =null;
constructor(
        private employeeManagementService : EmployeeManagementService
        ) {
                   }
  ngOnInit() {
  }

 onFileInput(files: FileList) {
    this.filename='Choose file';
    this.fileToUpload=null;
    let fileItem = files.item(0);
    this.filename=fileItem.name;
    this.fileToUpload = fileItem;
    this.showerror=false;
  }

uploadDl()
{

console.log(this.fileToUpload);
    if(this.fileToUpload){
     this.showerror=false;
     this.progresbar=true;
      this.employeeManagementService.importEmployee(this.fileToUpload).subscribe((data:any)=>{
                if(data['fileName']){
                      this.filename='Choose file';
                      this.fileToUpload=null;
                      this.progresbar=false;
                }
               if (data.createdBy==null){
                 this.errorMsg="FAILED TO UPLOAD "
               }else{
                this.msg="SUCCESS"
               }
              console.log('Upload DL data ',data)

      });

    }else{
      this.showerror=true;

    }
  }

}
