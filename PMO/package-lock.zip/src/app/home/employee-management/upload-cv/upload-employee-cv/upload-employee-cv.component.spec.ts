import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadEmployeeCvComponent } from './upload-employee-cv.component';

describe('UploadEmployeeCvComponent', () => {
  let component: UploadEmployeeCvComponent;
  let fixture: ComponentFixture<UploadEmployeeCvComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadEmployeeCvComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadEmployeeCvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
