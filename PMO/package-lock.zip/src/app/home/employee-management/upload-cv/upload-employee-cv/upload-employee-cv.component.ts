import { Component, OnInit, ViewChild, ElementRef, ChangeDetectorRef, Inject } from '@angular/core';
import { UploadEvent, UploadFile, FileSystemFileEntry, FileSystemDirectoryEntry } from 'ngx-file-drop';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { EmployeeListModel } from '../../../../model/employee-management/employee-list.model';
import { EmployeeManagementService } from '../../../../services/employee-management/employee-management.service';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { GlobalDropdownService } from '../../../../services/global-dropdown.service';
import { employeeNames } from '../../../../model/global-dropdown.model';
import { Http } from '@angular/http';
import { FormControl, Validators } from '@angular/forms';
import { EventEmitter } from 'protractor';
import * as saveAs from 'file-saver';

@Component({
  selector: 'app-upload-employee-cv',
  templateUrl: './upload-employee-cv.component.html',
  styleUrls: ['./upload-employee-cv.component.css']
})
export class UploadEmployeeCvComponent implements OnInit {
  public files: UploadFile[] = [];
  public fileName = [];
  public employees: employeeNames[];
  public employeeCvs;
  private dataSource: any;
  public emptyData: any;
  public emp: any;
  fileToUpload: File = null;
  filename: string = 'Choose file';
  displayedColumns: string[] = ['PsEmployeeId', 'Name', 'Type', 'download', 'delete'];

  constructor(private changeDetectorRefs: ChangeDetectorRef, private globalDropdownService: GlobalDropdownService, private employeeManagementService: EmployeeManagementService) { }

  emplNameFormControl = new FormControl('', [Validators.required]);
  @ViewChild('selectFile') file: ElementRef
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngOnInit() {
    this.globalDropdownService.getEmployees().subscribe((dataTitle: any) => {
      [this.employees, this.emptyData] = [dataTitle, dataTitle.length];
    });
    this.getAllEmployeeCvs();
  }
  change(e) {
    this.getEmployeeCvById(e);
  }
  getEmployeeCvById(e) {
    this.employeeManagementService.getEmployeeCvById(e).subscribe((dataTitle: any) => {
      this.dataSource = new MatTableDataSource(dataTitle);
       //this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
        this.emptyData = this.dataSource.data.length;
      this.changeDetectorRefs.detectChanges();
    });
  }
  onFileInput(files: FileList) {
    let [fileItem, filelength] = [files.item(0), files.length];
    if (filelength === 0) {
      this.filename = null;
    }
    else {
      this.filename = fileItem.name;
      this.fileToUpload = fileItem;
    }
  }
  getAllEmployeeCvs() {
    this.globalDropdownService.getEmployeeCvs().subscribe((dataTitle: any) => {
      this.dataSource = new MatTableDataSource(dataTitle);
     // this.dataSource.sort = this.sort;
       this.dataSource.paginator = this.paginator;
      this.changeDetectorRefs.detectChanges();
    });
  }
  public submitCv(e: any) {
    if (this.fileToUpload.size >= 10240000) {
      alert("File size is more");
    }
    else {
      this.employeeManagementService.submitCv(this.emp, this.fileToUpload).subscribe(() => {
        alert("File uploaded successfully")
        this.getEmployeeCvById(this.emp);
      });
    }
  }
  public deletecv(id: any) {
    this.employeeManagementService.deleteEmpcv(id).subscribe(() => {
      alert("Cv deleted");
      this.getEmployeeCvById(id);
    });
  }
  public downloadCv(id: any, type) {
    this.employeeManagementService.downloadEmpcv(id).subscribe(response => {
      let parsedResponse = (response)
      var blob = new Blob([response], { type: 'blob' });
      var filename = type;
      saveAs(blob, filename);
    });
  }
  isSaveValid() {
    if ((this.emp === '' || this.emp === undefined) || this.file.nativeElement.files.length === 0) {
      return true;
    }
    else {
      return false;
    }
  }
}