import { Component, OnInit ,Input ,OnChanges,SimpleChanges} from '@angular/core';
import {MatSort, MatTableDataSource, MatPaginator, MatDialogRef} from '@angular/material';
import {ViewChild} from '@angular/core';
import { EmployeeListModel } from '../../../../model/employee-management/employee-list.model';
import { EmployeeManagementService } from '../../../../services/employee-management/employee-management.service';
import {MatDialog} from '@angular/material';
import {EditEmployeeProjectComponent} from '../edit-employee-project/edit-employee-project.component';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-employee-project-list-table',
  templateUrl: './employee-project-list-table.component.html',
  styleUrls: ['./employee-project-list-table.component.css'],
  providers: [ EditEmployeeProjectComponent],
})
export class EmployeeProjectListTableComponent implements OnInit, OnChanges {

   displayEditWindow = false;
   private loader: boolean;
   private noData: boolean;
   private companyEmpId:any;
  employeeDetails:EmployeeListModel[];
  initialized=false;

  @Input('employeeList') myEmployeeList : any[];

    displayedColumns: string[] = ['companyEmpId', 'empId','firstName', 'roleName', 'technologyName','edit'];
      public dataSource:any
      @ViewChild(MatSort ) sort: MatSort;
      @ViewChild(MatPaginator) paginator: MatPaginator;



      constructor(private employeeManagementService:EmployeeManagementService,
                  public dialog: MatDialog,
                  private spinnerService: Ng4LoadingSpinnerService){
      }

      ngOnInit() {
        this.loader = false;
       // this.spinnerService.show();
          this.employeeManagementService.getEmployeeList().subscribe((data:any)=>{
            //console.log('data', data)
              this.dataSource = new MatTableDataSource(data); 
              this.dataSource.sort = this.sort;
              this.dataSource.paginator = this.paginator;
              this.loader = true;
             // this.spinnerService.hide();
          });
          this.initialized = true;
      }
       renameKeys(obj, newKeys) {
        const keyValues = Object.keys(obj).map(key => {
          const newKey = newKeys[key] || key;
          return { [newKey]: obj[key] };
        });
        return Object.assign({}, ...keyValues);
      }
 ngOnChanges(changes: SimpleChanges) {
  if(this.initialized){
       this.loader = true;
       this.dataSource = new MatTableDataSource(this.myEmployeeList);
      const keys =  { empId: 'employeeID' , 
                      companyEmpId: 'empCompanyID' };
      this.dataSource.data[0].roleName = this.dataSource.data[0].role.roleName;
      this.dataSource.data[0].technologyName = this.dataSource.data[0].technology.technologyName;
      let obj1  = this.renameKeys(this.dataSource.data[0] ,keys );
      this.dataSource.data[0] = {...obj1};  
       if (this.dataSource.data.length===0) {
        this.noData = true;
      } else {
        this.noData = false;
      }
              this.dataSource.sort = this.sort;
              this.dataSource.paginator = this.paginator;
    }
    }
openDialog($event,object){
  this.displayEditWindow= true;
  let dialogRef = this.dialog.open(EditEmployeeProjectComponent,
    {
      width: '6000px',
      height: '600px',
      data: {
        dataKey: object
      }
    }
  );
  dialogRef.afterClosed().subscribe(result => {
    console.log(`Dialog result: ${result}`);
  });
}
}

