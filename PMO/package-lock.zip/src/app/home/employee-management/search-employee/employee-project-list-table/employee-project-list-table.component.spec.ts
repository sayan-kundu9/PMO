import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeProjectListTableComponent } from './employee-project-list-table.component';

describe('EmployeeProjectListTableComponent', () => {
  let component: EmployeeProjectListTableComponent;
  let fixture: ComponentFixture<EmployeeProjectListTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeProjectListTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeProjectListTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
