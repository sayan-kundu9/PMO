import { Component, OnInit } from '@angular/core';
import { GlobalDropdownService } from '../../../../services/global-dropdown.service';
import { EmployeeSearchModel } from '../../../../model/employee-management/employee-search.model';
import { EmployeeManagementService } from '../../../../services/employee-management/employee-management.service';
import { EmployeeListModel } from '../../../../model/employee-management/employee-list.model';
@Component({
  selector: 'app-employee-search-project',
  templateUrl: './employee-search-project.component.html',
  styleUrls: ['./employee-search-project.component.css']
})
export class EmployeeSearchProjectComponent implements OnInit {

      employeeTitles;
      employeeBusinessLines;
      employeeTitle1 : string;
      employeeBusinessLine1: string;
      employeeCenterOfExcellences:string;
      employeeReportingTos :string;
      employeeReportingTo :string;
      employeeCenterOfExcellence:string;
      employeeList: EmployeeListModel[];
      employeeProjectNames:string;
      employeeProjectName:string;


      constructor(
        private employeeManagementService : EmployeeManagementService,
        private globalDropdownService : GlobalDropdownService) {
                   }

      ngOnInit() {
                this.globalDropdownService.getEmployeeTitle().subscribe((dataEmployeeTitles:any)=>{
                  this.employeeTitles = dataEmployeeTitles.employeeTitles;
                });
                   this.globalDropdownService.getEmployeeBusinessLines().subscribe((dataEmployeeBusinessLines:any)=>{
                  this.employeeBusinessLines = dataEmployeeBusinessLines.employeeBusinessLines;
                });
                this.globalDropdownService.getEmployeeCenterOfExcellence().subscribe((dataEmployeeCenterOfExcellences:any)=>{
                  this.employeeCenterOfExcellences = dataEmployeeCenterOfExcellences.employeeCenterOfExcellences;
                });
                this.globalDropdownService.getEmployeeReportingTo().subscribe((dataEmployeeReportingTo:any)=>{
                  this.employeeReportingTos = dataEmployeeReportingTo.employeeReportingTos;
                });
                this.globalDropdownService.getEmployeeProjectName().subscribe((dataEmployeeProjectNames:any)=>{
                  this.employeeProjectNames = dataEmployeeProjectNames.employeeProjectNames;
                });

      }


getSearch(formValue){
if (formValue.value.empId === '') {
  formValue.value.empId = undefined
}
if (formValue.value.companyEmpId === '') {
  formValue.value.companyEmpId = undefined
}
if (formValue.value.firstName === "") {
  formValue.value.firstName = undefined
}
 let employeeSearchModel : EmployeeSearchModel =
  {
    businessLine : formValue.value.employeeBusinessLine,
    companyEmpId:formValue.value.companyEmpId,
    empId:formValue.value.empId,
    firstName:formValue.value.firstName,
    lastName:formValue.value.lastName,
    coe:formValue.value.employeeCenterOfExcellence,
    reportingTo :formValue.value.employeeReportingTo,
    projectName :formValue.value.employeeProjectName,
    location:formValue.value.location,
    title:formValue.value.employeeTitle
  };
       this.employeeManagementService.search(employeeSearchModel).subscribe((data:any[])=>{
              this.employeeList = data;
            });
}
onSelect(recValue){
this.employeeTitle1 = recValue;
}
onReportingSelect(report){
this.employeeReportingTo = report;
}
onCenterOfExcellence(rec){
this.employeeCenterOfExcellence = rec;
}
onProjectNameSelect(recProject){
this.employeeProjectName = recProject;
}
onBusinessSelect(recClientValue){
this.employeeBusinessLine1 = recClientValue;
}

}

