
import { Component, Input, Inject, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { GlobalDropdownService } from '../../../../services/global-dropdown.service';
import { EmployeeManagementService } from '../../../../services/employee-management/employee-management.service';
import { FormControl, Validators } from '@angular/forms';
import { MatPaginator, MatTableDataSource, MatSort, MatDialog } from '@angular/material';
import { EditEmployee } from './../../../../model/employee-management/editEmployee';
import { EditEmployeeDL } from './../../../../model/employee-management/editEmployeeDl';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'edit-employee-project',
  templateUrl: './edit-employee-project.component.html',
  styleUrls: ['./edit-employee-project.component.css']
})
export class EditEmployeeProjectComponent {


  //History Table
  private dataSource: any;
  private dataSource2: any;
  private noData: boolean;
  private terminationDate: Date;
  private today: Date;
  private hideDLUpdation: boolean;
  public type: any;
  public typev: any;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  displayedColumns: string[] = ['salaryPerHour', 'effectiveDate'];

  //Validation
  pickerControl = new FormControl('', [Validators.required]);
  dlControl = new FormControl('', [Validators.required]);
  terminationControl = new FormControl('', [Validators.required]);


  @Input() editEmployee: EditEmployee;
  //msg: string = null;
  //msg1: string = null;

  employeeReportingTos: string;
  employeeReportingTo

  constructor(private toastr: ToastrService,
    private employeeManagementService: EmployeeManagementService,
    private dialogRef: MatDialogRef<EditEmployeeProjectComponent>,
    private globalDropdownService: GlobalDropdownService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    dialogRef.disableClose = true;

    this.type = this.data.dataKey.voluntaryType;
    if (data.dataKey.termination) {
      this.terminationDate = new Date(data.dataKey.termination);
      this.today = new Date();
      //console.log('this.terminationDate: ', this.terminationDate)
      //console.log('this.today : ', this.today);
      if (this.terminationDate < this.today) {
        this.hideDLUpdation = true;
      }
      else {
        this.hideDLUpdation = false;
      }
    }
    else {
      this.hideDLUpdation = false;
    }
  }
  historyDL: EditEmployeeDL = new EditEmployeeDL();
  ngOnInit() {
    this.globalDropdownService.getEmployeeReportingTo().subscribe((dataEmployeeReportingTo: any) => {
      this.employeeReportingTos = dataEmployeeReportingTo.employeeReportingTos;
      this.historyDL.companyEmpId = this.data.dataKey.empCompanyID;
      this.employeeManagementService.employeeDL(this.historyDL).subscribe((data: any) => {
        this.dataSource2 = new MatTableDataSource(data);
        if (this.dataSource2.data.length === 0) {
          this.noData = true;
        } else {
          this.noData = false;
        }
        this.dataSource2.paginator = this.paginator;
      })
    });
  }
  onReportingSelect(report) {
    this.employeeReportingTo = report;
  }
  isUpdateValid() {
    if ((this.employeeReportingTo === '' || this.employeeReportingTo === undefined) || this.terminationDate === undefined) {
      return true;
    } else {
      return false;
    }
  }
  updateEmployee(updateFormValue: any) {
    let editEmployee: EditEmployee = {
      companyEmpId: this.data.dataKey.empCompanyID,
      termination: updateFormValue.value.termination.getTime(),
      type: updateFormValue.value.type,
      reportingTo: updateFormValue.value.employeeReportingTo
    };
    this.employeeManagementService.updateEmp(editEmployee).subscribe(data => {
      //this.msg = 'Update done Successfully !!';
    });
    this.dialogRef.close();
    this.toastr.success('updated', 'SUCCESS', {
      positionClass: 'toast-top-center',
    });
  }

  editEmployeeDL: EditEmployeeDL = new EditEmployeeDL();

  updateDL() {
    this.editEmployeeDL.companyEmpId = this.data.dataKey.empCompanyID;
    this.employeeManagementService.updateEmployeeDL(this.editEmployeeDL).subscribe(data => {
      //this.msg1 = 'DL added Successfully !!';
      this.employeeManagementService.employeeDL(this.historyDL).subscribe((data: any) => {
        this.dataSource2 = new MatTableDataSource(data);
        this.dataSource2.paginator = this.paginator;
      })
    });
    this.dialogRef.close();
    this.toastr.success('DL added', 'SUCCESS', {
      positionClass: 'toast-top-center',
    });
  }
}
