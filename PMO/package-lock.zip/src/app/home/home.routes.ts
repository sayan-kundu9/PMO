import { Routes } from '@angular/router';
import { HomeComponent } from './home.component';
import { SearchProjectComponent } from './project-management/search-project/search-project/search-project.component';
import { TimesheetComponent } from './timesheet/timesheet/timesheet.component';
import { AddEmployeeComponent } from './employee-management/add-employee/add-employee.component';
import { PracticeExpensesComponent } from './practice-management/practice-expenses/practice-expenses/practice-expenses.component';
import { EmployeeSearchProjectComponent } from './employee-management/search-employee/employee-search/employee-search-project.component';
import { AddPracticeUpdatesComponent } from './practice-management/practice-updates/add-practice-updates/add-practice-updates.component';
import { AddProjectComponent } from './project-management/add-project/add-project.component';
import { AddClientComponent } from './project-management/add-clients/add-client/add-client.component';
import { EditClientComponent } from './project-management/add-clients/edit-client/edit-client.component';
import { UploadDlComponent } from './employee-management/upload-dL/upload-dL.component';
import { UploadEmployeeCvComponent } from './employee-management/upload-cv/upload-employee-cv/upload-employee-cv.component';
import { ImportEmployeeComponent } from './employee-management/import-employee/import-employee.component';
 export const HomeRoutes: Routes=[


    { path: '', redirectTo: '/home', pathMatch: 'full'},
    { path: 'home', component: HomeComponent },
    { path: 'projectManagement/searchProject' , component: SearchProjectComponent },
    { path: 'projectManagement/addProject' , component: AddProjectComponent },
    { path: 'projectManagement/addClient' , component: AddClientComponent},
    {path: 'projectManagement/addClient/editClient/:id', component: EditClientComponent},
    { path: 'employeeManagement/addEmployee' , component: AddEmployeeComponent },
    { path: 'practiceManagement/practiceExpense' , component: PracticeExpensesComponent },
    { path: 'practiceManagement/practiceUpdates' , component: AddPracticeUpdatesComponent },
    { path: 'timesheet' , component: TimesheetComponent },
    { path: 'employeeManagement/searchEmployee' , component: EmployeeSearchProjectComponent},
    { path: 'employeeManagement/upload-dL' , component: UploadDlComponent},
    { path: 'employeeManagement/upload-cv' , component: UploadEmployeeCvComponent},
    { path: 'employeeManagement/import-employee' , component: ImportEmployeeComponent}
];