export class PracticeExpensesListModel {
   
    practiceExpenseId: string;
    practiceId: string;
    expensesId: string;
    amount: string;
    currency_name: string;
    expenses_description: string;
    dateOfExpense: Date;
    planned: string;
}
