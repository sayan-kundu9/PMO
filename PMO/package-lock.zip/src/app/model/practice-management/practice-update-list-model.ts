export class PracticeUpdateListModel {
    
    //practiceID: number;
    id:number;
    portletPracticeID: string;
    practiceContent: string;
    //isActive: boolean;
    active: boolean;
    isDeleted: boolean;
    createdDate: string;
    createdBy: string;
    modifiedBy: string;
    //practiceHead: string;
    
}
