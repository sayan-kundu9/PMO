export class ProjectListModel {
    companyProjectId: String;
    projectId: String;
    projectName: String;
    clientName:String;
    regionName:number;
    seName:number;
    bdmName:number;
    startDate:Date;
    endDate:Date;
    projectAnalyst:string;
    email:string;
    contact:string;
    practice:string;
}
