export class client {
    clientName:String;
}
