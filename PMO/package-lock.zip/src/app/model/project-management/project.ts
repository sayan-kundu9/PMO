export class ProjectListModel {
    companyProjectId: String;
    projectId: String;
    projectName: String;
    clientId:String;
    regionName:number;
    seName:number;
    bdmName:number;
    startDate:Date;
    endDate:Date;
    projectAnalyst:String;
    email:String;
    contact:String;
    type:String;
    projectPracticeMappings: Array<{companyProjectId: String, practiceId: String}>;
}
