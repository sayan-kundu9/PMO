export interface BdmNames {
    bdmId: String;
    name: String;
}
export interface BdmName {
    value: String;
    name: String;
}

export interface employeeNames {
    value: String;
    name: String;
}

export interface Clients {
    clientId: String;
    clientName: String;
}
export interface Client {
    value: String;
    name: String;
}

export interface Practices {
    practiceId: String;
    practiceName: String;
}
export interface Practices1 {
    name: string;
    value: string;
}

export interface Regions {
    regionId: String;
    name: String;
}
export interface Region {
    value: String;
    name: String;
}
export interface SolutionExecutives {
    seId: String;
    name: String;
}

export interface SolutionExecutive {
    value: String;
    name: String;
}
export interface Currency {
    value: string;
    name: string;
  }

export interface Expenses {
    expensesId: string;
    expensesName: string;
}
export interface YesNo {
    value: string;
    name: string;
}
export interface EmployeeTitles {
value : String;
name : String;
}

export interface EmployeeBusinessLines {
value : String;
name : String;
}

export interface EmployeeCenterOfExcellences {
value : String;
name : String;
}

export interface Reporting {
value : String;
name : String;
}
