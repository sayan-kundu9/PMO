export class EditEmployee {
    companyEmpId: string;
    
    reportingTo:string;
   
    termination: string;
    
    type:string;

}
