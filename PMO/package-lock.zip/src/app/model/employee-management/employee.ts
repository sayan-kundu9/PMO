export class Employee {
    companyEmpId: string;
    empId: string;
    firstName: string;
    lastName: string;
     title:string;
    businessLine:string;
    reportingTo:string;
    hireDate: string;
    termination: string;
    location: string;
    salary: string;
    officePhone:string;
    mobilePhone:string;
    tekEmail:string;
    alternateEmail:string;
    coe:string;
    createdBy:string;
     dateCreated:string;
     modifiedBy:string;
    dateModified:string;
    type:string;
    projectName:string;

}
