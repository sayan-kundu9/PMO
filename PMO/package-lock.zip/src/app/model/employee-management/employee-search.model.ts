export class EmployeeSearchModel {
    companyEmpId: string;
    empId: string;
    firstName: string;
    lastName: string;
    title:string;
    coe:string;
    reportingTo:string;
    projectName:string;
    location: string;
    businessLine: string;

}
