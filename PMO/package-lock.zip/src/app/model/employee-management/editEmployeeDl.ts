export class EditEmployeeDL {
    companyEmpId: string;
    
    salaryPerHour:string;
   
    effectiveDate: string;
    
}