export interface EmployeeListModel {
    companyEmpId: string;
    empId: string;
    firstName: string;
    lastName: string;
    title:string;
    centerOfExcellence:string;
    reportingTo:string;
    location: string;
    businesLine:string;
roleName:string;
technologyName:string;



}
