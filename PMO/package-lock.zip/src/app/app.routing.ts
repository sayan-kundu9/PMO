import { Routes, RouterModule } from '@angular/router';
import { LoginPageComponent } from "./user/login-page/login-page.component";
import { HomeComponent } from "./home/home.component";
import { SearchProjectComponent } from './home/project-management/search-project/search-project/search-project.component';
import { HomeRoutes }from './home/home.routes';
import { UrlPermission } from "./urlPermission/url.permission";
import { AddEmployeeComponent } from './home/employee-management/add-employee/add-employee.component';
import { ImportEmployeeComponent } from './home/employee-management/import-employee/import-employee.component';
const appRoutes: Routes = [
  
 { path: '', redirectTo: '/login', pathMatch: 'full'},
 { path: 'home', component: HomeComponent , children : HomeRoutes},
 { path: 'login', component: LoginPageComponent },
 //{ path: 'projectManagement/searchProject' , component: SearchProjectComponent },

];

export const routing = RouterModule.forRoot(appRoutes,{useHash:true});
